let imageDecision;
self.onmessage=async({data})=>{
 if('saveImages' in data){imageDecision?.(data.saveImages);return;}
 const {file,name}=data;let doc;
 try{
  self.postMessage({stage:'检查书页文字'});
  doc=Document.openDocument(await file.arrayBuffer(),name.split('.').pop().toLowerCase());
  if(doc.needsPassword())throw Error('书籍受密码保护，请先解锁');
  const count=doc.countPages();if(!count)throw Error('没有可阅读的书页');
  const text=[];let meaningful=false,total=0;
  for(let i=0;i<count;i++){
   const page=doc.loadPage(i);let structured;
   try{structured=page.toStructuredText('preserve-whitespace');const t=structured.asText().trim();text.push(t);
    if(t.replace(/[\s\d\p{P}\p{S}]/gu,'').length>=1)meaningful=true;
    total+=t.length;if(total>16*1024*1024)throw Error('书籍文字超过设备容量');
   }finally{structured?.destroy();page.destroy();}
   if(i%8===0)self.postMessage({stage:'检查书页 '+(i+1)+' / '+count});
  }
  const title=doc.getMetaData('info:Title')||name.replace(/\.[^.]+$/,''),creator=doc.getMetaData('info:Author')||'';
  if(meaningful){
   const bytes=new TextEncoder().encode(text.filter(Boolean).join('\n\n'));
   if(bytes.length>16*1024*1024)throw Error('书籍文字超过设备容量');
   self.postMessage({output:bytes.buffer,ext:'txt',tags:{title,creator}},[bytes.buffer]);return;
  }
  if(count>512)throw Error('图片书超过设备的 512 页上限');
  self.postMessage({imageOnly:true,pages:count});
  if(!await new Promise(resolve=>{imageDecision=resolve;})){self.postMessage({skipped:true});return;}
  const pages=[];let bytes=0;
  for(let i=0;i<count;i++){
   const page=doc.loadPage(i);let pix;
   try{const [x0,y0,x1,y1]=page.getBounds(),scale=Math.min(460/(x1-x0),460/(y1-y0));
    pix=page.toPixmap(Matrix.scale(scale,scale),ColorSpace.DeviceRGB,false);
    const jpg=pix.asJPEG(88).slice();bytes+=jpg.length;if(bytes>32*1024*1024)throw Error('图片书超过 32 MiB');
    pages.push({width:pix.getWidth(),height:pix.getHeight(),jpg});
   }finally{pix?.destroy();page.destroy();}
   self.postMessage({stage:'转换书页 '+(i+1)+' / '+count,progress:Math.floor((i+1)*100/count)});
  }
  self.postMessage({pages,tags:{title,creator}},pages.map(p=>p.jpg.buffer));
 }catch(e){self.postMessage({error:e.message||'这本书无法转换'});}finally{doc?.destroy();}
};

self.postMessage({ready:true});
