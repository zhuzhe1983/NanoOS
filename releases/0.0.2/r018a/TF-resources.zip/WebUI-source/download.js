// The host shares an immutable Blob across workers without retaining a decoder.
async function codecBytes(path,size){
 const blob=await new Promise((resolve,reject)=>{
  function receive({data}){
   if(!('codecBlob' in data))return;
   self.removeEventListener('message',receive);
   if(data.codecBlob instanceof Blob&&data.codecBlob.size===size)resolve(data.codecBlob);
   else reject(Error('转换组件不完整'));
  }
  self.addEventListener('message',receive);
  self.postMessage({codecPath:path,size});
 });
 return new Uint8Array(await blob.arrayBuffer());
}
