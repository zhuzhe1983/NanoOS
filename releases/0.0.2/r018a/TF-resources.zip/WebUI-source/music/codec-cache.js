// Conversion workers are short lived. The page owns the shared bytes and keeps
// one persistent version per engine for the next visit to this device.
const codecLoads=new Map();
let codecDatabase;
function openCodecDatabase(){
 if(!codecDatabase)codecDatabase=new Promise((resolve,reject)=>{
  const open=indexedDB.open('nanoos-conversion-tools',1);
  let blocked=false;
  open.onblocked=()=>{blocked=true;resolve(null);};
  open.onupgradeneeded=()=>open.result.createObjectStore('engines');
  open.onsuccess=()=>{
   const db=open.result;
   if(blocked){db.close();return;}
   db.onversionchange=()=>{db.close();codecDatabase=null;};
   resolve(db);
  };
  open.onerror=()=>reject(open.error);
 }).catch(()=>null);
 return codecDatabase;
}
async function savedCodec(key,record){
 const db=await openCodecDatabase();
 if(!db)return;
 return new Promise((resolve,reject)=>{
  const tx=db.transaction('engines',record?'readwrite':'readonly');
  const store=tx.objectStore('engines');
  const op=record?store.put(record,key):store.get(key);
  tx.oncomplete=()=>resolve(op.result);
  tx.onabort=()=>reject(tx.error);
 });
}
async function loadCodecBlob(path,size,load){
 const key=path.split('?')[0],signal=load.controller.signal;
 const saved=await savedCodec(key).catch(()=>null);
 if(signal.aborted)throw Error('已取消');
 if(saved?.path===path&&saved.blob instanceof Blob&&saved.blob.size===size)return saved.blob;
 // An upgrade from the previous WebUI can already have these bytes in HTTP cache.
 let response=await fetch(path,{mode:'same-origin',cache:'only-if-cached',signal}).catch(()=>null);
 const local=response?.ok;
 if(!local){
  load.notify(0);
  response=await fetch(path,{signal});
 }
 if(!response.ok)throw Error('无法读取 TF 卡转换组件（'+response.status+'）');
 const reader=response.body.getReader(),chunks=[];
 let loaded=0,last=0;
 try{
  for(;;){
   const {done,value}=await reader.read();
   if(done)break;
   loaded+=value.length;
   if(loaded>size)throw Error('转换组件大小异常');
   chunks.push(value);
   if(!local&&(Date.now()-last>=120||loaded===size)){load.notify(loaded);last=Date.now();}
  }
 }finally{reader.releaseLock();}
 if(loaded!==size)throw Error('转换组件不完整，请重试');
 const blob=new Blob(chunks,{type:'application/wasm'});
 if(signal.aborted)throw Error('已取消');
 await savedCodec(key,{path,blob}).catch(()=>{});
 return blob;
}
function acquireCodec(path,size,progress){
 if(!/^\/(video|book)-codec\.wasm\?v=[a-f0-9]{16}$/.test(path)||!Number.isSafeInteger(size)||size<=0)throw Error('转换组件版本无效');
 const key=path.split('?')[0];
 let load=codecLoads.get(key);
 if(load?.path!==path){
  load={path,controller:new AbortController(),users:new Set(),loaded:null,done:false,
   notify(n){this.loaded=n;for(const user of this.users)user(n);}};
  codecLoads.set(key,load);
  load.promise=loadCodecBlob(path,size,load).then(blob=>{load.done=true;load.loaded=null;return blob;},e=>{
   if(codecLoads.get(key)===load)codecLoads.delete(key);
   load.controller.abort();
   throw e;
  });
 }
 load.users.add(progress);
 if(load.loaded!==null)progress(load.loaded);
 return {blob:load.promise,release(){
  load.users.delete(progress);
  if(!load.done&&!load.users.size){
   if(codecLoads.get(key)===load)codecLoads.delete(key);
   load.controller.abort();
  }
 }};
}
