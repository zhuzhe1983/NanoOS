// Local files are inspected and converted before any write to the TF card.
const uploadKinds={
 music:'.mp3,.flac,.wav,.aac,.m4a,.aif,.aiff,.ogg,.opus,.wma,.ape,.alac,.mka,.wv',
 video:'video/*,.mkv,.mjpeg,.mjpg,.avi,.mov,.m4v,.ts,.mts,.flv,.webm',
 books:'.txt,.epub,.pdf,.fb2,.xps,.cbz,.html,.xhtml'
};
let uploadDialog=null,activeWorker=null,activeRequest=null,stopUpload=false,decision=null;
function modalStep(stage,detail='',loaded=null,total=0){
 if(!uploadDialog?.open)return;
 const text=uploadDialog.querySelector('.up-stage'),meter=uploadDialog.querySelector('progress');
 text.textContent=stage;
 uploadDialog.querySelector('.up-detail').textContent=detail;
 if(Number.isFinite(loaded)&&total>0){meter.value=Math.min(100,loaded*100/total);meter.setAttribute('aria-valuetext',Math.floor(meter.value)+'%');}
 else{meter.removeAttribute('value');meter.removeAttribute('aria-valuetext');}
}
function checkUpload(){if(stopUpload)throw Error('已取消');}
function openUploadDialog(kind,files=[]){
 if(uploadBusy){if(uploadDialog&&!uploadDialog.open)uploadDialog.showModal();return;}
 if(!uploadDialog){
  uploadDialog=document.createElement('dialog');uploadDialog.className='upload-dialog';uploadDialog.setAttribute('aria-labelledby','up-heading');document.body.append(uploadDialog);
  uploadDialog.addEventListener('cancel',event=>{if(uploadBusy){event.preventDefault();cancelUpload();}});
 }
 stopUpload=false;
 uploadDialog.innerHTML='<h2 id="up-heading">上传'+esc(libraryNames[kind])+'</h2><p class="up-file"></p><strong class="up-stage" role="status">选择要上传的文件</strong><progress max="100" value="0" aria-label="当前阶段进度"></progress><p class="up-detail">先检查文件，设备可以直接使用的文件将原样上传。</p><ul class="up-results"></ul><input type="file" class="up-input" hidden multiple><div class="up-actions"><button class="button secondary up-close">关闭</button><button class="button primary up-pick">选择文件</button></div>';
 const close=uploadDialog.querySelector('.up-close'),pick=uploadDialog.querySelector('.up-pick');
 close.onclick=()=>uploadBusy?cancelUpload():uploadDialog.close();
 const input=uploadDialog.querySelector('.up-input');input.accept=uploadKinds[kind];
 input.onchange=()=>{if(input.files.length){const selected=[...input.files];input.value='';runUploads(kind,selected);}};
 pick.onclick=()=>input.click();
 if(!uploadDialog.open)uploadDialog.showModal();
 if(files.length)runUploads(kind,files);
}
function cancelUpload(){
 stopUpload=true;
 if(decision){decision(false);decision=null;}
 activeWorker?.cancel();activeRequest?.abort();
 modalStep('正在取消');
}
function askImageBook(count){
 return new Promise(resolve=>{
  const buttons=uploadDialog.querySelector('.up-actions'),old=buttons.hidden;buttons.hidden=true;
  modalStep('这本书只有图片，无法朗读','共 '+count+' 页。可以保存为图片书，在设备上逐页翻阅。');
  const options=document.createElement('div');options.className='up-actions';
  options.innerHTML='<button class="button secondary">跳过此书</button><button class="button primary">保存图片书</button>';
  uploadDialog.append(options);
  decision=save=>{decision=null;options.remove();buttons.hidden=old;resolve(save);};
  options.children[0].onclick=()=>decision(false);options.children[1].onclick=()=>decision(true);
 });
}
function runCodec(file,kind,inspect=true,flatMP4=false,onStage=()=>{}){
 return new Promise((resolve,reject)=>{
  const book=kind==='books',w=new Worker(book?'/book-codec.js':'/video-codec.js',book?{type:'module'}:{});
  const handle={cancel:()=>end(Error('已取消'))};activeWorker=handle;
  const beat=setInterval(updateJobs,15000);let stage='加载转换组件',lease,ended=false;
  function end(error,result){
   if(ended)return;ended=true;lease?.release();w.terminate();clearInterval(beat);if(activeWorker===handle)activeWorker=null;
   if(error)reject(error);else resolve(result);
  }
  w.onerror=()=>end(Error('转换组件加载失败，请检查 TF 卡和网络'));
  const request={file,name:file.name||'',kind,inspect,flatMP4,limit:state.caps.limits.media_upload_bytes||268435456};
  w.onmessage=async({data:d})=>{
   if(d.ready){w.postMessage(request);return;}
   if(d.error){end(Error(d.error));return;}
   if(d.codecPath){
    try{
     lease=acquireCodec(d.codecPath,d.size,n=>{
      stage='下载 WASM 组件';onStage(stage);modalStep(stage,formatBytes(n)+' / '+formatBytes(d.size),n,d.size);
     });
     const blob=await lease.blob;
     if(!ended){stage='加载转换组件';onStage(stage);modalStep(stage);w.postMessage({codecBlob:blob});}
    }catch(e){end(e);}
    return;
   }
   if(d.imageOnly){w.postMessage({saveImages:await askImageBook(d.pages)});return;}
   if(d.stage||d.progress!==undefined){stage=d.stage||stage;onStage(stage);modalStep(stage,d.progress===undefined?'':d.progress+'%',d.progress,100);return;}
   end(null,d);
  };
  modalStep(stage);
  if(!book)w.postMessage(request);
 });
}
async function plainMP4(file){
 let at=0,moov=false,mdat=false;
 for(let boxes=0;boxes<1024&&at+8<=file.size;boxes++){
  const buf=await file.slice(at,at+16).arrayBuffer(),v=new DataView(buf);let size=v.getUint32(0);
  const type=String.fromCharCode(...new Uint8Array(buf,4,4));
  if(type==='moof')return false;if(type==='moov')moov=true;if(type==='mdat')mdat=true;
  if(size===1){if(buf.byteLength<16)return false;size=Number(v.getBigUint64(8));}
  if(!size)size=file.size-at;if(size<8||size>file.size-at)return false;at+=size;
 }
 return at===file.size&&moov&&mdat;
}
async function directAudio(file,ext,header){
 let h=header;
 if((ext==='aac'||ext==='mp3')&&String.fromCharCode(...h.subarray(0,3))==='ID3'&&h.length>=10){
  if(h.subarray(6,10).some(v=>v&128))return false;
  const at=10+h.subarray(6,10).reduce((n,v)=>n*128+v,0)+(h[3]===4&&(h[5]&16)?10:0);
  h=new Uint8Array(await file.slice(at,at+16).arrayBuffer());
 }
 if(h.length<8)return false;
 if(ext==='mp3')return h[0]===255&&(h[1]&224)===224&&(h[1]>>3&3)!==1&&(h[1]>>1&3)===1&&(h[2]>>4)>0&&(h[2]>>4)<15&&(h[2]>>2&3)!==3;
 if(ext==='aac'){
  const rates=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000],rate=rates[h[2]>>2&15],channels=(h[2]&1)*4+(h[3]>>6);
  return h[0]===255&&(h[1]&246)===240&&(h[2]>>6)===1&&rate>=8000&&rate<=48000&&channels>=1&&channels<=2;
 }
 if(ext==='wav'&&String.fromCharCode(...h.subarray(0,4))==='RIFF'&&String.fromCharCode(...h.subarray(8,12))==='WAVE'){
  const v=new DataView(h.buffer,h.byteOffset,h.byteLength);
  for(let i=12;i+24<=h.length;){
   const bytes=v.getUint32(i+4,true);
   if(String.fromCharCode(...h.subarray(i,i+4))==='fmt '){
    const rate=v.getUint32(i+12,true),channels=v.getUint16(i+10,true);
    return bytes>=16&&v.getUint16(i+8,true)===1&&channels>=1&&channels<=2&&rate>=8000&&rate<=48000&&[8,16,24,32].includes(v.getUint16(i+22,true));
   }
   i+=8+bytes+(bytes&1);
  }
 }
 return false;
}

async function prepareLocal(file,kind){
 const ext=file.name.split('.').pop().toLowerCase(),base=file.name.replace(/\.[^.]+$/,'');
 const head=new Uint8Array(await file.slice(0,4096).arrayBuffer());
 checkUpload();if(!head.length)throw Error('文件为空');
 const sig=n=>String.fromCharCode(...head.subarray(0,n));
 if(kind==='books'){
  if(ext==='txt'){
   if(file.size>16777216)throw Error('文本书超过 16 MiB');
   const raw=new Uint8Array(await file.arrayBuffer());
   try{new TextDecoder('utf-8',{fatal:true}).decode(raw);if(raw.includes(0))throw Error();return {blob:file,name:file.name};}
   catch{let codec=raw[0]===255&&raw[1]===254?'utf-16le':raw[0]===254&&raw[1]===255?'utf-16be':'gb18030';
    modalStep('转换文字编码',codec+' → UTF-8');const text=new TextDecoder(codec,{fatal:true}).decode(raw);if(text.includes('\0'))throw Error('文本编码无法识别');return {blob:new Blob([text]),name:base+'.txt'};}
  }
  if(file.size>33554432)throw Error('书籍超过 32 MiB');
  if(ext==='epub'){try{const parsed=await loadEpub(file);return {blob:parsed.blob,tags:parsed.metadata||parsed.tags||{},name:base+'.txt'};}catch(e){if(!e.message.includes('没有可阅读的文字'))throw e;}}
  const r=await runCodec(file,'books');if(r.skipped)return {skipped:true};
  return r.pages?{pages:r.pages,name:base+'.nbook',tags:r.tags}:{blob:new Blob([r.output]),name:base+'.txt',tags:r.tags};
 }
 if(kind==='music'&&await directAudio(file,ext,head))return {blob:file,name:file.name};
 if(kind==='music'&&ext==='flac'&&sig(4)==='fLaC'&&head.length>=42&&(head[4]&127)===0){
  const block=head[10]*256+head[11],hz=head[18]*4096+head[19]*16+(head[20]>>4),ch=(head[20]>>1&7)+1,bits=((head[20]&1)<<4|head[21]>>4)+1;
  if(block>0&&block<=8192&&hz>=8000&&hz<=48000&&ch<=2&&bits<=24)return {blob:file,name:file.name};
 }
 const r=await runCodec(file,kind,true,ext==='mp4'&&await plainMP4(file));checkUpload();
 return r.direct?{blob:file,name:file.name}:{blob:new Blob([r.output]),name:base+'.'+r.ext};
}
const fileOp=(operation,source,destination)=>api('/file-manager',{method:'POST',body:JSON.stringify({operation,source,destination})});
function zipCRC(bytes){let crc=0xffffffff;for(const v of bytes){crc^=v;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function bookIndex(pages){
 const raw=new Uint8Array(32+pages.length*64),v=new DataView(raw.buffer),enc=new TextEncoder();
 raw.set(enc.encode('NBP1'));for(const [i,n] of [[4,1],[6,32],[8,64],[10,pages.length]])v.setUint16(i,n,true);
 for(const [i,page] of pages.entries()){
  const pos=32+i*64;raw.set(enc.encode(page.file),pos);v.setUint16(pos+32,page.width,true);v.setUint16(pos+34,page.height,true);
  v.setUint32(pos+36,page.jpg.length,true);v.setUint32(pos+40,zipCRC(page.jpg),true);v.setUint32(pos+44,i+1,true);
 }
 v.setUint32(16,zipCRC(raw.subarray(32)),true);v.setUint32(20,5,true);v.setUint32(28,zipCRC(raw.subarray(0,28)),true);
 return new Blob([raw]);
}
async function saveImageBook(book){
 if(byteLength(book.name)>96||/[\\/:*?"<>|\x00-\x1f]/.test(book.name)||book.name.includes('..'))throw Error('图片书名称过长或含有无效字符');
 const id=Array.from(crypto.getRandomValues(new Uint32Array(3)),n=>n.toString(16)).join('-'),dir='txt/upload-'+id;
 const owned=[];let temp='',committed=false;
 await fileOp('mkdir',dir);
 try{
  async function savePart(name,blob,i,total){
   checkUpload();const stagingName=id+'-'+name;
   await putMedia('inbox',stagingName,blob,i+'/'+total);temp='nanoos/inbox/'+stagingName;
   await fileOp('move',temp,dir+'/'+name);temp='';owned.push(dir+'/'+name);
  }
  const n=book.pages.length;
  for(const [i,page] of book.pages.entries()){
   page.file='page-'+String(i+1).padStart(4,'0')+'.jpg';await savePart(page.file,new Blob([page.jpg]),i+1,n+1);
  }
  await savePart('pages.nbp',bookIndex(book.pages),n+1,n+1);
  checkUpload();await fileOp('move',dir,'txt/'+book.name);committed=true;
 }finally{
  if(!committed){if(temp)await fileOp('delete',temp).catch(()=>{});for(const f of owned.reverse())await fileOp('delete',f).catch(()=>{});await fileOp('delete',dir).catch(()=>{});}
 }
}


async function uploadLocalFiles(kind,files){
 if(uploadBusy||!files.length||!uploadDialog?.open)return;
 uploadBusy=true;stopUpload=false;
 const imports={},saved=[],failed=[],dlg=uploadDialog,started=Date.now();
 dlg.querySelector('.up-pick').hidden=true;dlg.querySelector('.up-close').textContent='取消';
 try{
  for(const [i,file] of files.entries()){
   checkUpload();const batch=files.length>1?(i+1)+' / '+files.length:'';
   dlg.querySelector('.up-file').textContent=(batch?batch+' · ':'')+file.name;
   postJob('upload',{label:libraryNames[kind],status:'检查 '+file.name,done:i,goal:files.length,started});
   modalStep('检查文件',formatBytes(file.size));let detail='';
   try{
    const r=await prepareLocal(file,kind);checkUpload();
    if(r.skipped)detail='已跳过';
    else{
     if(r.pages)await saveImageBook(r);else await putMedia(kind,r.name,r.blob,batch);
     const path=({books:'txt',video:'mjpeg',music:'music'})[kind]+'/'+r.name+(r.pages?'/pages.nbp':'');
     if(r.tags)imports[path]=r.tags;
     saved.push(path);detail='已保存到 /'+path.replace(/\/pages\.nbp$/,'/');
    }
   }catch(e){if(stopUpload)throw e;detail=e.message;failed.push(file.name);}
   const line=document.createElement('li');line.textContent=file.name+' · '+detail;dlg.querySelector('.up-results').append(line);
  }
 }catch(e){if(!stopUpload)failed.push(e.message);}
 finally{
  uploadBusy=false;postJob('upload');
  if(saved.length){send(kind==='music'?'music-import':'media-upload',{kind,imports});}
  const result=stopUpload?'已取消':failed.length?'部分文件未保存':saved.length?'上传完成':'已跳过';
  modalStep(result,saved.length?'已保存 '+saved.length+' 个文件，资料库正在更新。':failed.length?'请查看文件旁的原因。':'',1,1);
  dlg.querySelector('.up-close').textContent='关闭';dlg.querySelector('.up-pick').hidden=false;dlg.querySelector('.up-pick').textContent='继续选择文件';
 }
}
async function deleteImageBook(path){
 const dir=path.slice(0,-'/pages.nbp'.length);let cursor=0,entries=[];
 do{const page=await api('/file-manager',{method:'POST',body:JSON.stringify({operation:'list',source:dir,cursor})});
  entries.push(...page.entries);cursor=page.next_cursor;
 }while(cursor);
 if(entries.some(e=>e.directory||!(/^(page-\d{4}\.jpg|pages\.nbp)$/.test(e.name))))throw Error('书籍目录含其他文件，请在文件管理中检查');
 const trash=dir.slice(0,dir.lastIndexOf('/')+1)+'remove-'+Array.from(crypto.getRandomValues(new Uint32Array(3)),n=>n.toString(16)).join('-');
 await fileOp('move',dir,trash);
 try{for(const e of entries)await fileOp('delete',trash+'/'+e.name);await fileOp('delete',trash);}
 catch{throw Error('书籍已移出资料库，剩余文件在 /'+trash);}
}
