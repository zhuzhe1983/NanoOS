self.onmessage=async({data})=>{
 if('codecBlob' in data)return;
 try{
  const {file,limit,kind='video',inspect=false,name=''}=data;
  const core=await createFFmpegCore({wasmBinary:await codecBytes('/video-codec.wasm',CODEC_BYTES)});
  core.FS.mkdir('/input');core.FS.mount(core.FS.filesystems.WORKERFS,{blobs:[{name:'source',data:file}]},'/input');
  let reason='',last=0;
  core.setLogger(({message})=>{if(/error|invalid|unsupported|not found/i.test(message))reason=message.slice(-180);});
  self.postMessage({stage:'检查音视频编码'});
  // This build can leave ret at its reset value after ffprobe writes valid JSON.
  core.ffprobe('-v','error','-show_entries','stream=codec_type,codec_name,profile,sample_rate,channels,width,height,field_order,refs,pix_fmt,avg_frame_rate,r_frame_rate,bits_per_raw_sample,sample_fmt:stream_disposition=attached_pic:format=format_name,duration','-of','json','-o','/probe.json','/input/source');
  let info;try{info=JSON.parse(core.FS.readFile('/probe.json',{encoding:'utf8'}));}catch{}
  if(!Array.isArray(info?.streams)||!info.format)throw Error('无法识别音视频流');
  const audio=info.streams.find(s=>s.codec_type==='audio'),video=info.streams.find(s=>s.codec_type==='video'&&!s.disposition?.attached_pic);
  const hz=Number(audio?.sample_rate),channels=Number(audio?.channels),ext=name.split('.').pop().toLowerCase();
  if(kind==='music'&&!audio||kind==='video'&&!video)throw Error('文件中没有对应的音轨或画面');
  const stereo=audio&&hz>=8000&&hz<=48000&&channels>=1&&channels<=2;
  const fps=String(video?.avg_frame_rate||video?.r_frame_rate||'0/1').split('/').map(Number),rate=fps[0]/fps[1];
  const dimensions=video&&video.width<=460&&video.height<=460;
  const seconds=Number(info.format.duration);
  if(kind==='video'&&seconds>3600)throw Error('设备支持一小时以内的视频');
  let direct=false;
  if(kind==='music'&&stereo){
   direct=ext==='mp3'&&audio.codec_name==='mp3'||ext==='aac'&&audio.codec_name==='aac'&&audio.profile==='LC'||
    ext==='wav'&&['pcm_u8','pcm_s16le','pcm_s24le','pcm_s32le'].includes(audio.codec_name);
  }else if(kind==='video'&&dimensions&&rate>0&&rate<=24){
   if(ext==='avi'&&info.format.format_name==='avi')direct=video.codec_name==='mjpeg'&&(!audio||stereo&&audio.codec_name==='pcm_s16le');
   if(/^(mjpg|mjpeg)$/.test(ext))direct=video.codec_name==='mjpeg'&&!audio;
   if(ext==='mp4')direct=video.codec_name==='h264'&&/Baseline/.test(video.profile||'')&&video.refs<=2&&video.pix_fmt==='yuv420p'&&(!video.field_order||['unknown','progressive'].includes(video.field_order))&&(!audio||stereo&&audio.codec_name==='aac'&&audio.profile==='LC')&&data.flatMP4;
  }
  if(inspect&&direct){self.postMessage({direct:true});return;}
  self.postMessage({stage:kind==='music'?'转换为 FLAC':'转换为 MJPEG / AVI'});
  core.setProgress(({progress})=>{if(Date.now()-last>=200){last=Date.now();self.postMessage({progress:Math.min(99,Math.max(0,Math.floor(100*progress)||0))});}});
  const output=kind==='music'?'/output.flac':'/output.avi',args=['-hide_banner','-loglevel','error','-threads','1','-i','/input/source'];
  if(kind==='music'){
   args.push('-map','0:a:0','-vn','-c:a','flac','-compression_level','5','-frame_size','4096');
   if(channels>2)args.push('-ac','2');if(hz>48000||hz<8000)args.push('-ar',String(hz<8000?8000:48000));
   if(Number(audio.bits_per_raw_sample)>24||audio.sample_fmt?.startsWith('flt')||audio.sample_fmt?.startsWith('dbl'))args.push('-sample_fmt','s32','-bits_per_raw_sample','24');
  }else{
   args.push('-map','0:v:0','-map','0:a:0?','-sn','-dn','-vf',"scale=w='min(460,iw)':h='min(460,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1",'-fpsmax','20','-c:v','mjpeg','-q:v','4','-pix_fmt','yuvj420p','-threads','1','-c:a','pcm_s16le');
   if(audio&&(!stereo||hz>48000)){args.push('-ar',String(Math.max(8000,Math.min(48000,hz||48000))));if(channels>2)args.push('-ac','2');}
   args.push('-f','avi');
  }
  core.reset();
  if(core.exec(...args,'-fs',String(limit+1048576),output)!==0)throw Error(reason||'转换失败');
  const size=core.FS.stat(output).size;if(!size||size>limit)throw Error('转码结果超过单文件传输上限');
  const bytes=core.FS.readFile(output);self.postMessage({output:bytes.buffer,ext:kind==='music'?'flac':'avi'},[bytes.buffer]);
 }catch(e){self.postMessage({error:e.message||'媒体转换失败'});}
};
