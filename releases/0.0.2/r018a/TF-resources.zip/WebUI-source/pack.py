"""Build the offline TF assets from the pinned, single-threaded FFmpeg distribution."""
import base64
import gzip
import hashlib
import io
import json
import sys
import tarfile
import urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
package=json.loads((root/'package.json').read_text())
if len(sys.argv)>1:
    archive=Path(sys.argv[1]).read_bytes()
else:
    with urllib.request.urlopen(package['tarball'],timeout=90) as response:
        archive=response.read()
assert 'sha512-'+base64.b64encode(hashlib.sha512(archive).digest()).decode()==package['integrity']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tf:
    core=tf.extractfile('package/dist/umd/ffmpeg-core.js').read()
    wasm=tf.extractfile('package/dist/umd/ffmpeg-core.wasm').read()
book=json.loads((root/'book-package.json').read_text())
if len(sys.argv)>2:
    book_archive=Path(sys.argv[2]).read_bytes()
else:
    with urllib.request.urlopen(book['tarball'],timeout=90) as response:book_archive=response.read()
assert 'sha512-'+base64.b64encode(hashlib.sha512(book_archive).digest()).decode()==book['integrity']
with tarfile.open(fileobj=io.BytesIO(book_archive),mode='r:gz') as tf:
    def unpack(name):return tf.extractfile('package/'+name).read()
    book_wasm=unpack('dist/mupdf-wasm.wasm')
    glue=unpack('dist/mupdf-wasm.js').replace(b'export default _;',b'const libmupdf_wasm=_;')
    api=unpack('dist/mupdf.js').replace(b'import libmupdf_wasm from "./mupdf-wasm.js";',b'').replace(b'globalThis["$libmupdf_wasm_Module"]',b"{wasmBinary:await codecBytes('/book-codec.wasm',"+str(len(book_wasm)).encode()+b')}')
    book_js=glue+b'\n'+(root/'download.js').read_bytes()+api+b'\n'+(root/'book-worker.js').read_bytes()
    (root/'MuPDF-LICENSE').write_bytes(unpack('LICENSE'))
out=root/'assets';out.mkdir(exist_ok=True)
entries=[]
for name,data in [('js',core+b'\nconst CODEC_BYTES='+str(len(wasm)).encode()+b';\n'+(root/'download.js').read_bytes()+(root/'worker.js').read_bytes()),('wasm',wasm),('book_js',book_js),('book_wasm',book_wasm)]:
    if name in ('js','book_js'):
        raw=wasm if name=='js' else book_wasm
        url=b'/video-codec.wasm' if name=='js' else b'/book-codec.wasm'
        data=data.replace(url+b"'",url+b'?v='+hashlib.sha256(raw).hexdigest()[:16].encode()+b"'")
    data=gzip.compress(data,compresslevel=6,mtime=0)
    digest=hashlib.sha256(data).digest()
    file='video-'+digest.hex()[:16]+'.'+name+'.gz'
    (out/file).write_bytes(data)
    entries.append('#define VIDEO_'+name.upper()+'_PATH "tools/'+file+'"\n#define VIDEO_'+name.upper()+'_SIZE '+str(len(data))+'u\nstatic const unsigned char video_'+name+'_sha[32]={'+','.join(str(x) for x in digest)+'};')
(root/'assets.h').write_text('#pragma once\n'+'\n'.join(entries)+'\n')
