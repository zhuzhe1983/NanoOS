'use strict';
if(typeof document==='undefined'){
const WASM_BASE64='AGFzbQEAAAABMwhgAn9/AGAHf39/f39/fwBgA39/fwBgAX8Bf2ADf39/AX9gAn9/AX9gBH9/f38AYAABfwMODQABAgADAAQFBgcEBAQFAwEAEgYJAX8BQYCAwAALBycEBm1lbW9yeQIABmJ1ZmZlcgAJCm1lZGlhX3NwYW4ACgRzcGFuAAsKkyQN0QEBBX8CQAJAIAEoAgAiAiABKAIERw0AQQAhAwwBC0EBIQMgASACQQFqNgIAIAItAAAiBMBBf0oNACABIAJBAmo2AgAgAi0AAUE/cSEFIARBH3EhBgJAIARB3wFLDQAgBkEGdCAFciEEDAELIAEgAkEDajYCACAFQQZ0IAItAAJBP3FyIQUCQCAEQfABTw0AIAUgBkEMdHIhBAwBCyABIAJBBGo2AgAgBUEGdCACLQADQT9xciAGQRJ0QYCA8ABxciEECyAAIAQ2AgQgACADNgIAC6cCAQl/QQAhBwJAAkAgBkECSw0AIAEgAUF8aiIIIAEgCEkbIQkgBEEBaiEKIAZBAnQoAryBwIAAIQsgBEH/AXFBA0YhDANAIAJBCGoiDSADSw0BIAJBBGoiBCAJSw0BIAQoAPyFwIAAIgQgDWoiCCAESQ0BIAJB/IXAgABqKAAAIQ4CQCAEQQRJDQAgDA0AIA5BzJLNogVHDQAgAkEMaiICIAFLDQIgDSgA/IXAgAAiD0Ht3tnLBkYNACAAIAEgAiAIIAMgCCADSRsgCiAPQcmcmfoERiAGEIGAgIAAIAAoAgANAwsgCCADSw0BAkAgBUUNACAOIAsoAABHDQAgACAENgIIIAAgDTYCBEEBIQcMAgsgBEEBcSAIaiECDAALCyAAIAc2AgALC8YCAQp/I4CAgIAAQSBrIgMkgICAgAAgAyABNgIIIAMgATYCACADIAI2AgQgAyABIAJqNgIMIANBADYCECADQRRqIAMQg4CAgAAgAygCHEEAIAMoAhQiBBshBSADKAIYIQYgAygCDCECIAMoAgghBwJAA0AgByACIghGDQECQCAIQX9qIgIsAAAiCUF/Sg0AAkACQCAIQX5qIgItAAAiCsAiC0FASA0AIApBH3EhCgwBCwJAAkAgCEF9aiICLQAAIgrAIgxBQEgNACAKQQ9xIQoMAQsgCEF8aiICLQAAQQdxQQZ0IAxBP3FyIQoLIApBBnQgC0E/cXIhCgsgCkEGdCAJQT9xciEJCyAJEISAgIAADQALIAggB2sgAygCEGohBQsgACAFIAZBACAEGyICazYCBCAAIAEgAmo2AgAgA0EgaiSAgICAAAuZAQEGfyOAgICAAEEQayICJICAgIAAIAFBCGohAwJAA0AgASgCCCEEIAEoAgwhBSACQQhqIAMQhYCAgAACQCACKAIMIgZBf0cNAEEAIQEMAgsgAigCCCEHIAYQhICAgAANAAsgACAHNgIEIAAgBSAEayAHaiABKAIIaiABKAIMazYCCEEBIQELIAAgATYCACACQRBqJICAgIAAC5sBAQJ/AkACQCAAQXdqIgFBF0sNAEEBIQJBn4CABCABdkEBcQ0BC0EAIQIgAEGFAUkNAAJAAkAgAEEIdiIBRQ0AAkAgAUEwRg0AIAFBIEYNAiABQRZHDQMgAEGALUYhAgwDCyAAQYDgAEYhAgwCCyAAQf8BcS0A7IHAgAAhAgwBCyAAQf8BcS0A7IHAgABBAnFBAXYhAgsgAkEBcQuEAQEFfyOAgICAAEEQayICJICAgIAAIAEoAgAhAyABKAIEIQQgAkEIaiABEICAgIAAAkACQCACKAIIQQFGDQBBfyEFDAELIAIoAgwhBSABIAEoAggiBiAEaiADIAEoAgRqayABKAIAajYCCAsgACAFNgIEIAAgBjYCACACQRBqJICAgIAACw8AIAAgASACEIyAgIAARQspAQF/IAAgAXJFIQICQCAARQ0AIAFFDQAgACABQQQQhoCAgAAhAgsgAgs/AQF/IANBf2ohBAJAAkAgAw0AQQAhAwwBCyACQQAgASACIARqQQEQhoCAgAAbIQMLIAAgBDYCBCAAIAM2AgALCABB/IXAgAALtBEBEn8jgICAgABBkAFrIgMkgICAgABBACEEAkAgAEGAgARLDQBBACEEAkACQAJAAkACQAJAAkACQCABDgMAAQIICyAARQ0CQQAgAEF5aiIBIAEgAEsbIQVB/4XAgABBfHFB/IXAgABrIQZBACEBA0ACQAJAAkACQCABLQD8hcCAACIHwCIIQQBIDQAgBiABa0EDcQ0BIAEgBU8NAgNAIAFBgIbAgABqKAIAIAFB/IXAgABqKAIAckGAgYKEeHENAyABQQhqIgEgBUkNAAwDCwtBACEEAkACQAJAAkACQAJAAkACQAJAIActAOyDwIAAQX5qDgMAAgEUCyABQQFqIgEgAE8NEyABLAD8hcCAAEG/f0wNBwwTCyABQQFqIgkgAE8NEiAJLAD8hcCAACEJIAdBkH5qDgUCAQEBAwELIAFBAWoiCSAATw0RIAksAPyFwIAAIQkCQAJAAkAgB0HgAUYNACAHQe0BRg0BIAhBH2pB/wFxQQxJDQIgCEF+cUFuRw0UIAlBQEgNBwwUCyAJQWBxQaB/Rg0GDBMLIAlBn39KDRIMBQsgCUFASA0EDBELIAhBD2pB/wFxQQJLDRAgCUFASA0CDBALIAlB8ABqQf8BcUEwSQ0BDA8LIAlBj39KDQ4LIAFBAmoiByAATw0NIAcsAPyFwIAAQb9/Sg0NIAFBA2oiASAATw0NIAEsAPyFwIAAQb9/Sg0NDAELIAFBAmoiASAATw0MIAEsAPyFwIAAQb9/Sg0MCyABQQFqIQEMAgsgAUEBaiEBDAELIAEgAE8NAANAIAFB/IXAgABqLAAAQQBIDQEgACABQQFqIgFHDQAMBQsLIAEgAEkNAAwDCwtBACEEQQBB/IXAgAAgAEEESRtB5IHAgAAQh4CAgABFDQZBACEEQQBBhIbAgAAgAEEMSRtB6IHAgAAQh4CAgABFDQYgA0HwAGogAEEMIABBAEEAIAIQgYCAgAAgAygCcCEEIAMoAnghAQwDCyACQQJLDQNBACEEQQAgAEF9aiIBIAEgAEsbIQcgAEF8aiEFIAJBAnQoAtSBwIAAIQJBACEBA0AgByABRg0GAkACQCABQQRJDQAgAUH8hcCAAGooAAAgAigAAEcNAEEAIAFBhIbAgABqIAFBDGogAEsbQeCBwIAAEIeAgIAARQ0AIAFBCGogAEsNCCABQRBqIABLDQggAUGAhsCAAGooAAAiCCAIQRB4c0GA/oN4cUEIdiAIQQh4cyIIQRBJDQAgAUH4hcCAAGooAAAiBiAGQRB4c0GA/oN4cUEIdiAGQQh4cyAIQQhqSQ0AIAggBUsNACABQYiGwIAAaigAAEGAgIAIRg0BCyABQQFqIQEgBUF/aiEFDAELCyADIAFBFGo2AnQgCEFwaiEBDAELQQAhBCACQQJLDQQgA0EKNgJMIAJBAnQoAuyFwIAAIgogAi0A+IXAgABBA3RqIQggA0GAAWohC0E8IQxBACEJQQAhDUEAIQ4DQCAMRQ0DIA1BAXENAyAMQX9qIQwCQAJAAkADQAJAIAAgDk8NACAOIQ8MAwsgDkH8hcCAAGohBQJAAkAgACAOayIHQQdLDQBBACEBA0AgByABRg0EIAUgAWotAABBCkYNAiABQQFqIQEMAAsLAkACQAJAIAVBA2pBfHEiASAFRg0AIAEgBWshBEEAIQEDQCAFIAFqLQAAQQpGDQQgBCABQQFqIgFHDQALIAQgB0F4aiIGSw0CDAELIAdBeGohBkEAIQQLA0BBgIKECCAFIARqIgEoAgAiAkGKlKjQAHNrIAJyQYCChAggAUEEaigCACIBQYqUqNAAc2sgAXJxQYCBgoR4cUGAgYKEeEcNASAEQQhqIgQgBk0NAAsLIAcgBEYNAiAFIARqIQUgACAEayAOayECQQAhAQJAA0AgBSABai0AAEEKRg0BIAIgAUEBaiIBRg0EDAALCyABIARqIQELIA4gAWoiAUEBaiEOIAEgAE8NACABQfyFwIAAai0AAEEKRw0AC0EAIQ0gDiEPIA4hAQwCCyAAIQ8LIAAgCUYNBEEBIQ0gCSEOIAAhAQsgA0EKNgJwIANBMGogA0HwAGogCUH8hcCAAGoiBCABIAlrIgUQiICAgAACQCADKAIwIgFFDQAgAygCNCEEIANBDTYCcCADQShqIANB8ABqIAEgBBCIgICAACADKAIsIAQgAygCKCICGyEFIAIgASACGyEECyAERQ0DIAQgBWohB0EAIQECQAJAA0AgAyAHNgJ0IAMgBCABIgJqNgJwIANBIGogA0HwAGoQgICAgAAgAygCIEEBRw0BIAUgAygCdGsgAygCcGohASADKAIkQf/9A0YNAAwCCwsgBSECCyADQRhqIAQgAmogBSACaxCCgICAACADKAIYIgYgAygCHCIHaiEQIAohAgNAAkAgAiIBIAhHDQAgDiEJIA8hDgwCCyABQQhqIQIgByABKAIEIgRJDQAgASgCACAGIAQQhoCAgABFDQAgA0EANgKAASADIBA2AnwgAyAGIARqIgE2AnggAyABNgJwIAMgByAEayIENgJ0IANB5ABqIANB8ABqEIOAgIAAIAMoAmghBSADKAJkIQkgA0EANgKIASADIBA2AoQBIAMgASAFIAQgCRsiBWoiCTYCgAEgAyAEIAVrIhE2AnwgAyAJNgJ4IANCuoCAgKDjPzcDcCADQRBqIAsQhYCAgAAgAygCFCIFQX9GDQAgAygCECESQQAhASADKAKAASETIAMoAoQBIRQDQCABQQhGDQEgA0HwAGogAWohBCABQQRqIQEgBCgCACAFRw0ACyADQQhqIAkgEiARaiAUayATaiIBaiARIAFrEIKAgIAAIAMoAgwiAUUNAAsLIAMgAygCCEH8hcCAAGs2AnQLQQEhBAsgBA0BC0EAIQQMAQtBACEEIAFBf2pBgAhPDQAgAygCdEEQdCABciEECyADQZABaiSAgICAACAEC4oHAQ1/I4CAgIAAQdAAayIDJICAgIAAQQAhBAJAIABBgIAESw0AIANBCzYCJCADQY+BwIAANgIgIANBCzYCHCADQYSBwIAANgIYIANBBTYCFCADQf+AwIAANgIQIANBBjYCDCADQfmAwIAANgIIIANBBTYCBCADQfSAwIAANgIAIANBBDYCTCADQaqBwIAANgJIIANBBDYCRCADQaaBwIAANgJAIANBBDYCPCADQaKBwIAANgI4IANBBDYCNCADQZ6BwIAANgIwIANBBDYCLCADQZqBwIAANgIoAkACQAJAAkAgAQ4FAAQEAQEECyAAQQRJDQNBACgC/IXAgAAiBUF7Sw0DIAAgBUEEaiIGSQ0DIAAgBmtBBEkNAyAFQQhqIQcgAyACQQN0aiEIIAVBgIbAgABqKAAAIQlBACEKA0AgByELIAogCUYNBCAAIAtJDQQgACALa0EESQ0EIAsoAPyFwIAAIgwgC0EEaiIFaiIHIAxJDQQgByAASyIGDQQgCkEBaiEKQQAgBUH8hcCAAGoiDSAGGyEOQQAhBQNAIA0gBWohBiAMIAVGDQECQCAGLQAAQT1GDQAgBUEBaiEFDAELCyACQQRLDQQgBSAIKAIERw0AIAgoAgAhD0EAIQYDQCAFIAZGDQMgDiAGaiENIA8gBmohASAGQQFqIQZBIEEAIA0tAAAiDUG/f2pB/wFxQRpJGyANckH/AXFBIEEAIAEtAAAiDUG/f2pB/wFxQRpJGyANckH/AXFHDQEMAAsLCyADQShqIAJBA3RqIQ9BACEFA0AgBUEKaiIOIABLDQMgBUH8hcCAAGoiCy0AAEUNAyALQQRqIQwCQAJAIAFBBEcNACAFQYCGwIAAaiENQQAhBQNAAkAgBUEERw0AQQAhBkEAIQUDQCAGQQd0IAwgBWotAAByIQYgBUEBaiIFQQRHDQAMBAsLIA0gBWohBiAFQQFqIQUgBiwAAEEATg0ADAYLCyAMKAAAIgUgBUEQeHNBgP6DeHFBCHYgBUEIeHMhBgsgBiAOaiIFIAZJDQMCQCALLQAJDQAgAkEESw0EIA9BBGooAgBBBEcNACALIA8oAgBBBBCGgICAACEMIAUgAEsNACAMDQMLIAUgAE0NAAwDCwsgDCAFQX9zaiEGIAsgBWpBBWohDgsgBkF/akH/H0sNACAOQRB0IAZyIQQLIANB0ABqJICAgIAAIAQLSgEDf0EAIQMCQCACRQ0AAkADQCAALQAAIgQgAS0AACIFRw0BIABBAWohACABQQFqIQEgAkF/aiICRQ0CDAALCyAEIAVrIQMLIAMLC4UGAQBBgIDAAAv7BeS5puWQjeagh+mimFRpdGxlAAAAAAAQAAYAAAAGABAABgAAAAwAEAAFAAAA5L2c6ICFQXV0aG9yLAAQAAYAAAAyABAABgAAAOWIhuexu+exu+WIq0dlbnJlAAAASAAQAAYAAABOABAABgAAAFQAEAAFAAAAVElUTEVBUlRJU1RBTEJVTUFMQlVNQVJUSVNUVFJBQ0tOVU1CRVJUSVQyVFBFMVRBTEJUUEUyVFJDS0lOQU1JQVJUSUdOUgAArgAQALIAEAC2ABAAqW5hbalBUlSpZ2VuyAAQAMwAEADQABAAZGF0YVJJRkZBVkkgAgICAgICAgICAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAICAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwMDAwMDAwMDAwMDAwMDAwQEBAQEAAAAAAAAAAAAAAAUABAAOAAQAFwAEAADAgM=';
// ID3v2 marker 0 is frequently used for legacy multibyte encodings. Some
// taggers also store that misdecoded Latin text again as UTF-8 or UTF-16.
const tagFields = ['title', 'artist', 'album', 'albumArtist'];
const western = new TextDecoder('windows-1252');
const legacyByte = new Map(Array.from({length: 256}, (_, b) => [western.decode(Uint8Array.of(b)), b]));
const han = /[\u3400-\u9fff]/u;
function legacyBytes(text) {
 const bytes = [];
 for (const c of text) {
  const n = legacyByte.get(c) ?? c.codePointAt(0);
  if (n > 255) return null;
  bytes.push(n);
 }
 return Uint8Array.from(bytes);
}
function alternatives(bytes) {
 const result = [];
 for (const label of ['utf-8','gb18030','big5']) {
  try {
   const text = new TextDecoder(label,{fatal:true}).decode(bytes).replace(/\0+$/u,'').replaceAll('\0',' / ').trim();
   if (han.test(text) && !/[\x00-\x1f\x7f-\x9f\ufffd]/u.test(text)) result.push({label,text});
  } catch {}
 }
 return result;
}
function anchorMatch(text,path) {
 const normalize = s => s.normalize('NFKC').toLowerCase();
 const parts = normalize(path).split('/');
 const tokens = normalize(text).match(/[\u3400-\u9fff]{2,}/gu) || [];
 return tokens.some(token => parts.some(part => part.includes(token)));
}
function repairTagEncoding(track) {
 // Cross-check decoded title/album/artist against the original TF path.
 // Apply a common encoding only when the independent evidence agrees.
 const evidence = new Set(), candidates = {};
 for (const field of tagFields) {
  const value = track[field];
  if (!value || han.test(value) || !/[\u0080-\u00ff\u2010-\u203a]/u.test(value)) continue;
  const bytes = legacyBytes(value);
  if (!bytes || bytes.filter(b => b >= 128).length < 4) continue;
  const options = alternatives(bytes);
  if (!options.length) continue;
  candidates[field] = options;
  const matches = options.filter(o => anchorMatch(o.text,track.path));
  if (matches.length === 1) evidence.add(matches[0].label);
 }
 const chosen = evidence.size === 1 ? [...evidence][0] : '';
 const repaired = {...track, suggestions:{...track.suggestions}, tagEncodingVersion:1};
 for (const [field, options] of Object.entries(candidates)) {
  const candidate = chosen && options.find(o => o.label === chosen);
  // Western names can be legitimate in the same album as legacy Chinese tags.
  // An unanchored field must also look like consecutive multibyte text.
  const highRuns = [...legacyBytes(track[field])].map(byte => byte < 128 ? ' ' : 'x').join('').match(/x+/g) || [];
  const use = candidate && (anchorMatch(candidate.text,track.path) ||
   (highRuns.every(run => run.length >= 2) && !/[a-z]{3}/i.test(track[field])));
  if (use) {
   repaired.originalTags = {...repaired.originalTags, [field]:track[field]};
   repaired[field] = candidate.text;
  }
  const previous = repaired.suggestions[field] || [];
  const choices = [...previous,...options];
  if (use) choices.push({label:'原始标签',text:track[field]});
  repaired.suggestions[field] = choices.filter((o,i) =>
   o.text !== repaired[field] && choices.findIndex(other=>other.text===o.text)===i);
 }
 return repaired;
}

// Native view index. All offsets are 32-bit little-endian; strings are UTF-8.
// The device can fetch any grid cell with one fixed-record seek and bounded text reads.
const collation=new Intl.Collator('zh-CN-u-co-pinyin',{numeric:true,sensitivity:'base'});
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ#';
// ICU Chinese index contractions give bucket boundaries before the first Han character of each reading.
const hanLetters='ABCDEFGHJKLMNOPQRSTWXYZ';
function initialOf(name){
 const first=name.trim().normalize('NFKD')[0]||'';
 if(/[a-z]/i.test(first))return alphabet.indexOf(first.toUpperCase());
 if(!/[\u3400-\u9fff]/u.test(first))return 26;
 let result='#';for(const letter of hanLetters){if(collation.compare(first,'\uFDD0'+letter)<0)break;result=letter;}
 return alphabet.indexOf(result);
}
function trackOrder(x,y,entries){
  const a=entries.get(x).data,b=entries.get(y).data;
  return (parseInt(a.track)||0)-(parseInt(b.track)||0)||collation.compare(a.path,b.path);
 }
function buildNativeIndex(tracks,albums,lists,mediaSections){
 const encoder=new TextEncoder(),strings=[new Uint8Array(1)],offsets=new Map([['',0]]);
 let textBytes=1;
 function intern(value){
  const s=String(value||'');if(offsets.has(s))return offsets.get(s);
  const bytes=encoder.encode(s+'\0'),pos=textBytes;strings.push(bytes);textBytes+=bytes.length;offsets.set(s,pos);return pos;
 }
 const records=[],groups=[],members=[],indices=new Map(),artists=new Map();
 for(const [key,{data:t}] of tracks){
  const v={...t,...t.overrides};indices.set(key,records.length/4);
  records.push(intern(v.path),intern(v.title),intern(v.artist),intern(v.album));
  if(mediaSections)continue;
  const name=v.artist||'未知艺人';if(!artists.has(name))artists.set(name,[]);artists.get(name).push(key);
 }
 const albumRows=[...albums.values()].map(a=>({name:a.decision?.selected?.album||a.name,sub:a.decision?.selected?.artist||a.artist,ids:[...a.ids].sort((a,b)=>trackOrder(a,b,tracks))}));
 const artistRows=[...artists].map(([name,ids])=>({name,sub:ids.length+' 首',ids}));
 const listRows=lists.map(l=>({name:l.name,sub:l.ids.length+' 首',ids:l.ids,cover:l.cover}));
 const jumps=[],counts=[];
 for(const entries of mediaSections||[albumRows,artistRows,listRows]){
  const positions=Array(27).fill(0xffffffff);
  const rows=entries.map(row=>({...row,letter:initialOf(row.name)})).sort((a,b)=>a.letter-b.letter||collation.compare(a.name,b.name));
  let count=0;
  for(const row of rows){
   const ids=row.ids.filter(key=>indices.has(key));if(!ids.length)continue;
   if(positions[row.letter]===0xffffffff)positions[row.letter]=count;
   groups.push(intern(row.name),intern(row.sub),indices.get(row.cover)??indices.get(ids[0]),members.length,ids.length);
   for(const id of ids)members.push(indices.get(id));
   count++;
  }
  counts.push(count);jumps.push(...positions);
 }
 const head=48, jumpBytes=81*4, trackAt=head+jumpBytes,groupAt=trackAt+records.length*4;
 const memberAt=groupAt+groups.length*4,textAt=memberAt+members.length*4;
 const bytes=new Uint8Array(textAt+textBytes),view=new DataView(bytes.buffer);
 function words(pos,values){for(const n of values){view.setUint32(pos,n,true);pos+=4;}}
 words(0,[0x314c4d4e,bytes.length,records.length/4,...counts,trackAt,groupAt,memberAt,textAt,members.length,1]);
 words(head,jumps);words(trackAt,records);words(groupAt,groups);words(memberAt,members);
 let pos=textAt;for(const b of strings){bytes.set(b,pos);pos+=b.length;}return bytes;
}
async function publishNative(gen){
 await gate(gen);
 const {lists}=await readPlaylists(),bytes=buildNativeIndex(tracks,albums,lists);
 return publishIndexBytes(bytes,'0000000000000001',()=>gate(gen));
}
async function publishIndexBytes(bytes,key,checkpoint){
 if(bytes.length>32*1024*1024)throw Error('资料库索引超过单次传输限额');
 let a=0x811c9dc5,b=0x9e3779b9;
 for(const n of bytes){a=Math.imul(a^n,0x01000193);b=Math.imul(b^n,0x5bd1e995);}
 const id=[a,b].map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
 const old=await request('music',{op:'get',key});
 if(old.value===id)return;
 await checkpoint();
 const r=await fetch('/api/v1/files/upload?dir=catalog&name='+id+'.nml',{method:'POST',headers:{'Content-Type':'application/octet-stream',...(secret?{Authorization:'Bearer '+secret}:{})},body:bytes,signal:AbortSignal.timeout(120000)});
 if(!r.ok&&r.status!==409)throw Error('设备资料库索引写入失败（'+r.status+'）');
 if(r.status===409){const exists=await fetch('/api/v1/files/download?dir=catalog&name='+id+'.nml',{headers:secret?{Authorization:'Bearer '+secret}:{}});if(!exists.ok)throw Error('索引文件未就绪');const check=new Uint8Array(await exists.arrayBuffer());if(check.length!==bytes.length||!check.every((x,i)=>x===bytes[i]))throw Error('索引文件校验失败');}
 await checkpoint();await request('music',{op:'put',key,rev:old.rev,value:id});
}

// The header is the commit point. A failed or competing write leaves its old pages readable.
async function readPlaylists(){
 const old=await doc(LISTS),lists=[];
 for(const h of old.value||[]){
  const ids=[];
  for(const key of h.pages){const page=(await doc(key)).value;if(!Array.isArray(page))throw Error('播放列表资料不完整');ids.push(...page);}
  lists.push({name:h.name,ids,cover:h.cover||''});
 }
 return {old,lists};
}
function playlistArt(list){
 return list.cover&&tracks.has(list.cover)&&list.ids.includes(list.cover)?list.cover:list.ids.find(k=>tracks.has(k));
}
async function writePlaylists(old,lists){
 const headers=[];
 for(const list of lists){
  const pages=[];
  for(let i=0;i<list.ids.length;i+=192){
   const members=list.ids.slice(i,i+192),key=keyFor('playlist:'+members.join(','));
   const previous=await doc(key);
   if(!previous.value)await put(key,0,members);
   else if(JSON.stringify(previous.value)!==JSON.stringify(members))throw Error('播放列表索引冲突');
   pages.push(key);
  }
  headers.push({name:list.name,pages,...(list.cover?{cover:list.cover}:{})});
 }
 await put(LISTS,old.rev,headers);
}
async function removeTrackFromPlaylists(id){
 for(let attempt=0;;attempt++){
  const {old,lists}=await readPlaylists();
  const affected=lists.filter(list=>list.ids.includes(id));
  if(!affected.length)return;
  for(const list of affected){
   list.ids=list.ids.filter(key=>key!==id);
   if(list.cover===id)list.cover='';
  }
  try{await writePlaylists(old,lists);return;}
  catch(error){if(error.status!==409||attempt>=2)throw error;}
 }
}
async function listCommand(m){
 const {old,lists}=await readPlaylists(),name=String(m.name||'').trim();
 let list=lists.find(l=>l.name===name);
 if(m.cmd==='lists'){postMessage({type:'lists',names:lists.map(l=>l.name),trackToAdd:m.trackToAdd||'',album:m.album||''});return;}
 if(m.album){
  const album=albums.get(m.album);
  if(!album||!album.ids.length||!musicInventoryReady)throw Error('曲目仍在读取，完成后可整张加入');
  if(m.create?list:!list)throw Error(m.create?'此播放列表名称已使用':'播放列表已变化');
  if(!name||new TextEncoder().encode(name).length>96)throw Error('请输入有效的播放列表名称');
  const present=new Set(list?.ids),all=[...new Set(album.ids)].sort((a,b)=>trackOrder(a,b,tracks)),add=all.filter(k=>!present.has(k));
  const token=keyFor(JSON.stringify([m.album,name,old.rev,all,add]));
  if(m.cmd==='list-preview'||m.confirm!==token){
   postMessage({type:'list-preview',album:m.album,title:album.name,name,create:!!m.create,add:add.length,existing:all.length-add.length,token});return;
  }
  if(!add.length)return;
  if(!list){list={name,ids:[],cover:''};lists.push(list);}
  list.ids.push(...add);
 }else if(m.cmd==='list-edit'){
  if(m.op==='create'){
   if(!name||new TextEncoder().encode(name).length>96||list)throw Error('名称为空、过长或已使用');
   if(m.track&&!tracks.has(m.track))throw Error('未找到歌曲');
   list={name,ids:m.track?[m.track]:[],cover:''};lists.push(list);
  }else{
   if(!list)throw Error('播放列表已变化');
   const i=list.ids.indexOf(m.track);
   if(m.op==='append'){
    if(!tracks.has(m.track))throw Error('未找到歌曲');if(i<0)list.ids.push(m.track);
   }else if(i<0)throw Error('这首歌已不在播放列表中');
   else if(m.op==='remove'){list.ids.splice(i,1);if(list.cover===m.track)list.cover='';}
   else if(m.op==='cover'){
    if(!tracks.has(m.track))throw Error('歌曲文件暂不可用');
    await ensurePlaylistThumb(m.track);list.cover=m.track;
   }else if(['move','up','down'].includes(m.op)){
    const target=m.op==='move'?(m.anchor?list.ids.indexOf(m.anchor):m.index):i+(m.op==='up'?-1:1);
    if(!Number.isInteger(target)||target<0||target>=list.ids.length)throw Error('目标位置已变化');
    list.ids.splice(i,1);list.ids.splice(target,0,m.track);
   }else throw Error('未知的播放列表操作');
  }
 }
 if(m.cmd==='list-edit'){
  await writePlaylists(old,lists);
  if(running)rescan=true;
  else await publishNative(serial);
  postMessage({type:'playlist-saved',name,inline:!!m.inline,album:!!m.album});
 }
 if(!list)return;
 const offset=Math.max(0,Math.min(m.offset||0,Math.floor(Math.max(0,list.ids.length-1)/24)*24));
 postMessage({type:'list',name,offset,total:list.ids.length,cover:playlistArt(list),rows:list.ids.slice(offset,offset+24).map(key=>{
  const t=tracks.get(key)?.data;return {key,title:t?.overrides?.title||t?.title||'文件暂不可用'};
 })});
}

'use strict';
const fields=['title','artist','album','albumArtist','track'];
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const ascii=b=>String.fromCharCode(...b);
let throttled=false,providerBackoff=0;
let secret='', wasm, roots=[], running=false, suspended=false, rescan=false, nextLookup=0, serial=0;
const albums=new Map(), tracks=new Map();
const ROOTS='0000000000000000',LISTS='0000000000000002';
function keyFor(text) {
 let hash=0xcbf29ce484222325n;
 for(const byte of new TextEncoder().encode(text))hash=BigInt.asUintN(64,(hash^BigInt(byte))*0x100000001b3n);
 return hash.toString(16).padStart(16,'0');
}
async function request(route,args,binary=false){
 const r=await fetch('/api/v1/'+route,{method:'POST',headers:{'Content-Type':'application/json',...(secret?{Authorization:'Bearer '+secret}:{})},body:JSON.stringify(args),signal:AbortSignal.timeout(12000)});
 if(r.status===401)postMessage({type:'auth'});
 if(!r.ok){
  const detail=await r.json().catch(()=>null);
  const error=new Error(detail?.error?.message||(r.status===401?'管理会话已结束，请重新连接':'资料库请求失败（'+r.status+'）'));error.status=r.status;throw error;
 }
 return binary?new Uint8Array(await r.arrayBuffer()):r.json();
}
async function doc(key){const r=await request('music',{op:'get',key});return {rev:r.rev,value:r.value?JSON.parse(r.value):null};}
async function put(key,rev,value){
 const encoded=JSON.stringify(value);
 try{return await request('music',{op:'put',key,rev,value:encoded});}
 catch(e){if(e.status!==409)throw e;const current=await request('music',{op:'get',key});if(current.value===encoded)return current;throw e;}
}
function pauseCheck(gen){if(gen!==serial)throw new Error('扫描已取消');}
async function gate(gen){
 while(suspended){pauseCheck(gen);await wait(300);}
 if(throttled)await wait(65);
 pauseCheck(gen);
}
async function bytes(path,offset,n,gen){
 if(n>65536)throw Error('标签超过读取预算');
 const data=new Uint8Array(n);let used=0;
 while(used<n){await gate(gen);const chunk=await request('music',{op:'slice',key:path,offset:offset+used,bytes:Math.min(8192,n-used)},true);data.set(chunk,used);used+=chunk.length;if(!chunk.length)break;}
 return data.subarray(0,used);
}
function decode(raw,marker){
 let charset=['windows-1252','utf-16','utf-16be','utf-8'][marker]||'utf-8';
 if(marker===1&&raw[0]===0xfe&&raw[1]===0xff)charset='utf-16be';
 const trim=s=>s.replace(/\0+$/g,'').replaceAll('\0',' / ').trim().slice(0,160);
 const original=trim(new TextDecoder(charset).decode(raw));
 let suggestions=[];
 if((marker===0||original.includes('\uFFFD'))&&raw.some(b=>b>=128)){
  for(const label of ['utf-8','gb18030','big5']){
   try {const text=trim(new TextDecoder(label,{fatal:true}).decode(raw));if(text&&text!==original&&!suggestions.some(s=>s.text===text))suggestions.push({label,text});}catch{}
  }
 }
 return {original,suggestions};
}
async function tags(path,size,gen){
 const head=await bytes(path,0,Math.min(10,size),gen);let version=0,block;
 if(ascii(head.subarray(0,4))==='fLaC'){
  let pos=4;
  for(let i=0;i<128&&pos+4<=size;i++){
   const h=await bytes(path,pos,4,gen);if(h.length!==4)break;
   const n=h[1]*65536+h[2]*256+h[3];pos+=4;if(pos+n>size)break;
   if((h[0]&127)===4){if(n>65536)return {note:'标签过大，待手动核对'};block=await bytes(path,pos,n,gen);break;}
   if(h[0]&128)break;pos+=n;
  }
 }else if(head.length===10&&ascii(head.subarray(0,3))==='ID3'&&[3,4].includes(head[3])&&!(head[5]&0xc0)){
  version=head[3];const n=head.slice(6,10).reduce((a,b)=>a*128+(b&127),0);block=await bytes(path,10,Math.min(n,65536,size-10),gen);
 }
 const result={suggestions:{}};
 if(ascii(head.subarray(0,4))==='fLaC'&&size>=42){
  const b=await bytes(path,18,8,gen);
  if(b.length===8){const rate=b[0]*4096+b[1]*16+(b[2]>>4),samples=(b[3]&15)*4294967296+b[4]*16777216+b[5]*65536+b[6]*256+b[7];if(rate&&samples)result.seconds=Math.round(samples/rate);}
 }else if(version&&block){
  const text=ascii(block.subarray(0,Math.min(4096,block.length)));const i=text.indexOf('TLEN');
  if(i>=0&&i+11<block.length){const b=block.subarray(i+11,i+25),ms=parseInt(ascii(b).replaceAll('\0',''));if(ms>0&&ms<86400000)result.seconds=Math.round(ms/1000);}
 }
 if(!block)return {...result,note:'缺少可读取的标签'};
 new Uint8Array(wasm.memory.buffer,wasm.buffer(),block.length).set(block);
 fields.forEach((field,i)=>{
  const span=wasm.span(block.length,version,i)>>>0;if(!span)return;
  const start=span>>>16,b=block.subarray(start,start+(span&65535));
  const v=decode(version?b.subarray(1):b,version?b[0]:3);
  result[field]=v.original;if(v.suggestions.length)result.suggestions[field]=v.suggestions;
 });
 return result;
}
let progressDone=0,progressGoal=0,progressStart=0;
let statusText='就绪', total=0, lastUpdate=0, failed=0, errorDetail='';
function publish(force=false){
 if(!force&&Date.now()-lastUpdate<350)return;lastUpdate=Date.now();
 postMessage({type:'status',roots,running,statusText,total,failed,errorDetail,progressDone,progressGoal,progressStart,albums:albums.size});
}
function normalized(t){return String(t||'').normalize('NFKC').trim().toLowerCase();}
async function lookup(album,artist,gen){
 if(Date.now()<providerBackoff)throw Error("在线资料源稍后重试");
 const q=s=>'"'+s.replace(/([+\-&|!(){}\[\]^"~*?:\\/])/g,'\\$1')+'"';
 const query='release:'+q(album)+(artist?' AND artist:'+q(artist):'');
 await wait(Math.max(0,nextLookup-Date.now()));await gate(gen);nextLookup=Date.now()+1200;
 const url=new URL('https://musicbrainz.org/ws/2/release/');url.search=new URLSearchParams({query,fmt:'json',limit:'5'});
 let r;try{r=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(9000)});}catch(e){providerBackoff=Date.now()+60000;throw e;}
 if(!r.ok){providerBackoff=Date.now()+Math.max(60000,1000*(Number(r.headers.get('retry-after'))||0));throw Error('在线资料源暂不可用');}
 const data=await r.json();
 return {count:data.count, options:(data.releases||[]).map(v=>({id:v.id,album:v.title,artist:(v['artist-credit']||[]).map(a=>(a.name||a.artist?.name||'')+(a.joinphrase||'')).join(''),date:v.date||'',country:v.country||'',count:v['track-count']||0})).filter(x=>/^[0-9a-f-]{36}$/i.test(x.id))};
}
function groupId(t){return JSON.stringify([t.dir,normalized(t.album||t.dir.split('/').pop()),normalized(t.albumArtist||'')]);}
let musicInventoryReady=false;
async function scan(gen,force){
 musicInventoryReady=false;
 total=failed=0;errorDetail='';albums.clear();tracks.clear();progressDone=progressGoal=0;
 statusText='正在统计歌曲';publish(true);
 const sidecars=[];
 const files=await mediaFiles(roots,/\.(flac|mp3|wav|aac)$/i,()=>gate(gen),sidecars);
 statusText='载入资料库';progressStart=Date.now();progressGoal=files.length;publish(true);
 for(const {entry,dir,path} of files){
    await gate(gen);
    const key=keyFor('track:'+path),old=await doc(key);let t=old.value;
    if(t&&t.path!==path)throw Error('曲目索引冲突');
    const readTags=force||!t||!t.durationChecked||t.size!==entry.bytes||t.modified!==entry.modified;
    if(readTags){
     statusText='读取本地标签';
     const info=await tags(path,entry.bytes,gen);
     t={...info,...t?.imported,imported:t?.imported,path,dir,size:entry.bytes,modified:entry.modified,title:t?.imported?.title||info.title||entry.name.replace(/\.[^.]+$/,''),durationChecked:true,addedAt:t?.addedAt||Date.now(),overrides:t?.overrides||{}};
     }
    if(readTags||t.tagEncodingVersion!==1||!t.addedAt){
     t.addedAt=t.addedAt||Date.now();
     t=repairTagEncoding(t);
     await gate(gen);const saved=await put(key,old.rev,t);old.rev=saved.rev;
    }
    const view={...t,...t.overrides};const group=groupId(view);
    if(!albums.has(group))albums.set(group,{name:view.album||dir.split('/').pop(),artist:view.albumArtist||view.artist||'',ids:[],decision:null});
    albums.get(group).ids.push(key);tracks.set(key,{rev:old.rev,data:t});total++;progressDone++;publish();
 }
 musicInventoryReady=true;postMessage({type:"local-music-ready"});
 await prepareDeviceCovers(gen,force,sidecars);
 progressStart=Date.now();progressDone=0;progressGoal=albums.size;statusText="核对专辑";publish(true);
 for(const [id,album] of albums){
  await gate(gen);const k=keyFor('album:'+id);const stored=await doc(k);
  if(stored.value&&stored.value.id!==id)throw Error('专辑索引冲突');
  album.rev=stored.rev;album.decision=stored.value;
  if(!album.decision||(!album.decision.selected&&album.decision.retryAt&&Date.now()>=album.decision.retryAt)){
   let options=[],selected=null,retryAt=0;
   statusText='匹配专辑 · '+album.name;publish();
   try{
    const matches=await lookup(album.name,album.artist,gen);options=matches.options;
    if(matches.count===1&&options.length===1&&album.artist&&normalized(options[0].album)===normalized(album.name)&&normalized(options[0].artist)===normalized(album.artist)&&options[0].count===album.ids.length)selected=options[0];
   }catch(e){retryAt=Date.now()+300000;failed++;errorDetail='在线查询失败，本地标签已保留';}
   await gate(gen);const value={id,options,selected,retryAt};album.rev=(await put(k,album.rev,value)).rev;album.decision=value;
  }
  progressDone++;publish();
 }
 await publishNative(gen);statusText='整理完成';publish(true);
}
async function start(force=false){
 if(running){rescan=true;return;}
 running=true;const gen=serial;
 try{for(let i=0;;i++){try{await scan(gen,force);break;}catch(e){if(e.status!==409||i===2||gen!==serial)throw e;await wait(650+Math.random()*750);force=false;}}}catch(e){if(gen===serial){statusText='整理中断';errorDetail=e.message;}}finally{running=false;publish(true);if(rescan){rescan=false;start();}}
}
function page(entries,offset){return entries.slice(offset,offset+24);}
async function command(m){
 switch(m.cmd){
 case 'list-preview':case 'list':case 'lists':case 'list-edit':await listCommand(m);break;
 case 'init':
  secret=m.key;
  wasm=(await WebAssembly.instantiate(Uint8Array.from(atob(WASM_BASE64),c=>c.charCodeAt(0)))).instance.exports;
  roots=(await doc(ROOTS)).value||[];publish(true);postMessage({type:"initialized"});if(roots.length&&m.scanMusic)start();break;
 case 'key':secret=m.key;break;
 case 'throttle':throttled=m.value;break;
 case 'pause':suspended=m.value;break;
 case 'scan':await start(m.force);break;
 case 'music-file-deleted':{
  const id=keyFor('track:'+m.path);
  try{await removeTrackFromPlaylists(id);}finally{await start(false);}
  break;
 }
 case 'music-import':{
  for(const [path,imported] of Object.entries(m.imports||{})){
   const key=keyFor('track:'+path),record=await doc(key);
   await put(key,record.rev,{...record.value,...imported,imported,path});
  }
  const old=await doc(ROOTS);roots=old.value||[];
  if(!roots.includes('music')){roots=['music',...roots.filter(p=>!p.startsWith('music/'))];await put(ROOTS,old.rev,roots);serial++;}
  await start();break;}
 case 'browse-music':await browseClient(m);break;
 case 'cover-page':await coverPage(m);break;
 case 'media-refresh':case 'media-browse':case 'media-upload':case 'media-roots':case 'media-key':await mediaCommand(m);break;
 case 'roots':{
  const old=await doc(ROOTS);let next=old.value||[];const path=m.path;
  if(m.remove)next=next.filter(x=>x!==path);
  else if(next.some(x=>path===x||path.startsWith(x+'/')))throw Error('已由现有目录管理');
  else next=[...next.filter(x=>!x.startsWith(path+'/')),path];
  await put(ROOTS,old.rev,next);roots=next;serial++;await start();break;}
 case 'albums':{
  const rows=[...albums].map(([id,a])=>({id,name:a.name,artist:a.artist,count:a.ids.length,matched:!!a.decision?.selected}));
  postMessage({type:'albums',offset:m.offset,total:rows.length,rows:page(rows,m.offset)});break;}
 case 'album':{const a=albums.get(m.id);
  if(!a){if(musicInventoryReady)postMessage({type:'album-missing',id:m.id});return;}
  const offset=Math.min(m.offset||0,24*Math.floor(Math.max(0,a.ids.length-1)/24));
  postMessage({type:'album',id:m.id,name:a.name,decision:a.decision,offset,total:a.ids.length,rows:page(a.ids,offset).map(key=>({key,...tracks.get(key).data}))});break;}
 case 'edition':{
  const a=albums.get(m.id),candidate=a?.decision?.options.find(c=>c.id===m.mbid);if(!candidate)throw Error('候选版本已变化');
  const value={...a.decision,selected:candidate,retryAt:0};a.rev=(await put(keyFor('album:'+m.id),a.rev,value)).rev;a.decision=value;if(running)rescan=true;else await publishNative(serial);await command({cmd:'album',id:m.id,offset:0});break;}
 case 'correct':{
  const t=tracks.get(m.key);if(!t||!t.data.suggestions?.[m.field]?.some(x=>x.text===m.value))throw Error('编码候选已变化');
  const value={...t.data,overrides:{...t.data.overrides,[m.field]:m.value}};t.rev=(await put(m.key,t.rev,value)).rev;t.data=value;await start();break;}
 }
}
self.onmessage=({data})=>command(data).catch(e=>postMessage({type:'error',message:e.message}));

const mediaKinds={
 books:{root:'txt',legacy:'nanoos/books',extensions:/(?:\.txt$|^pages\.nbp$)/i,upload:'reads'},
 video:{root:'mjpeg',legacy:'nanoos/videos',extensions:/\.(?:mp4|avi|mjpg|mjpeg|mkv|mov|m4v|webm|wmv|ts|m2ts|mpg|mpeg|vob|flv|asf|3gp|mts|vob|iso)$/i,upload:'movies'}
};
const mediaMaps={books:new Map(),video:new Map()}, mediaQueues={books:Promise.resolve(),video:Promise.resolve()};
let mediaReady;
async function mediaFiles(roots,extensions,checkpoint,sidecars){
 const dirs=[...roots],seen=new Set(),files=[];
 while(dirs.length){
  await checkpoint();const dir=dirs.pop(),identity=dir.toLowerCase();if(seen.has(identity))continue;seen.add(identity);
  let cursor=0;
  do{
   await checkpoint();const page=await request('file-manager',{operation:'list',source:dir,cursor});
   for(const entry of page.entries){const path=dir+'/'+entry.name;if(entry.directory)dirs.push(path);
    else if(extensions.test(entry.name)&&(entry.name!=='pages.nbp'||dir.endsWith('.nbook')))files.push({entry,dir,path});
    else if(sidecars&&/^(cover|folder|front)\.(jpe?g|png)$/i.test(entry.name))sidecars.push([path,entry.bytes,entry.modified]);}
   const next=page.next_cursor||0;if(next&&next<=cursor)throw Error('目录游标无效');cursor=next;
  }while(cursor);
 }return files;
}
function bookText(raw){
 if(raw[0]===0xff&&raw[1]===0xfe)return new TextDecoder('utf-16le').decode(raw);
 if(raw[0]===0xfe&&raw[1]===0xff)return new TextDecoder('utf-16be').decode(raw);
 try{return new TextDecoder('utf-8',{fatal:true}).decode(raw,{stream:true});}
 catch{return new TextDecoder('gb18030').decode(raw,{stream:true});}
}
function readMediaTags(raw,kind){
 if(kind===0)raw=new TextEncoder().encode(bookText(raw)).subarray(0,65000);
 new Uint8Array(wasm.memory.buffer,wasm.buffer(),raw.length).set(raw);
 const tags={};
 for(const [i,key] of ['title','creator','category'].entries()){
  const span=wasm.media_span(raw.length,kind,i)>>>0;
  if(span){const text=raw.subarray(span>>>16,(span>>>16)+(span&65535));tags[key]=bookText(text).replace(/\0/g,'').trim().slice(0,160);}
 }return tags;
}
async function mediaGate(){
 while(suspended)await wait(300);
 if(throttled)await wait(65);
}
async function mediaSlice(path,offset,size){
 const data=new Uint8Array(size);let at=0;
 while(at<size){await mediaGate();const n=Math.min(8192,size-at),r=await request('music',{op:'slice',key:path,offset:offset+at,bytes:n},true);data.set(r,at);at+=r.length;if(r.length<n)break;}
 return data.subarray(0,at);
}
async function rootState(kind){return doc(keyFor('managed-roots:'+kind));}
async function publishMediaIndex(kind,items){
 const books=kind==='books', entries=new Map(), groups=[new Map(),new Map(),new Map()];
 for(const [path,item] of items){
  if(!books&&(item.imported?.devicePlayable==='no'||!(/\.(mp4|avi|mjpg|mjpeg)$/i.test(path))))continue;
  entries.set(path,{data:{path,title:item.title,artist:item.creator,album:item.category}});
  const directory=path.split('/').slice(0,-1).join('/');
  const collection=item.series||item.collection||directory;
  const labels=[item.category||'未分类',item.creator||(books?'未知作者':'未知创作者'),collection];
  labels.forEach((name,i)=>{
   if(!groups[i].has(name))groups[i].set(name,[]);
   groups[i].get(name).push(path);
  });
 }
 const sections=groups.map(g=>[...g].map(([name,ids])=>{
  ids.sort((a,b)=>collation.compare(items.get(a).title,items.get(b).title));
  return {name,sub:ids.length+(books?' 本':' 部'),ids};
 }));
 const bytes=buildNativeIndex(entries,new Map(),[],sections);
 await publishIndexBytes(bytes,books?'626f6f6b69647831':'766964656f696478',mediaGate);
}
async function scanMedia(m){
 const kind=m.kind,settings=mediaKinds[kind],map=mediaMaps[kind],started=Date.now();
 let done=0,goal=0,status='统计文件',last=0;
 const tell=(running,force=false,error='')=>{if(!force&&Date.now()-last<300)return;last=Date.now();postMessage({type:'media-job',kind,running,status,done,goal,started,error});};
 tell(true,true);
 try{
  await mediaGate();
  const old=await rootState(kind), managed=old.value||[settings.root];
  if(m.cmd==='media-roots'){
   const roots=m.remove?managed.filter(p=>p!==m.path):[...new Set([...managed,m.path])];
   await put(keyFor('managed-roots:'+kind),old.rev,roots);managed.splice(0,managed.length,...roots);
  }
  if(m.cmd==='media-upload'&&!managed.includes(settings.root)){managed.push(settings.root);await put(keyFor('managed-roots:'+kind),old.rev,managed);}
  postMessage({type:'media-directories',kind,roots:managed});
  const files=await mediaFiles(managed,settings.extensions,mediaGate);goal=files.length;status='读取元信息';tell(true,true);
  const next=new Map();
  for(const {entry,path,dir} of files){
   await mediaGate();const key=keyFor(kind+':'+path),record=await doc(key);let item=record.value;
   if(item&&item.path!==path)throw Error('索引冲突');
   const supplied=m.imports?.[path];
   if(!item||item.size!==entry.bytes||item.modified!==entry.modified||supplied||m.force){
    const format=kind==='books'?0:/\.avi$/i.test(path)?1:/\.mp4$/i.test(path)?2:3;
    let tags={};if(format<3&&entry.name!=='pages.nbp'){
     const length=Math.min(entry.bytes,kind==='books'?8192:32768);
     tags=readMediaTags(await mediaSlice(path,0,length),format);
     if(format===2&&entry.bytes>length&&!tags.title)tags={...readMediaTags(await mediaSlice(path,entry.bytes-length,length),format),...tags};
    }
    const clean=entry.name==='pages.nbp'?dir.split('/').pop().replace(/\.nbook$/,''):entry.name.replace(/\.[^.]+$/,'');
    const inferredCategory=managed.includes(dir)?'未分类':dir.split('/').pop();
    item={title:tags.title||clean,creator:tags.creator||'',category:tags.category||inferredCategory,imported:supplied||item?.imported||{},path,size:entry.bytes,modified:entry.modified};
    Object.assign(item,item.imported);await put(key,record.rev,item);
   }
   next.set(path,item);done++;tell(true);
  }
  status='更新设备索引';tell(true,true);await publishMediaIndex(kind,next);
  map.clear();for(const [key,item] of next)map.set(key,item);
  status='整理完成';tell(false,true);postMessage({type:'media-updated',kind});
 }catch(e){status='整理中断';tell(false,true,e.message);}
}
async function mediaCommand(m){
 if(!mediaKinds[m.kind])return;
 if(m.cmd==='media-browse'){
  const data=[...mediaMaps[m.kind].values()],unknown='未知';
  const values=field=>[...new Set(data.map(e=>e[field]||unknown))].sort(collation.compare);
  const facets={category:values('category'),creator:values('creator')};
  const query=(m.query||'').normalize('NFKC').toLocaleLowerCase();
  const all=data.filter(e=>(!m.category||(e.category||unknown)===m.category)&&(!m.creator||(e.creator||unknown)===m.creator)&&
    (!query||[e.title,e.creator,e.category].some(s=>(s||'').normalize('NFKC').toLocaleLowerCase().includes(query))));
  let rows;
  if(m.field&&!m.filter){
   const groups=new Map();for(const entry of all){const label=entry[m.field]||'未知';groups.set(label,(groups.get(label)||0)+1);}
   rows=[...groups].map(([title,n])=>({title,sub:n+(m.kind==='books'?' 本':' 部'),group:title}));
  }else rows=all.filter(e=>!m.filter||(e[m.field]||'未知')===m.filter).map(e=>({title:e.title,sub:[e.creator,e.category].filter(Boolean).join(' · '),path:e.path,size:e.size,creator:e.creator,category:e.category,added:e.imported?.importedAt||0,original:e.imported?.sourceFormat==='original',unplayable:m.kind==='video'&&(e.imported?.devicePlayable==='no'||!(/\.(mp4|avi|mjpg|mjpeg)$/i.test(e.path))),coverAsset:e.imported?.coverAsset}));
  rows.sort((a,b)=>(b.added||0)-(a.added||0)||collation.compare(a.title,b.title));postMessage({type:'media-page',facets,request:m.request,kind:m.kind,tab:m.tab,filter:m.filter||'',offset:m.offset,total:rows.length,rows:page(rows,m.offset)});return;
 }
 mediaQueues[m.kind]=mediaQueues[m.kind].then(()=>scanMedia(m));await mediaQueues[m.kind];
}

const coverCache=new Map(),sidecarDirs=new Map();let artGeneration=0,artChain=Promise.resolve();
const matchString=(s,q)=>!q||String(s||'').toLocaleLowerCase().includes(q);
const effectiveTrack=key=>{const t=tracks.get(key)?.data;return t?{...t,...t.overrides,key}:null;};
const songRow=t=>({title:t.title,sub:t.artist||'未知艺人',album:t.album||t.dir.split('/').pop(),format:t.path.split('.').pop().toUpperCase(),path:t.path,key:t.key,track:parseInt(t.track)||0,seconds:t.seconds||0});
async function browseClient(m){
 const q=(m.query||'').toLowerCase(),tab=m.tab;let rows=[],detail=null;
 const albumRow=([id,a])=>{const t=effectiveTrack(a.ids[0]);return {title:a.name,sub:a.artist||'未知艺人',id,count:a.ids.length,artKey:t?.key,added:a.added||t?.addedAt||0};};
 if(tab==='艺人'){
  const byName=new Map();for(const [id,a] of albums)for(const key of a.ids){
   const t=effectiveTrack(key),artist=t.artist||'未知艺人';
   if(!byName.has(artist))byName.set(artist,{title:artist,count:0,artKey:key,groups:new Set()});
   const entry=byName.get(artist);entry.count++;entry.groups.add(id);
  }
  rows=[...byName.values()].filter(a=>matchString(a.title,q)).sort((a,b)=>collation.compare(a.title,b.title));
  const current=byName.get(m.artist)||rows[0];
  if(current){const all=[...current.groups].map(id=>albumRow([id,albums.get(id)]));
   const chosen=all.find(a=>a.id===m.album)||all[0];const songIds=albums.get(chosen.id).ids.filter(k=>(effectiveTrack(k).artist||'未知艺人')===current.title);
   detail={title:current.title,count:current.count,albums:all.length,choices:all.slice(m.groupOffset||0,(m.groupOffset||0)+24),selected:chosen,rows:songIds.slice(m.detailOffset||0,(m.detailOffset||0)+24).map(k=>songRow(effectiveTrack(k))),length:songIds.length};
  }
  rows=rows.map(({title,count,artKey})=>({title,count,artKey,artist:title}));
 }else if(tab==='专辑'||tab==='最近添加'){
  rows=[...albums].map(albumRow).filter(a=>matchString(a.title+' '+a.sub,q)).sort((a,b)=>tab==='最近添加'?b.added-a.added||collation.compare(a.title,b.title):collation.compare(a.title,b.title));
 }else if(tab==='播放列表'){
  const {lists}=await readPlaylists();rows=lists.filter(l=>matchString(l.name,q)).map(l=>({title:l.name,list:l.name,count:l.ids.length,artKey:playlistArt(l)}));
  const selected=lists.find(l=>l.name===m.list);if(selected){const offset=m.detailOffset||0;detail={title:selected.name,length:selected.ids.length,rows:selected.ids.slice(offset,offset+24).map(key=>{const t=effectiveTrack(key);return t?songRow(t):{key,title:'文件暂不可用'};}),artKey:playlistArt(selected)};}
 }else{
  rows=[...tracks.keys()].map(effectiveTrack).filter(t=>matchString(t.title+' '+(t.artist||'')+' '+(t.album||''),q)).map(songRow);
  rows.sort((a,b)=>collation.compare(a[m.sort||'title']||'',b[m.sort||'title']||''));
 }
 postMessage({type:'music-page',tab,request:m.request,offset:m.offset,total:rows.length,rows:page(rows,m.offset),detail});
}
async function artBytes(path,offset,bytes){
 const buffer=new Uint8Array(bytes);let done=0;
 while(done<bytes){await mediaGate();const n=Math.min(131072,bytes-done);const chunk=await request('music',{op:'slice',key:path,offset:offset+done,bytes:n},true);buffer.set(chunk,done);done+=chunk.length;if(chunk.length<n)break;}
 return buffer.subarray(0,done);
}
const be32=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p);
async function picture(t,device=false){
 const path=t.path,size=t.size,h=await artBytes(path,0,Math.min(10,size));
 let pos=0,payload=null;
 if(ascii(h.subarray(0,4))==='fLaC'){
  pos=4;for(let i=0;i<128&&pos+4<=size;i++){
   const b=await artBytes(path,pos,4),len=b[1]*65536+b[2]*256+b[3];pos+=4;if(pos+len>size)break;
   if((b[0]&127)===6&&len>=32&&len<=2*1024*1024){
    const head=await artBytes(path,pos,Math.min(len,4096));
    if(head.length>=12){const mime=be32(head,4);if(12+mime<=head.length){const desc=be32(head,8+mime),at=32+mime+desc;
     if(at<=head.length&&at<=len){const n=be32(head,at-4);if(n&&n<=len-at)payload=await artBytes(path,pos+at,n);}}}
    if(payload)break;
   }
   if(b[0]&128)break;pos+=len;
  }
 }else if(h.length===10&&ascii(h.subarray(0,3))==='ID3'&&[3,4].includes(h[3])&&!(h[5]&0xc0)){
  const end=Math.min(size,10+h.subarray(6).reduce((a,b)=>128*a+b,0));pos=10;
  for(let i=0;i<160&&pos+10<=end;i++){
   const frame=await artBytes(path,pos,10);if(frame.length<10||!frame[0])break;
   const len=h[3]===3?be32(frame,4):frame.subarray(4,8).reduce((a,b)=>a*128+b,0);pos+=10;if(!len||pos+len>end)break;
   if(ascii(frame.subarray(0,4))==='APIC'&&len<=2*1024*1024){
    const raw=await artBytes(path,pos,len);let off=raw.indexOf(0,1)+2;if(off<3)break;
    if(raw[0]===1||raw[0]===2){while(off+1<raw.length&&(raw[off]||raw[off+1]))off+=2;off+=2;}else{off=raw.indexOf(0,off)+1;}
    if(off>0&&off<raw.length)payload=raw.subarray(off);break;
   }pos+=len;
  }
 }
 if(!payload&&t.imported?.coverAsset){
  const response=await fetch('/api/v1/files/download?dir=catalog&name='+t.imported.coverAsset,{headers:secret?{Authorization:'Bearer '+secret}:{}});
  if(response.ok)payload=new Uint8Array(await response.arrayBuffer());
 }
 if(!payload){
  if(!sidecarDirs.has(t.dir)){
   const r=await mediaFilesIn(t.dir);sidecarDirs.set(t.dir,r.find(x=>/^(cover|folder|front)\.(jpg|jpeg|png)$/i.test(x.name)&&x.bytes<=2*1024*1024)||null);
  }
  const f=sidecarDirs.get(t.dir);if(f)payload=await artBytes(t.dir+'/'+f.name,0,f.bytes);
 }
 if(!payload?.length)return '';
 const bitmap=await createImageBitmap(new Blob([payload]));try{
  const side=device?160:220,canvas=new OffscreenCanvas(side,side),g=canvas.getContext('2d');
  const crop=Math.min(bitmap.width,bitmap.height);
  g.drawImage(bitmap,(bitmap.width-crop)/2,(bitmap.height-crop)/2,crop,crop,0,0,side,side);
  if(device){
   const rgba=g.getImageData(0,0,side,side).data,out=new Uint8Array(side*side*2);
   for(let i=0;i<side*side;i++){
    const p=i*4,rgb=(rgba[p]>>3)<<11|(rgba[p+1]>>2)<<5|(rgba[p+2]>>3);
    out[i*2]=rgb;out[i*2+1]=rgb>>8;
   }
   return out;
  }
  const blob=await canvas.convertToBlob({type:'image/jpeg',quality:.80});
  const data=new Uint8Array(await blob.arrayBuffer());return 'data:image/jpeg;base64,'+btoa(ascii(data));
 }finally{bitmap.close();}
}
async function mediaFilesIn(path){
 let cursor=0;const files=[];do{const r=await request('file-manager',{operation:'list',source:path,cursor});files.push(...r.entries.filter(x=>!x.directory));const next=r.next_cursor||0;if(next&&next<=cursor)break;cursor=next;}while(cursor);return files;
}
async function coverPage(m){
 const generation=++artGeneration;
 artChain=artChain.then(async()=>{for(const k of [...new Set(m.keys)].slice(0,50)){
  if(generation!==artGeneration)return;const t=effectiveTrack(k);if(!t)continue;
  const signature=k+'-'+t.size+'-'+t.modified;
  if(!coverCache.has(signature)){
   try{const data=await picture(t);if(coverCache.size>=56)coverCache.delete(coverCache.keys().next().value);coverCache.set(signature,data);}catch{continue;}
  }
  if(generation===artGeneration)postMessage({type:'cover',key:k,url:coverCache.get(signature)});
 }});return artChain;
}

async function prepareDeviceCovers(gen,force,sidecars){
 const representatives=new Set(),artistNames=new Set();
 for(const a of albums.values())representatives.add([...a.ids].sort((x,y)=>trackOrder(x,y,tracks))[0]);
 for(const [key,entry] of tracks){
  const artist=entry.data.overrides?.artist||entry.data.artist||'';
  if(!artistNames.has(artist)){artistNames.add(artist);representatives.add(key);}
 }
 const {lists}=await readPlaylists();for(const list of lists){const key=playlistArt(list);if(key)representatives.add(key);}
 const signatureKey=keyFor('device-covers-2'),last=await doc(signatureKey);
 const directoryStamps=new Map();
 for(const [path,size,time] of sidecars.sort()){const dir=path.slice(0,path.lastIndexOf('/'));directoryStamps.set(dir,(directoryStamps.get(dir)||'')+JSON.stringify([path,size,time]));}
 const stamps=new Map();
 for(const key of representatives){
  const t=effectiveTrack(key);stamps.set(key,JSON.stringify([t.path,t.size,t.modified,t.imported?.coverAsset||'',directoryStamps.get(t.dir)||'']));
 }
 const signature=keyFor(JSON.stringify([...stamps.values()].sort()));
 if(!force&&last.value===signature)return;
 let complete=true;
 sidecarDirs.clear();progressStart=Date.now();progressGoal=representatives.size;progressDone=0;statusText='准备设备封面';publish(true);
 for(const key of representatives){
  await gate(gen);const t=effectiveTrack(key),id=keyFor('thumb1:'+t.path+':'+t.size+':'+t.modified);
  const stateKey=keyFor('thumb-state:'+t.path),previous=await doc(stateKey);
  if(force||previous.value?.stamp!==stamps.get(key)){
   try{
    const raw=await picture(t,true);
    if(raw){
     await saveThumb(id,raw);
    }
    await put(stateKey,previous.rev,{id,stamp:stamps.get(key),found:!!raw});
   }catch{complete=false;errorDetail='部分封面未能整理，可在管理目录重新检查';}
  }
  progressDone++;publish();
 }
 if(complete&&last.value!==signature)await put(signatureKey,last.rev,signature);
}

async function saveThumb(id,raw){
const r=await fetch('/api/v1/files/upload?dir=catalog&name='+id+'.nct',{method:'POST',headers:{'Content-Type':'application/octet-stream',Authorization:'Bearer '+secret},body:raw,signal:AbortSignal.timeout(40000)});
     if(!r.ok&&r.status!==409)throw Error('封面未保存');
}
async function ensurePlaylistThumb(key){
 const t=effectiveTrack(key),raw=await picture(t,true);if(!raw)throw Error('这首歌没有可用封面，请选另一首');
 await saveThumb(keyFor('thumb1:'+t.path+':'+t.size+':'+t.modified),raw);
}

}else{
const worker=new Worker('/music.js');
let library={roots:[],running:false,total:0,albums:0,statusText:'读取中',errorDetail:''};
let lastThrottle=null,paused=false,lastGate=null,sheetType='',albumId='',workerKey=state.key;
const send=(cmd,args={})=>worker.postMessage({cmd,...args});
const inMusic=()=>state.route==='music';
const button=(text,action,value='',primary=false)=>'<button class="button '+(primary?'primary':'secondary')+'" data-library-action="'+esc(action)+'" data-value="'+esc(value)+'">'+esc(text)+'</button>';
function gateWorker(){
 if(workerKey!==state.key){workerKey=state.key;send('key',{key:workerKey});if(inMusic())send('scan');}
 const block=paused||!state.connected||state.needsKey||!state.status?.storage?.local_ready||state.status?.storage?.usb_owned;
 const throttle=!!(phasePlaying(state.status?.audio)||state.status?.audio?.state==='loading');
 if(throttle!==lastThrottle){lastThrottle=throttle;send('throttle',{value:throttle});}
 if(lastGate!==!!block){lastGate=!!block;send('pause',{value:lastGate});paint();}
}
function view(){
 const rows=library.roots.map(path=>'<div class="setting-row"><strong>'+esc(path)+'/</strong>'+button('移除','remove',path)+'</div>').join('');
 const activity=paused?'已暂停':lastGate&&library.running?'等待设备空闲':library.statusText;
 return panel('音乐目录',(rows||'<p>添加 TF 卡目录后，会自动整理其中的歌曲和子目录。</p>')+button('添加目录','browse','',true))+
 panel('资料整理','<p>'+esc(activity)+' · '+library.total+' 首 · '+library.albums+' 张专辑</p>'+
 (library.errorDetail?'<p role="status">'+esc(library.errorDetail)+'</p>':'')+
 '<div class="lock-actions">'+button('查看专辑','albums','0')+button('播放列表','lists')+button(paused?'继续':'暂停','pause')+button('重新检查','scan')+'</div>');
}
function paint(){if(window.nanoLibraries)window.nanoLibraries.changed();}
function paging(action,pos,total){return (pos?button('上一页',action,String(Math.max(0,pos-24))):'')+(pos+24<total?button('下一页',action,String(pos+24)):'');}
let browseGen=0;
$('#sheet').addEventListener('close',()=>{sheetType='';browseGen++;});
async function browse(path='',cursor=0){
 sheetType='folder';const gen=++browseGen;showSheet('添加音乐目录','<p>读取中…</p>','','音乐');
 try{
  const r=await api('/file-manager',{method:'POST',body:JSON.stringify({operation:'list',source:path,cursor})});
  if(gen!==browseGen||sheetType!=='folder'||!$('#sheet').open)return;
  const folders=r.entries.filter(e=>e.directory&&(!path?e.name!=='nanoos':true));
  const up=path.split('/').slice(0,-1).join('/');
  const list=folders.map(e=>'<li class="file-row">'+button(e.name+' /','browse',fileJoin(path,e.name))+'</li>').join('');
  showSheet('添加音乐目录','<p>'+esc(path||'TF 卡根目录')+'</p>'+(path?button('上级目录','browse',up):'')+'<ul class="file-list">'+list+'</ul>'+(r.next_cursor?button('下一页','folder-next',JSON.stringify([path,r.next_cursor])):'')+(path?'<p class="small">包括子目录。浏览器会用专辑名和艺人查找 MusicBrainz，结果保存在 TF 卡资料库。</p>':''),path?button('管理此目录','add',path,true):'','音乐');
 }catch(e){toast(e.message,true);}
}
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-library-action]');if(!b)return;
 const action=b.dataset.libraryAction,v=b.dataset.value;
 if(action==='lists'||action==='add-to'||action==='add-album'){sheetType='lists';send('lists',{trackToAdd:action==='add-to'?v:'',album:action==='add-album'?v:''});}
 if(action==='list'){sheetType='list';const [name,offset]=JSON.parse(v);send('list',{name,offset});}
 if(action==='new-list'||action==='new-album-list'){sheetType='new-list';showSheet('新建播放列表','<label class="field"><span>名称</span><input id="library-list-name" maxlength="64"></label>',button(action==='new-album-list'?'下一步':'创建',action==='new-album-list'?'preview-new-album':'create-list',v,true),'音乐');}
 if(action==='preview-new-album'){const name=$('#library-list-name').value.trim();if(name){sheetType='album-confirm';send('list-preview',{album:v,name,create:true});}}
 if(action==='preview-album'){const [album,name]=JSON.parse(v);sheetType='album-confirm';send('list-preview',{album,name});}
 if(action==='confirm-album'&&!b.disabled){b.disabled=true;const details=JSON.parse(v);send('list-edit',details);}
 if(action==='cancel-album')$('#sheet').close();
 if(action==='create-list'){const name=$('#library-list-name').value.trim();if(!name)return;sheetType='list';send('list-edit',{op:'create',name,track:v});}
 if(action==='change-list'){const [name,op,track,offset]=JSON.parse(v);sheetType='list';send('list-edit',{name,op,track,offset});}
 if(action==='browse')browse(v);
 if(action==='folder-next')browse(...JSON.parse(v));
 if(action==='add'||action==='remove-ok'){send('roots',{path:v,remove:action==='remove-ok'});$('#sheet').close();}
 if(action==='remove')showSheet('移除音乐目录','<p>'+esc(v)+' 将停止跟踪，卡上的音乐文件会保留。</p>',button('移除目录','remove-ok',v,true),'音乐');
 if(action==='pause'){paused=!paused;gateWorker();paint();}
 if(action==='scan'){paused=false;gateWorker();send('scan',{force:true});}
 if(action==='albums'){sheetType='albums';send('albums',{offset:Number(v)});}
 if(action==='open'){albumId=v;sheetType='album';send('album',{id:v,offset:0});}
 if(action==='tracks')send('album',{id:albumId,offset:Number(v)});
 if(action==='edition')send('edition',{id:albumId,mbid:v});
 if(action==='correct'){const [key,field,value]=JSON.parse(v);send('correct',{key,field,value});$('#sheet').close();}
});
worker.onmessage=({data:d})=>{
 if(d.type==='auth'){authNeeded();return;}
 if(window.nanoLibraries?.message(d))return;
 if(d.type==='error'){library.errorDetail=d.message;paint();toast(d.message,true);return;}
 if(d.type==='status'){const ended=library.running&&!d.running;library=d;paint();if(ended)window.nanoLibraries?.refreshMusic();return;}
 if(d.type==='playlist-saved'){clientQuery();if(d.album&&sheetType==='album-confirm'){$('#sheet').close();toast('已添加到「'+d.name+'」');}return;}
 if(d.type==='list-preview'&&sheetType==='album-confirm'){
  const details={name:d.name,album:d.album,confirm:d.token,create:d.create};
  showSheet('将专辑添加到播放列表','<p>《'+esc(d.title)+'》将为「'+esc(d.name)+'」新增 <strong>'+d.add+' 首歌曲</strong>。'+(d.existing?'已有 '+d.existing+' 首，会跳过。':'')+'</p>',button('取消','cancel-album')+(d.add?button('确认添加 '+d.add+' 首','confirm-album',JSON.stringify(details),true):''),'音乐');return;
 }
 if(d.type==='lists'&&sheetType==='lists'){
  const rows=d.names.map(name=>'<div class="setting-row"><strong>'+esc(name)+'</strong>'+(d.album?button('选择','preview-album',JSON.stringify([d.album,name])):d.trackToAdd?button('加入','change-list',JSON.stringify([name,'append',d.trackToAdd,0])):button('查看','list',JSON.stringify([name,0])))+'</div>').join('');
  showSheet(d.album||d.trackToAdd?'添加到播放列表':'播放列表',rows||'<p>还没有播放列表。</p>',button('新建播放列表',d.album?'new-album-list':'new-list',d.album||d.trackToAdd),'音乐');return;
 }
 if(d.type==='list'&&sheetType==='list'){
  const rows=d.rows.map((t,i)=>'<li class="file-row"><strong>'+esc(t.title)+'</strong><div class="lock-actions">'+(d.offset+i?button('上移','change-list',JSON.stringify([d.name,'up',t.key,d.offset])):'')+(d.offset+i+1<d.total?button('下移','change-list',JSON.stringify([d.name,'down',t.key,d.offset])):'')+button('移除','change-list',JSON.stringify([d.name,'remove',t.key,d.offset]))+'</div></li>').join('');
  const nav=(d.offset?button('上一页','list',JSON.stringify([d.name,Math.max(0,d.offset-24)])):'')+(d.offset+24<d.total?button('下一页','list',JSON.stringify([d.name,d.offset+24])):'');
  showSheet(d.name,rows?'<ul class="file-list">'+rows+'</ul>':'<p>查看专辑中的曲目即可加入这个播放列表。</p>',button('返回播放列表','lists')+nav,'音乐');return;
 }
 if(d.type==='albums'&&sheetType==='albums'){
  showSheet('专辑','<ul class="file-list">'+d.rows.map(a=>'<li class="file-row"><div class="file-main"><strong>'+esc(a.name)+'</strong><small>'+esc(a.artist)+' · '+a.count+' 首 · '+(a.matched?'已匹配':'待核对')+'</small></div>'+button('查看','open',a.id)+button('添加到播放列表','add-album',a.id)+'</li>').join('')+'</ul>'+(d.total?'':'<p>添加目录后，已读取的专辑会出现在这里。</p>'),paging('albums',d.offset,d.total),'音乐');return;
 }
 if(d.type==='album'&&sheetType==='album'&&d.id===albumId){
  const release=d.decision?.selected;
  const variants=(d.decision?.options||[]).map(v=>'<div class="setting-row"><div><strong>'+esc(v.album)+'</strong><p>'+esc([v.artist,v.date,v.country].filter(Boolean).join(' · '))+'</p></div>'+(release?.id===v.id?'已采用':button('采用版本','edition',v.id))+'</div>').join('');
  const art=release?'<p><a target="_blank" rel="noreferrer" href="https://coverartarchive.org/release/'+encodeURIComponent(release.id)+'/front-250">查看版本封面</a></p>':'';
  const rows=d.rows.map(t=>'<li class="file-row"><div class="file-main"><strong>'+esc(t.overrides?.title||t.title)+'</strong><small>'+esc(t.path)+'</small>'+button('加入播放列表','add-to',t.key)+Object.entries(t.suggestions||{}).map(([field,opts])=>opts.map(o=>button(({title:'曲名',artist:'艺人',album:'专辑',albumArtist:'专辑艺人'}[field]||field)+' · '+o.label+' → '+o.text,'correct',JSON.stringify([t.key,field,o.text]))).join('')).join('')+'</div></li>').join('');
  showSheet(d.name,(variants||'<p>暂无匹配版本，使用本地标签。</p>')+art+'<ul class="file-list">'+rows+'</ul>',button('返回专辑','albums','0')+paging('tracks',d.offset,d.total),'音乐');
 }
};
worker.onerror=()=>{library.errorDetail='资料工具未能启动，请重新载入音乐页。';paint();};
const musicSettingsView=view;

// OPDS and Emby share one device transfer slot with covers and library scans.
// Retry read requests only when the device explicitly reports that slot busy.
async function fetchLibrarySource(endpoint,options){
 const started=Date.now();let retriedOrigin=false;
 for(let attempt=0;;attempt++){
  const res=await fetch(endpoint,options);
  if(res.ok)return res;
  const busy=res.status===409||res.status===503;
  const temporary=endpoint==='/api/v1/opds'&&res.status===502&&!retriedOrigin;
  if(!busy&&!temporary||Date.now()-started>20000)return res;
  const error=(await res.clone().json().catch(()=>null))?.error;
  if(busy&&error?.code!=='transfer_busy'||temporary&&error?.code!=='opds_source')return res;
  if(temporary)retriedOrigin=true;
  await new Promise(resolve=>setTimeout(resolve,Math.min(1400,250+attempt*180)));
 }
}

const catalog = {source:0, url:'', stack:[], nav:[], books:[], chosen:new Map(),search:'',query:'',loading:false,error:'',generation:0};
function resolveLink(href,base){
 try{const u=new URL(href,base);return /^https?:$/.test(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}
}
function xmlDocument(text){
 text=text.replace(/<!DOCTYPE\s+html(?:\s+PUBLIC\s+"[^"<>]*"\s+"[^"<>]*")?\s*>/i,'');
 if(/<!DOCTYPE/i.test(text))throw Error('书库文档含有不支持的声明');
 const x=new DOMParser().parseFromString(text,'application/xml');
 if(x.getElementsByTagName('parsererror').length)throw Error('书库返回的 XML 无法解析');return x;
}
const children=(el,tag)=>Array.from(el?.children||[]).filter(child=>child.localName===tag);
const elementText=(el,tag)=>children(el,tag)[0]?.textContent?.trim()||'';
function catalogFeed(text,base){
 const nav=[],books=[];let search='',next='';
 const links=(items)=>items.map(l=>({...l,href:resolveLink(l.href,base),rel:[l.rel||''].flat()})).filter(l=>l.href);
 function book(title,creator,category,items){
  const ls=links(items),download=ls.find(l=>l.rel.some(r=>/^https?:\/\/opds-spec\.org\/acquisition(?:\/open-access)?$/.test(r))&&(/epub\+zip|text\/plain/i.test(l.type)||/\.(epub|txt)(\?|$)/i.test(l.href)));
  if(download)books.push({title,creator,category,href:download.href,epub:/epub/i.test(download.type||download.href)});
  else {const folder=ls.find(l=>/atom\+xml|opds\+json/i.test(l.type));if(folder)nav.push({title,href:folder.href});
   else {const media=ls.find(l=>l.rel.some(r=>r.includes('/acquisition')));if(media)books.push({title,creator,category,href:media.href,unsupported:(media.type||'未知格式').split('/').pop().toUpperCase()});}}
 }
 function relations(list){for(const l of links(list)){if(l.rel.includes('search'))search=l.href;if(l.rel.includes('next'))next=l.href;}}
 if(text.trimStart().startsWith('{')){
  const d=JSON.parse(text);const named=x=>typeof x==='string'?x:x?.name||'';
  const collect=g=>{for(const l of g.navigation||[])nav.push({title:l.title||l.href,href:resolveLink(l.href,base)});
   for(const p of g.publications||[]){const m=p.metadata||{};book(typeof m.title==='string'?m.title:Object.values(m.title||{})[0]||'未命名', [m.author||[]].flat().map(named).join('、'),[m.subject||[]].flat().map(named).filter(Boolean).join(' / '),p.links||[]);}};
  collect(d);for(const g of d.groups||[])collect(g);relations(d.links||[]);
 }else{
  const root=xmlDocument(text).documentElement;
  const attrs=e=>Object.fromEntries(Array.from(e.attributes).map(a=>[a.name,a.value]));
  relations(children(root,'link').map(attrs));
  for(const e of children(root,'entry'))book(elementText(e,'title'),children(e,'author').map(a=>elementText(a,'name')).join('、'),children(e,'category').map(a=>a.getAttribute('label')||a.getAttribute('term')).filter(Boolean).join(' / '),children(e,'link').map(attrs));
 }
 return {nav,books,search,next};
}
async function opdsRead(url,book=false){
 const source=state.config.opds.sources[catalog.source],base=new URL(source.url);
 const target=new URL(url||source.url,base);
 if(target.origin!==base.origin)throw Error('这个链接位于另一个站点，请添加相应书库来源');
 const r=await fetchLibrarySource('/api/v1/opds',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+state.key},body:JSON.stringify({source:catalog.source,url:target.href,book}),signal:AbortSignal.timeout(book?600000:40000)});
 if(r.status===401)authNeeded();if(!r.ok)throw Error((await r.json().catch(()=>null))?.error?.message||'无法读取书库');
 return book?r.blob():r.text();
}
async function openFeed(url,back=false){
 const seq=++catalog.generation;catalog.loading=true;catalog.error='';paintLibraries();
 try{const text=await opdsRead(url),page=catalogFeed(text,url);if(seq!==catalog.generation)return;
  if(!back&&catalog.url&&catalog.url!==url)catalog.stack.push(catalog.url);
  Object.assign(catalog,page,{search:page.search||catalog.search,url,query:''});
 }catch(e){if(seq===catalog.generation)catalog.error=e.message;}
 finally{if(seq===catalog.generation){catalog.loading=false;paintLibraries();}}
}
async function searchFeed(query){
 const term=query.trim();if(!term)return;
 if(!catalog.url){const source=state.config.opds.sources[catalog.source];if(source)await openFeed(source.url);}
 if(!catalog.search){if(catalog.error)return;catalog.query=term;paintLibraries();return;}
 try{let template=decodeURI(catalog.search).replace(/%7B/gi,'{').replace(/%7D/gi,'}');
  if(!template.includes('{searchTerms}')){
   const root=xmlDocument(await opdsRead(catalog.search)).documentElement;
   template=Array.from(root.getElementsByTagNameNS('*','Url')).find(e=>/atom|opds/.test(e.getAttribute('type')||''))?.getAttribute('template')||'';
  }
  if(!template.includes('{searchTerms}'))throw Error('此来源没有可用的搜索模板');
  await openFeed(resolveLink(template.replace('{searchTerms}',encodeURIComponent(term)).replace(/\{[^{}]+\?\}/g,''),catalog.url));
 }catch(e){catalog.error=e.message;paintLibraries();}
}
async function loadEpub(blob){
 const bytes=new Uint8Array(await blob.arrayBuffer()),v=new DataView(bytes.buffer),entries=new Map(),dec=new TextDecoder();
 const u16=p=>v.getUint16(p,true),u32=p=>v.getUint32(p,true);let end=bytes.length-22;
 for(;end>=Math.max(0,bytes.length-65557);end--)if(u32(end)===0x06054b50)break;
 if(end<0||end<bytes.length-65557||u32(end)!==0x06054b50)throw Error('EPUB 目录损坏');
 let p=u32(end+16);const count=u16(end+10);if(count>10000)throw Error('EPUB 章节过多');
 for(let i=0;i<count;i++){
  if(u32(p)!==0x02014b50)throw Error('EPUB 目录无效');
  const name=dec.decode(bytes.subarray(p+46,p+46+u16(p+28)));
  entries.set(name,{method:u16(p+10),flags:u16(p+8),size:u32(p+24),packed:u32(p+20),at:u32(p+42)});
  p+=46+u16(p+28)+u16(p+30)+u16(p+32);
 }
 let expanded=0;
 async function xml(name){
  const e=entries.get(name);if(!e||e.flags&1||e.size>8*1024*1024||expanded+e.size>32*1024*1024)throw Error('EPUB 章节缺失、加密或超出容量');
  const at=e.at;if(u32(at)!==0x04034b50)throw Error('EPUB 章节无效');
  const start=at+30+u16(at+26)+u16(at+28);if(start+e.packed>bytes.length)throw Error('EPUB 章节不完整');
  let body=bytes.subarray(start,start+e.packed);
  if(e.method===8){
   const stream=new Blob([body]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
   const result=new Uint8Array(e.size);let n=0;
   try{for(;;){const part=await stream.read();if(part.done)break;if(n+part.value.length>e.size)throw Error('EPUB 解压长度无效');result.set(part.value,n);n+=part.value.length;}}
   finally{await stream.cancel().catch(()=>{});}
   if(n!==e.size)throw Error('EPUB 章节不完整');body=result;
  }else if(e.method!==0||body.length!==e.size)throw Error('不支持的 EPUB 压缩方式');
  expanded+=body.length;return xmlDocument(dec.decode(body));
 }
 const container=await xml('META-INF/container.xml');
 const opf=container.getElementsByTagNameNS('*','rootfile')[0]?.getAttribute('full-path');if(!opf)throw Error('EPUB 缺少书目');
 const doc=await xml(opf),find=k=>Array.from(doc.getElementsByTagNameNS('*',k));
 const metadata={title:find('title')[0]?.textContent||'',creator:find('creator').map(t=>t.textContent).join('、'),category:find('subject')[0]?.textContent||''};
 const manifest=new Map(find('item').map(e=>[e.getAttribute('id'),e.getAttribute('href')]));
 const paragraphs=[];
 for(const ref of find('itemref')){
  if(ref.getAttribute('linear')==='no')continue;
  const href=manifest.get(ref.getAttribute('idref'));if(!href)throw Error('EPUB 章节引用缺失');
  const resource=new URL(href,new URL(opf,'https://epub.invalid/'));if(resource.origin!=='https://epub.invalid')throw Error('不支持外部章节');
  const chapter=await xml(decodeURIComponent(resource.pathname.slice(1)));
  const body=chapter.getElementsByTagNameNS('*','body')[0];if(!body)continue;
  for(const node of Array.from(body.querySelectorAll('script,style,svg')))node.remove();
  for(const node of Array.from(body.querySelectorAll('p,div,section,h1,h2,h3,h4,li,br')))node.append(chapter.createTextNode('\n'));
  paragraphs.push(body.textContent.replace(/[ \t]+\n/g,'\n').trim());
 }
 const plain=paragraphs.filter(Boolean).join('\n\n');if(!plain)throw Error('此 EPUB 没有可阅读的文字');
 return {blob:new Blob([plain],{type:'text/plain;charset=utf-8'}),metadata};
}

const client={tab:'专辑',query:'',offset:0,detailOffset:0,groupOffset:0,chosenArtist:'',chosenAlbum:'',chosenList:'',sort:'title',response:null,request:0,art:new Map(),lastKeys:'',timer:0,album:null};
const clientNav=[['最近添加','refresh'],['艺人','apps'],['专辑','music'],['歌曲','list'],['播放列表','folder'],['管理目录','settings']];
function mcButton(text,action,value='',cls=''){
 return '<button class="'+(cls||'button secondary')+'" data-mc="'+action+'" data-value="'+esc(value)+'">'+esc(text)+'</button>';
}
function coverTile(key,shape=''){
 const src=client.art.get(key);
 return '<span class="mc-art '+shape+'" data-mc-cover="'+esc(key||'')+'">'+(src?'<img src="'+esc(src)+'" alt="">':icon('music'))+'</span>';
}
function askCovers(){
 const keys=[...new Set($$('[data-mc-cover]',$('#content')).map(n=>n.dataset.mcCover).filter(k=>k&&!client.art.has(k)))];
 const here=keys.join(',');if(here&&here!==client.lastKeys){client.lastKeys=here;send('cover-page',{keys});}
}
function clientQuery(){
 if(!ready||state.route!=='music'||client.tab==='管理目录'||client.tab==='从 Emby 导入')return;
 if(client.album){send('album',{id:client.album.id,offset:client.detailOffset});return;}
 send('browse-music',{tab:client.tab,query:client.query,offset:client.offset,sort:client.sort,artist:client.chosenArtist,album:client.chosenAlbum,list:client.chosenList,detailOffset:client.detailOffset,groupOffset:client.groupOffset,request:++client.request});
}
function pageButtons(offset,count,action){
 return count>24?'<div class="library-actions">'+(offset?mcButton('上一页',action,Math.max(0,offset-24)):'')+'<small>'+String(offset+1)+'–'+Math.min(count,offset+24)+' / '+count+'</small>'+(offset+24<count?mcButton('下一页',action,offset+24):'')+'</div>':'';
}
function tableRows(list,sort=false,playlist=null){
 const head=field=>sort?mcButton(({title:'标题',sub:'艺人',album:'专辑'})[field],'sort',field,'mc-heading'):({title:'标题',sub:'艺人',album:'专辑'})[field];
 return '<div class="mc-table-wrap"><table class="mc-table"><thead><tr><th>'+head('title')+'</th><th>'+head('sub')+'</th><th>'+head('album')+'</th><th>格式</th><th>时长</th><th><span class="sr-only">文件操作</span></th></tr></thead><tbody>'+list.map(t=>'<tr data-song-key="'+esc(t.key)+'"><td><button class="mc-track" data-mc="play" data-value="'+esc(t.path)+'">'+esc(t.title)+'</button></td><td>'+esc(t.sub||'')+'</td><td>'+esc(t.album||'')+'</td><td>'+esc(t.format||'')+'</td><td>'+formatSongTime(t.seconds)+'</td><td><button class="mc-track-add" data-library-action="add-to" data-value="'+esc(t.key)+'" aria-label="将'+esc(t.title)+'加入播放列表" title="添加到播放列表">＋</button>'+(playlist?playlistTools(t,playlist):'')+libraryDeleteButton(t.path,t.title)+'</td></tr>').join('')+'</tbody></table></div>';
}
function formatSongTime(seconds){return seconds?Math.floor(seconds/60)+':'+String(Math.floor(seconds%60)).padStart(2,'0'):'—';}
function albumAdd(row){return '<button class="mc-track-add" data-library-action="add-album" data-value="'+esc(row.id)+'" aria-label="将《'+esc(row.title)+'》添加到播放列表" title="添加到播放列表">＋</button>';}
function albumCard(r,action){
 const card='<button class="mc-card" data-mc="'+action+'" data-value="'+esc(r.list||r.id)+'">'+coverTile(r.artKey)+'<strong>'+esc(r.title)+'</strong><small>'+esc(r.list?r.count+' 首歌曲':r.sub||'')+'</small></button>';
 return r.list?card:'<div class="mc-card-item">'+card+albumAdd(r)+'</div>';
}
function albumCards(rows){
 return '<div class="mc-grid">'+rows.map(r=>albumCard(r,r.list?'list':'album')).join('')+'</div>';
}
function hero(title,sub,key,buttons){
 return '<div class="mc-hero">'+coverTile(key)+'<div><h2>'+esc(title)+'</h2><p>'+esc(sub)+'</p><div class="library-actions">'+buttons+'</div></div></div>';
}
function albumSongs(d){return d.rows.map(t=>({key:t.key,title:t.overrides?.title||t.title,sub:t.overrides?.artist||t.artist,album:t.overrides?.album||t.album,path:t.path,seconds:t.seconds,format:t.path.split('.').pop().toUpperCase()}));}
function clientBody(){
 if(client.tab==='管理目录')return musicSettingsView();
 if(client.album){
  const album=client.album,d=album.data;if(!d)return '<p>正在读取曲目…</p>';
  const rows=albumSongs(d);return mcButton('返回'+client.tab,'back')+hero(d.name,album.sub+' · '+d.total+' 首',album.artKey,(rows.length?mcButton('播放','play',rows[0].path,'button primary'):'')+button('添加到播放列表','add-album',d.id)+mcButton('整理资料','metadata',d.id))+tableRows(rows)+pageButtons(client.detailOffset,d.total,'detail-page');
 }
 const d=client.response;if(!d)return '<p>正在读取资料库…</p>';
 if(client.tab==='播放列表'&&client.chosenList&&d.detail){
  const l=d.detail;return mcButton('所有播放列表','back')+hero(l.title,l.length+' 首歌曲',l.artKey,(l.rows.length?mcButton('播放','play',l.rows[0].path,'button primary'):''))+tableRows(l.rows,false,l)+pageButtons(client.detailOffset,l.length,'detail-page');
 }
 const emptyText=client.query?'没有找到匹配的内容。':client.tab==='播放列表'?'在歌曲旁点「＋」，即可创建播放列表或加入已有列表。':library.running?'正在整理歌曲，首批目录读完后会显示在这里。':'还没有音乐。可上传文件，或在管理目录中选择已有音乐。';
 if(!d.rows.length)return (client.tab==='播放列表'?button('新建播放列表','new-list'):'')+'<p>'+emptyText+'</p>';
 if(client.tab==='艺人'){
  const a=d.detail;
  return '<div class="mc-artists"><div class="mc-artist-list">'+d.rows.map(r=>'<button class="mc-artist '+(a?.title===r.title?'active':'')+'" data-mc="artist" data-value="'+esc(r.title)+'">'+coverTile(r.artKey,'round')+'<span>'+esc(r.title)+'</span></button>').join('')+pageButtons(client.offset,d.total,'page')+'</div>'+
   (a?'<section class="mc-artist-detail"><h2>'+esc(a.title)+'</h2><p>'+a.albums+' 张专辑 · '+a.count+' 首歌曲</p><div class="mc-discography">'+a.choices.map(r=>albumCard(r,'artist-album')).join('')+'</div>'+pageButtons(client.groupOffset,a.albums,'group-page')+'<h3>'+esc(a.selected.title)+'</h3>'+tableRows(a.rows)+pageButtons(client.detailOffset,a.length,'detail-page')+'</section>':'')+'</div>';
 }
 return (client.tab==='播放列表'?button('新建播放列表','new-list'):'')+(client.tab==='歌曲'?tableRows(d.rows,true):albumCards(d.rows))+pageButtons(client.offset,d.total,'page');
}
function clientView(){
 return '<div class="mc-shell"><nav class="mc-nav" aria-label="音乐资料库">'+clientNav.map(([t,i])=>'<button data-mc="nav" data-value="'+t+'" aria-current="'+(t===client.tab?'page':'false')+'">'+icon(i)+'<span>'+t+'</span></button>').join('')+'</nav><section class="mc-main"><div class="mc-toolbar"><h2>'+esc(client.tab)+'</h2>'+(!['管理目录','从 Emby 导入'].includes(client.tab)?'<label class="mc-search"><span class="sr-only">在'+client.tab+'中查找</span><input id="mc-search" type="search" value="'+esc(client.query)+'" placeholder="在'+client.tab+'中查找"></label>':'')+'</div><div id="mc-body">'+clientBody()+'</div></section></div>';
}
function paintClient(full=false){
 if(state.route!=='music')return;
 const body=$('#mc-body');if(full||!body)$('#content').innerHTML=clientView();else body.innerHTML=clientBody();askCovers();
}
function clientMessage(d){
 if(d.type==='cover'){
  if(client.art.size>=64)client.art.delete(client.art.keys().next().value);
  client.art.set(d.key,d.url);for(const el of $$('[data-mc-cover]'))if(el.dataset.mcCover===d.key&&d.url){const img=new Image();img.alt='';img.src=d.url;el.replaceChildren(img);}return true;
 }
 if(d.type==='music-page'){
  if(d.request!==client.request)return true;
  if(client.offset>0&&client.offset>=d.total){
   client.offset=24*Math.floor(Math.max(0,d.total-1)/24);clientQuery();return true;
  }
  if(d.detail&&client.detailOffset>0&&client.detailOffset>=d.detail.length){
   client.detailOffset=24*Math.floor(Math.max(0,d.detail.length-1)/24);clientQuery();return true;
  }
  client.response=d;paintClient();return true;
 }
 if(d.type==='album-missing'&&client.album?.id===d.id){
  client.album=null;client.detailOffset=0;clientQuery();return true;
 }
 if(d.type==='album'&&client.album?.id===d.id&&sheetType!=='album'){
  client.album.data=d;client.detailOffset=d.offset;paintClient();return true;
 }return false;
}
document.addEventListener('input',e=>{if(e.target.id!=='mc-search')return;
 client.query=e.target.value;client.offset=0;client.album=null;client.chosenList='';clearTimeout(client.timer);client.timer=setTimeout(clientQuery,170);
});
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-mc]');if(!b||state.route!=='music')return;const value=b.dataset.value,action=b.dataset.mc;
 if(action==='play'){if(!value||value==='undefined')return;const path='/sdcard/'+value,album=client.album?.data,list=client.tab==='播放列表'&&client.chosenList&&client.response?.detail;
  try{
   const args={path};
   if(list||album){
    const q=await api('/music',{method:'POST',body:JSON.stringify({op:'queue',kind:list?'playlist':'album',key:list?list.title:album.name,path,artist:list?'':client.album.sub})});
    args.queue=q.queue;
   }
   await command('open','music',args);
  }catch(error){toast('播放失败：'+error.message,true);}
  return;}
 if(action==='metadata'){sheetType='album';albumId=value;send('album',{id:value,offset:0});return;}
 if(action==='nav'){Object.assign(client,{tab:value,query:'',offset:0,detailOffset:0,groupOffset:0,chosenAlbum:'',chosenArtist:'',chosenList:'',album:null,response:null});paintClient(true);}
 if(action==='artist'){client.chosenArtist=value;client.chosenAlbum='';client.detailOffset=client.groupOffset=0;}
 if(action==='artist-album'){client.chosenAlbum=value;client.detailOffset=0;}
 if(action==='sort'){client.sort=value;client.offset=0;}
 if(action==='list'){client.chosenList=value;client.detailOffset=0;}
 if(action==='back'){client.album=null;client.chosenList='';client.detailOffset=0;}
 if(action==='album'){const row=client.response?.rows.find(r=>r.id===value);if(!row)return;client.album={...row};client.detailOffset=0;sheetType='';paintClient();}
 if(action==='page')client.offset=Number(value);
 if(action==='group-page')client.groupOffset=Number(value);
 if(action==='detail-page')client.detailOffset=Number(value);
 clientQuery();
});
function playlistTools(track,list){
 const key=esc(track.key),title=esc(track.title);
 return '<button class="mc-drag" data-reorder="'+key+'" aria-label="调整《'+title+'》的位置" title="拖动排序，点按可指定位置">⠿</button>'+
  '<button class="mc-row-action" data-playlist-op="cover" data-key="'+key+'" '+(track.key===list.artKey?'aria-pressed="true"':'')+' title="使用这首歌的封面">'+(track.key===list.artKey?'当前封面':'设为封面')+'</button>'+
  '<button class="mc-row-action" data-playlist-op="remove" data-key="'+key+'">移出列表</button>';
}
function editCurrentList(op,track,extra={}){
 if(client.tab==='播放列表'&&client.chosenList)send('list-edit',{op,track,name:client.chosenList,inline:true,...extra});
}
let songDrag=null;
document.addEventListener('pointerdown',e=>{
 const handle=e.target.closest('[data-reorder]');if(!handle||e.button!==0)return;
 songDrag={id:e.pointerId,key:handle.dataset.reorder,y:e.clientY,target:null,moved:false};handle.setPointerCapture(e.pointerId);
});
document.addEventListener('pointermove',e=>{
 const d=songDrag;if(!d||e.pointerId!==d.id)return;
 if(Math.abs(e.clientY-d.y)>5)d.moved=true;if(!d.moved)return;
 if(e.clientY<75||e.clientY>innerHeight-75)window.scrollBy(0,e.clientY<75?-20:20);
 const row=document.elementFromPoint(e.clientX,e.clientY)?.closest('tr[data-song-key]');if(row!==d.target){d.target?.classList.remove('mc-drop');d.target=row;row?.classList.add('mc-drop');}
});
function finishDrag(e){
 const d=songDrag;if(!d||e.pointerId!==d.id)return;songDrag=null;d.target?.classList.remove('mc-drop');
 if(e.type==='pointerup'&&d.moved){const handle=e.target.closest('[data-reorder]');if(handle){handle.dataset.dragged='1';setTimeout(()=>delete handle.dataset.dragged,300);}
  if(d.target&&d.target.dataset.songKey!==d.key)editCurrentList('move',d.key,{anchor:d.target.dataset.songKey});}
}
document.addEventListener('pointerup',finishDrag);document.addEventListener('pointercancel',finishDrag);
document.addEventListener('click',e=>{
 const btn=e.target.closest('button');if(!btn)return;
 if(btn.dataset.playlistOp)editCurrentList(btn.dataset.playlistOp,btn.dataset.key);
 if(btn.dataset.reorder&&!btn.dataset.dragged){
  const n=client.response?.detail?.length||0,key=btn.dataset.reorder,index=client.detailOffset+[...btn.closest('tbody').rows].indexOf(btn.closest('tr'))+1;
  showSheet('调整曲序','<label class="field"><span>目标位置（1–'+n+'）</span><input id="mc-position" type="number" min="1" max="'+n+'" value="'+index+'" required></label>','<button class="button primary" data-move-key="'+esc(key)+'">移动</button>');
 }
 if(btn.dataset.moveKey){const input=$('#mc-position');if(input.reportValidity()){editCurrentList('move',btn.dataset.moveKey,{index:input.valueAsNumber-1});$('#sheet').close();}}
});

// Conversion workers are short lived. The page owns the shared bytes and keeps
// one persistent version per engine for the next visit to this device.
const codecLoads=new Map();
let codecDatabase;
function openCodecDatabase(){
 if(!codecDatabase)codecDatabase=new Promise((resolve,reject)=>{
  const open=indexedDB.open('nanoos-conversion-tools',1);
  let blocked=false;
  open.onblocked=()=>{blocked=true;resolve(null);};
  open.onupgradeneeded=()=>open.result.createObjectStore('engines');
  open.onsuccess=()=>{
   const db=open.result;
   if(blocked){db.close();return;}
   db.onversionchange=()=>{db.close();codecDatabase=null;};
   resolve(db);
  };
  open.onerror=()=>reject(open.error);
 }).catch(()=>null);
 return codecDatabase;
}
async function savedCodec(key,record){
 const db=await openCodecDatabase();
 if(!db)return;
 return new Promise((resolve,reject)=>{
  const tx=db.transaction('engines',record?'readwrite':'readonly');
  const store=tx.objectStore('engines');
  const op=record?store.put(record,key):store.get(key);
  tx.oncomplete=()=>resolve(op.result);
  tx.onabort=()=>reject(tx.error);
 });
}
async function loadCodecBlob(path,size,load){
 const key=path.split('?')[0],signal=load.controller.signal;
 const saved=await savedCodec(key).catch(()=>null);
 if(signal.aborted)throw Error('已取消');
 if(saved?.path===path&&saved.blob instanceof Blob&&saved.blob.size===size)return saved.blob;
 // An upgrade from the previous WebUI can already have these bytes in HTTP cache.
 let response=await fetch(path,{mode:'same-origin',cache:'only-if-cached',signal}).catch(()=>null);
 const local=response?.ok;
 if(!local){
  load.notify(0);
  response=await fetch(path,{signal});
 }
 if(!response.ok)throw Error('无法读取 TF 卡转换组件（'+response.status+'）');
 const reader=response.body.getReader(),chunks=[];
 let loaded=0,last=0;
 try{
  for(;;){
   const {done,value}=await reader.read();
   if(done)break;
   loaded+=value.length;
   if(loaded>size)throw Error('转换组件大小异常');
   chunks.push(value);
   if(!local&&(Date.now()-last>=120||loaded===size)){load.notify(loaded);last=Date.now();}
  }
 }finally{reader.releaseLock();}
 if(loaded!==size)throw Error('转换组件不完整，请重试');
 const blob=new Blob(chunks,{type:'application/wasm'});
 if(signal.aborted)throw Error('已取消');
 await savedCodec(key,{path,blob}).catch(()=>{});
 return blob;
}
function acquireCodec(path,size,progress){
 if(!/^\/(video|book)-codec\.wasm\?v=[a-f0-9]{16}$/.test(path)||!Number.isSafeInteger(size)||size<=0)throw Error('转换组件版本无效');
 const key=path.split('?')[0];
 let load=codecLoads.get(key);
 if(load?.path!==path){
  load={path,controller:new AbortController(),users:new Set(),loaded:null,done:false,
   notify(n){this.loaded=n;for(const user of this.users)user(n);}};
  codecLoads.set(key,load);
  load.promise=loadCodecBlob(path,size,load).then(blob=>{load.done=true;load.loaded=null;return blob;},e=>{
   if(codecLoads.get(key)===load)codecLoads.delete(key);
   load.controller.abort();
   throw e;
  });
 }
 load.users.add(progress);
 if(load.loaded!==null)progress(load.loaded);
 return {blob:load.promise,release(){
  load.users.delete(progress);
  if(!load.done&&!load.users.size){
   if(codecLoads.get(key)===load)codecLoads.delete(key);
   load.controller.abort();
  }
 }};
}

// Local files are inspected and converted before any write to the TF card.
const uploadKinds={
 music:'.mp3,.flac,.wav,.aac,.m4a,.aif,.aiff,.ogg,.opus,.wma,.ape,.alac,.mka,.wv',
 video:'video/*,.mkv,.mjpeg,.mjpg,.avi,.mov,.m4v,.ts,.mts,.flv,.webm',
 books:'.txt,.epub,.pdf,.fb2,.xps,.cbz,.html,.xhtml'
};
let uploadDialog=null,activeWorker=null,activeRequest=null,stopUpload=false,decision=null;
function modalStep(stage,detail='',loaded=null,total=0){
 if(!uploadDialog?.open)return;
 const text=uploadDialog.querySelector('.up-stage'),meter=uploadDialog.querySelector('progress');
 text.textContent=stage;
 uploadDialog.querySelector('.up-detail').textContent=detail;
 if(Number.isFinite(loaded)&&total>0){meter.value=Math.min(100,loaded*100/total);meter.setAttribute('aria-valuetext',Math.floor(meter.value)+'%');}
 else{meter.removeAttribute('value');meter.removeAttribute('aria-valuetext');}
}
function checkUpload(){if(stopUpload)throw Error('已取消');}
function openUploadDialog(kind,files=[]){
 if(uploadBusy){if(uploadDialog&&!uploadDialog.open)uploadDialog.showModal();return;}
 if(!uploadDialog){
  uploadDialog=document.createElement('dialog');uploadDialog.className='upload-dialog';uploadDialog.setAttribute('aria-labelledby','up-heading');document.body.append(uploadDialog);
  uploadDialog.addEventListener('cancel',event=>{if(uploadBusy){event.preventDefault();cancelUpload();}});
 }
 stopUpload=false;
 uploadDialog.innerHTML='<h2 id="up-heading">上传'+esc(libraryNames[kind])+'</h2><p class="up-file"></p><strong class="up-stage" role="status">选择要上传的文件</strong><progress max="100" value="0" aria-label="当前阶段进度"></progress><p class="up-detail">先检查文件，设备可以直接使用的文件将原样上传。</p><ul class="up-results"></ul><input type="file" class="up-input" hidden multiple><div class="up-actions"><button class="button secondary up-close">关闭</button><button class="button primary up-pick">选择文件</button></div>';
 const close=uploadDialog.querySelector('.up-close'),pick=uploadDialog.querySelector('.up-pick');
 close.onclick=()=>uploadBusy?cancelUpload():uploadDialog.close();
 const input=uploadDialog.querySelector('.up-input');input.accept=uploadKinds[kind];
 input.onchange=()=>{if(input.files.length){const selected=[...input.files];input.value='';runUploads(kind,selected);}};
 pick.onclick=()=>input.click();
 if(!uploadDialog.open)uploadDialog.showModal();
 if(files.length)runUploads(kind,files);
}
function cancelUpload(){
 stopUpload=true;
 if(decision){decision(false);decision=null;}
 activeWorker?.cancel();activeRequest?.abort();
 modalStep('正在取消');
}
function askImageBook(count){
 return new Promise(resolve=>{
  const buttons=uploadDialog.querySelector('.up-actions'),old=buttons.hidden;buttons.hidden=true;
  modalStep('这本书只有图片，无法朗读','共 '+count+' 页。可以保存为图片书，在设备上逐页翻阅。');
  const options=document.createElement('div');options.className='up-actions';
  options.innerHTML='<button class="button secondary">跳过此书</button><button class="button primary">保存图片书</button>';
  uploadDialog.append(options);
  decision=save=>{decision=null;options.remove();buttons.hidden=old;resolve(save);};
  options.children[0].onclick=()=>decision(false);options.children[1].onclick=()=>decision(true);
 });
}
function runCodec(file,kind,inspect=true,flatMP4=false,onStage=()=>{}){
 return new Promise((resolve,reject)=>{
  const book=kind==='books',w=new Worker(book?'/book-codec.js':'/video-codec.js',book?{type:'module'}:{});
  const handle={cancel:()=>end(Error('已取消'))};activeWorker=handle;
  const beat=setInterval(updateJobs,15000);let stage='加载转换组件',lease,ended=false;
  function end(error,result){
   if(ended)return;ended=true;lease?.release();w.terminate();clearInterval(beat);if(activeWorker===handle)activeWorker=null;
   if(error)reject(error);else resolve(result);
  }
  w.onerror=()=>end(Error('转换组件加载失败，请检查 TF 卡和网络'));
  const request={file,name:file.name||'',kind,inspect,flatMP4,limit:state.caps.limits.media_upload_bytes||268435456};
  w.onmessage=async({data:d})=>{
   if(d.ready){w.postMessage(request);return;}
   if(d.error){end(Error(d.error));return;}
   if(d.codecPath){
    try{
     lease=acquireCodec(d.codecPath,d.size,n=>{
      stage='下载 WASM 组件';onStage(stage);modalStep(stage,formatBytes(n)+' / '+formatBytes(d.size),n,d.size);
     });
     const blob=await lease.blob;
     if(!ended){stage='加载转换组件';onStage(stage);modalStep(stage);w.postMessage({codecBlob:blob});}
    }catch(e){end(e);}
    return;
   }
   if(d.imageOnly){w.postMessage({saveImages:await askImageBook(d.pages)});return;}
   if(d.stage||d.progress!==undefined){stage=d.stage||stage;onStage(stage);modalStep(stage,d.progress===undefined?'':d.progress+'%',d.progress,100);return;}
   end(null,d);
  };
  modalStep(stage);
  if(!book)w.postMessage(request);
 });
}
async function plainMP4(file){
 let at=0,moov=false,mdat=false;
 for(let boxes=0;boxes<1024&&at+8<=file.size;boxes++){
  const buf=await file.slice(at,at+16).arrayBuffer(),v=new DataView(buf);let size=v.getUint32(0);
  const type=String.fromCharCode(...new Uint8Array(buf,4,4));
  if(type==='moof')return false;if(type==='moov')moov=true;if(type==='mdat')mdat=true;
  if(size===1){if(buf.byteLength<16)return false;size=Number(v.getBigUint64(8));}
  if(!size)size=file.size-at;if(size<8||size>file.size-at)return false;at+=size;
 }
 return at===file.size&&moov&&mdat;
}
async function directAudio(file,ext,header){
 let h=header;
 if((ext==='aac'||ext==='mp3')&&String.fromCharCode(...h.subarray(0,3))==='ID3'&&h.length>=10){
  if(h.subarray(6,10).some(v=>v&128))return false;
  const at=10+h.subarray(6,10).reduce((n,v)=>n*128+v,0)+(h[3]===4&&(h[5]&16)?10:0);
  h=new Uint8Array(await file.slice(at,at+16).arrayBuffer());
 }
 if(h.length<8)return false;
 if(ext==='mp3')return h[0]===255&&(h[1]&224)===224&&(h[1]>>3&3)!==1&&(h[1]>>1&3)===1&&(h[2]>>4)>0&&(h[2]>>4)<15&&(h[2]>>2&3)!==3;
 if(ext==='aac'){
  const rates=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000],rate=rates[h[2]>>2&15],channels=(h[2]&1)*4+(h[3]>>6);
  return h[0]===255&&(h[1]&246)===240&&(h[2]>>6)===1&&rate>=8000&&rate<=48000&&channels>=1&&channels<=2;
 }
 if(ext==='wav'&&String.fromCharCode(...h.subarray(0,4))==='RIFF'&&String.fromCharCode(...h.subarray(8,12))==='WAVE'){
  const v=new DataView(h.buffer,h.byteOffset,h.byteLength);
  for(let i=12;i+24<=h.length;){
   const bytes=v.getUint32(i+4,true);
   if(String.fromCharCode(...h.subarray(i,i+4))==='fmt '){
    const rate=v.getUint32(i+12,true),channels=v.getUint16(i+10,true);
    return bytes>=16&&v.getUint16(i+8,true)===1&&channels>=1&&channels<=2&&rate>=8000&&rate<=48000&&[8,16,24,32].includes(v.getUint16(i+22,true));
   }
   i+=8+bytes+(bytes&1);
  }
 }
 return false;
}

async function prepareLocal(file,kind){
 const ext=file.name.split('.').pop().toLowerCase(),base=file.name.replace(/\.[^.]+$/,'');
 const head=new Uint8Array(await file.slice(0,4096).arrayBuffer());
 checkUpload();if(!head.length)throw Error('文件为空');
 const sig=n=>String.fromCharCode(...head.subarray(0,n));
 if(kind==='books'){
  if(ext==='txt'){
   if(file.size>16777216)throw Error('文本书超过 16 MiB');
   const raw=new Uint8Array(await file.arrayBuffer());
   try{new TextDecoder('utf-8',{fatal:true}).decode(raw);if(raw.includes(0))throw Error();return {blob:file,name:file.name};}
   catch{let codec=raw[0]===255&&raw[1]===254?'utf-16le':raw[0]===254&&raw[1]===255?'utf-16be':'gb18030';
    modalStep('转换文字编码',codec+' → UTF-8');const text=new TextDecoder(codec,{fatal:true}).decode(raw);if(text.includes('\0'))throw Error('文本编码无法识别');return {blob:new Blob([text]),name:base+'.txt'};}
  }
  if(file.size>33554432)throw Error('书籍超过 32 MiB');
  if(ext==='epub'){try{const parsed=await loadEpub(file);return {blob:parsed.blob,tags:parsed.metadata||parsed.tags||{},name:base+'.txt'};}catch(e){if(!e.message.includes('没有可阅读的文字'))throw e;}}
  const r=await runCodec(file,'books');if(r.skipped)return {skipped:true};
  return r.pages?{pages:r.pages,name:base+'.nbook',tags:r.tags}:{blob:new Blob([r.output]),name:base+'.txt',tags:r.tags};
 }
 if(kind==='music'&&await directAudio(file,ext,head))return {blob:file,name:file.name};
 if(kind==='music'&&ext==='flac'&&sig(4)==='fLaC'&&head.length>=42&&(head[4]&127)===0){
  const block=head[10]*256+head[11],hz=head[18]*4096+head[19]*16+(head[20]>>4),ch=(head[20]>>1&7)+1,bits=((head[20]&1)<<4|head[21]>>4)+1;
  if(block>0&&block<=8192&&hz>=8000&&hz<=48000&&ch<=2&&bits<=24)return {blob:file,name:file.name};
 }
 const r=await runCodec(file,kind,true,ext==='mp4'&&await plainMP4(file));checkUpload();
 return r.direct?{blob:file,name:file.name}:{blob:new Blob([r.output]),name:base+'.'+r.ext};
}
const fileOp=(operation,source,destination)=>api('/file-manager',{method:'POST',body:JSON.stringify({operation,source,destination})});
function zipCRC(bytes){let crc=0xffffffff;for(const v of bytes){crc^=v;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function bookIndex(pages){
 const raw=new Uint8Array(32+pages.length*64),v=new DataView(raw.buffer),enc=new TextEncoder();
 raw.set(enc.encode('NBP1'));for(const [i,n] of [[4,1],[6,32],[8,64],[10,pages.length]])v.setUint16(i,n,true);
 for(const [i,page] of pages.entries()){
  const pos=32+i*64;raw.set(enc.encode(page.file),pos);v.setUint16(pos+32,page.width,true);v.setUint16(pos+34,page.height,true);
  v.setUint32(pos+36,page.jpg.length,true);v.setUint32(pos+40,zipCRC(page.jpg),true);v.setUint32(pos+44,i+1,true);
 }
 v.setUint32(16,zipCRC(raw.subarray(32)),true);v.setUint32(20,5,true);v.setUint32(28,zipCRC(raw.subarray(0,28)),true);
 return new Blob([raw]);
}
async function saveImageBook(book){
 if(byteLength(book.name)>96||/[\\/:*?"<>|\x00-\x1f]/.test(book.name)||book.name.includes('..'))throw Error('图片书名称过长或含有无效字符');
 const id=Array.from(crypto.getRandomValues(new Uint32Array(3)),n=>n.toString(16)).join('-'),dir='txt/upload-'+id;
 const owned=[];let temp='',committed=false;
 await fileOp('mkdir',dir);
 try{
  async function savePart(name,blob,i,total){
   checkUpload();const stagingName=id+'-'+name;
   await putMedia('inbox',stagingName,blob,i+'/'+total);temp='nanoos/inbox/'+stagingName;
   await fileOp('move',temp,dir+'/'+name);temp='';owned.push(dir+'/'+name);
  }
  const n=book.pages.length;
  for(const [i,page] of book.pages.entries()){
   page.file='page-'+String(i+1).padStart(4,'0')+'.jpg';await savePart(page.file,new Blob([page.jpg]),i+1,n+1);
  }
  await savePart('pages.nbp',bookIndex(book.pages),n+1,n+1);
  checkUpload();await fileOp('move',dir,'txt/'+book.name);committed=true;
 }finally{
  if(!committed){if(temp)await fileOp('delete',temp).catch(()=>{});for(const f of owned.reverse())await fileOp('delete',f).catch(()=>{});await fileOp('delete',dir).catch(()=>{});}
 }
}


async function uploadLocalFiles(kind,files){
 if(uploadBusy||!files.length||!uploadDialog?.open)return;
 uploadBusy=true;stopUpload=false;
 const imports={},saved=[],failed=[],dlg=uploadDialog,started=Date.now();
 dlg.querySelector('.up-pick').hidden=true;dlg.querySelector('.up-close').textContent='取消';
 try{
  for(const [i,file] of files.entries()){
   checkUpload();const batch=files.length>1?(i+1)+' / '+files.length:'';
   dlg.querySelector('.up-file').textContent=(batch?batch+' · ':'')+file.name;
   postJob('upload',{label:libraryNames[kind],status:'检查 '+file.name,done:i,goal:files.length,started});
   modalStep('检查文件',formatBytes(file.size));let detail='';
   try{
    const r=await prepareLocal(file,kind);checkUpload();
    if(r.skipped)detail='已跳过';
    else{
     if(r.pages)await saveImageBook(r);else await putMedia(kind,r.name,r.blob,batch);
     const path=({books:'txt',video:'mjpeg',music:'music'})[kind]+'/'+r.name+(r.pages?'/pages.nbp':'');
     if(r.tags)imports[path]=r.tags;
     saved.push(path);detail='已保存到 /'+path.replace(/\/pages\.nbp$/,'/');
    }
   }catch(e){if(stopUpload)throw e;detail=e.message;failed.push(file.name);}
   const line=document.createElement('li');line.textContent=file.name+' · '+detail;dlg.querySelector('.up-results').append(line);
  }
 }catch(e){if(!stopUpload)failed.push(e.message);}
 finally{
  uploadBusy=false;postJob('upload');
  if(saved.length){send(kind==='music'?'music-import':'media-upload',{kind,imports});}
  const result=stopUpload?'已取消':failed.length?'部分文件未保存':saved.length?'上传完成':'已跳过';
  modalStep(result,saved.length?'已保存 '+saved.length+' 个文件，资料库正在更新。':failed.length?'请查看文件旁的原因。':'',1,1);
  dlg.querySelector('.up-close').textContent='关闭';dlg.querySelector('.up-pick').hidden=false;dlg.querySelector('.up-pick').textContent='继续选择文件';
 }
}
async function deleteImageBook(path){
 const dir=path.slice(0,-'/pages.nbp'.length);let cursor=0,entries=[];
 do{const page=await api('/file-manager',{method:'POST',body:JSON.stringify({operation:'list',source:dir,cursor})});
  entries.push(...page.entries);cursor=page.next_cursor;
 }while(cursor);
 if(entries.some(e=>e.directory||!(/^(page-\d{4}\.jpg|pages\.nbp)$/.test(e.name))))throw Error('书籍目录含其他文件，请在文件管理中检查');
 const trash=dir.slice(0,dir.lastIndexOf('/')+1)+'remove-'+Array.from(crypto.getRandomValues(new Uint32Array(3)),n=>n.toString(16)).join('-');
 await fileOp('move',dir,trash);
 try{for(const e of entries)await fileOp('delete',trash+'/'+e.name);await fileOp('delete',trash);}
 catch{throw Error('书籍已移出资料库，剩余文件在 /'+trash);}
}

// Emby list requests, local selection and media transfers belong to the browser.
const embyViews=Object.fromEntries(['music','video'].map(kind=>[kind,{
 source:0,mode:'albums',sourceGeneration:0,members:new Map(),expanding:new Set(),folder:null,stack:[],offset:0,total:0,query:'',rows:[],chosen:new Map(),loaded:false,loading:false,error:'',generation:0
}]));
let importPicker;
function openImportPicker(kind){
 if(!ready){toast('资料库正在载入');return;}
 if(!importPicker){
  importPicker=document.createElement('dialog');importPicker.className='import-picker';
  importPicker.setAttribute('aria-labelledby','import-title');
  importPicker.innerHTML='<header><h2 id="import-title"></h2><button type="button" aria-label="关闭" class="icon-button">×</button></header><div class="import-body"></div>';
  importPicker.querySelector('button').onclick=()=>importPicker.close();
  document.body.append(importPicker);
 }
 importPicker.dataset.kind=kind;
 importPicker.querySelector('h2').textContent=kind==='books'?'从 OPDS 导入':'从 Emby 导入';
 drawImportPicker(kind);
 if(!importPicker.open)importPicker.showModal();
 if(kind!=='books'&&!embyViews[kind].loaded&&!embyViews[kind].loading)embyBrowse(kind);
}
function drawImportPicker(kind){
 if(importPicker?.dataset.kind===kind)
  importPicker.querySelector('.import-body').innerHTML=kind==='books'?catalogView():embyView(kind);
}
function embyApiBase(source){
 const u=new URL(source.url);u.search='';u.hash='';
 u.pathname=u.pathname.replace(/\/+$/,'');if(!u.pathname.endsWith('/emby'))u.pathname=u.pathname.replace(/\/$/,'')+'/emby';
 return u.href.replace(/\/$/,'');
}
async function embyFetch(source,url,large=false){
 const r=await fetchLibrarySource('/api/v1/emby',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+state.key},
  body:JSON.stringify({source,url,book:large}),signal:AbortSignal.timeout(large?1800000:30000)});
 if(r.status===401)authNeeded();
 if(!r.ok)throw Error((await r.json().catch(()=>null))?.error?.message||'Emby 读取失败（'+r.status+'）');
 return r;
}
const directoryTypes=new Set(['MusicAlbum','MusicArtist','Series','Season','BoxSet','Folder']);
function embyMedia(item,kind){
 const media=item.MediaSources?.[0]||{},stream=(media.MediaStreams||item.MediaStreams||[]),video=stream.find(s=>s.Type==='Video'),audio=stream.find(s=>s.Type==='Audio');
 const container=(media.Container||item.Container||'').split(',')[0].toLowerCase();
 const supported=kind==='music'?['mp3','flac','wav','aac']:['mp4','avi','mjpeg','mjpg'];
 let reason='';
 if(!supported.includes(container))reason='设备不支持 '+(container||'未知格式');
 else if(media.Size>268435456)reason='超过 256 MiB';
 else if(kind==='video'&&video){
  if(container==='mp4'&&(video.Codec&&video.Codec!=='h264'||video.Width>460||video.Height>460||video.RealFrameRate>24.1||video.RefFrames>2||video.Profile&&!/baseline/i.test(video.Profile)||audio?.Codec&&audio.Codec!=='aac'))reason='需 460×460、24 fps 以内的 H.264 Baseline 和 AAC 音频';
  else if(container==='avi'&&video.Codec&&!/mjpeg|mjpa|mjpb/i.test(video.Codec))reason='AVI 需使用 MJPEG 编码';
 }
 return {container,reason:kind==='music'&&media.Size>268435456?'超过 256 MiB':'',directPlayable:!reason&&!!video,sourceId:media.Id||item.Id,transcodable:media.SupportsTranscoding,size:media.Size||item.Size||0};
}
async function embyPage(kind,source,folder,offset,query,mode){
 const fields=kind==='video'||folder?.type==='MusicAlbum'?'Genres,MediaSources,MediaStreams,People':'Genres,ChildCount';
 const args=new URLSearchParams({Limit:'30',StartIndex:String(offset),Fields:fields,ImageTypeLimit:'1',EnableUserData:'false',SortBy:folder?.type==='MusicAlbum'?'ParentIndexNumber,IndexNumber,SortName':'SortName',SortOrder:'Ascending'});
 const types=kind==='music'?(folder?.type==='MusicAlbum'?'Audio':!folder&&mode==='artists'?'MusicArtist':'MusicAlbum'):(folder?.type==='Series'?'Season,Episode':folder?.type==='Season'?'Episode':'Movie,Series,MusicVideo,Video,Episode');
 args.set('IncludeItemTypes',types);args.set('Recursive',kind==='music'||!folder?'true':'false');
 if(folder){if(folder.type==='MusicArtist')args.set('ArtistIds',folder.id);else args.set('ParentId',folder.id);}
 if(query)args.set('SearchTerm',query);
 const entry=state.config?.emby?.sources?.[source];if(!entry)throw Error('服务器已移除');
 const response=await embyFetch(source,embyApiBase(entry)+'/Items?'+args),data=await response.json();
 if(!Array.isArray(data.Items))throw Error('Emby 未返回资料列表');
 const rows=data.Items.filter(x=>x.Id&&x.Name).map(x=>({id:String(x.Id),title:x.Name,type:x.Type,folder:directoryTypes.has(x.Type),artist:(x.Artists||[]).join('、')||x.AlbumArtist||'',album:x.Album||'',index:x.IndexNumber,series:x.SeriesName||'',creator:(x.People||[]).filter(p=>p.Type==='Director').map(p=>p.Name).filter(Boolean).join('、'),season:x.ParentIndexNumber,year:x.ProductionYear,genre:(x.Genres||[]).join(' / '),seconds:Math.round((x.RunTimeTicks||0)/1e7),image:x.ImageTags?.Primary?String(x.Id):x.AlbumPrimaryImageTag&&x.AlbumId?String(x.AlbumId):'',...embyMedia(x,kind)}));
 return {rows,total:data.TotalRecordCount??offset+rows.length,count:data.Items.length};
}
async function embyBrowse(kind,folder=null,offset=0,query=''){
 const v=embyViews[kind];if(!state.config?.emby?.sources?.[v.source])return;
 const seq=++v.generation;Object.assign(v,{folder,offset,query,error:'',loading:true});paintEmby(kind);
 try{const result=await embyPage(kind,v.source,folder,offset,query,v.mode);if(seq===v.generation)Object.assign(v,result,{loaded:true});}
 catch(e){if(seq===v.generation)Object.assign(v,{error:e.message,rows:[],total:0});}
 finally{if(seq===v.generation){v.loading=false;paintEmby(kind);}}
}
async function selectEmbyAlbum(kind,row,on){
 const v=embyViews[kind],source=v.source,generation=v.sourceGeneration;
 if(v.expanding.has(row.id))return;
 v.expanding.add(row.id);paintEmby(kind);
 try{
  let members=v.members.get(row.id);
  if(!members){members=[];let offset=0;const seen=new Set();do{
   const page=await embyPage(kind,source,row,offset,'','albums');if(v.sourceGeneration!==generation)return;
   const fresh=page.rows.filter(r=>!seen.has(r.id));if(page.count&&!fresh.length)throw Error('服务器重复返回同一页曲目');
   for(const r of fresh){seen.add(r.id);if(!r.reason&&!r.folder)members.push(r);}
   offset+=page.count;if(!page.count||offset>=page.total)break;
  }while(true);v.members.set(row.id,members);}
  for(const r of members){if(on)v.chosen.set(r.id,r);else v.chosen.delete(r.id);}
  if(!members.length)toast('这张专辑没有可导入的歌曲');
 }catch(e){if(v.sourceGeneration===generation)v.error=e.message;}
 finally{if(v.sourceGeneration===generation){v.expanding.delete(row.id);paintEmby(kind);}}
}
function embyView(kind){
 const v=embyViews[kind],sources=state.config?.emby?.sources||[],music=kind==='music';
 const manage=libButton(sources.length?'管理服务器':'添加 Emby 服务器','emby-sources');
 if(!sources.length)return panel('Emby 服务器','<p>添加自己的 Emby 服务器，即可导入'+(music?'音乐':'影片')+'。</p>'+manage);
 const chooser='<select aria-label="选择 Emby 服务器" id="emby-source">'+sources.map((s,i)=>'<option value="'+i+'" '+(i===v.source?'selected':'')+'>'+esc(s.name||s.url)+'</option>').join('')+'</select>';
 const category=v.folder?.type==='MusicAlbum'?'歌曲':v.folder?.type==='MusicArtist'||v.mode!=='artists'?'专辑':'艺人';
 const modes=music?'<div class="library-tabs">'+[['albums','专辑'],['artists','艺人']].map(([m,t])=>'<button class="button secondary" data-lib-emby-mode="'+m+'" aria-pressed="'+(v.mode===m)+'">'+t+'</button>').join('')+'</div>':'';
 const tools='<div class="library-tools">'+chooser+'<input type="search" id="emby-query" aria-label="搜索 Emby" placeholder="搜索'+(music?category:'影片或剧集')+'" value="'+esc(v.query)+'">'+libButton('搜索','emby-search')+manage+'</div>';
 const rows=v.rows.map((r,i)=>{
  const album=r.type==='MusicAlbum',members=v.members.get(r.id),checked=album?(members?.length&&members.every(t=>v.chosen.has(t.id))):v.chosen.has(r.id);
  const box=(!r.folder||album)?'<input type="checkbox" aria-label="'+(album?'整张选择':'选择')+'《'+esc(r.title)+'》" data-emby-select="'+i+'" '+(checked?'checked':'')+' '+(uploadBusy||v.expanding.has(r.id)||!r.folder&&r.reason?'disabled':'')+'>':'';
  const name=r.folder?'<button class="mc-track" data-lib-emby-folder="'+i+'">'+esc(r.title)+' ›</button>':'<label>'+box+' '+esc(r.title)+'</label>';
  const sub=r.folder?[r.type==='MusicArtist'?'艺人':album?'专辑':'目录',r.artist,r.year].filter(Boolean):[r.artist||r.series,r.container.toUpperCase(),r.reason].filter(Boolean);
  return '<li>'+(r.folder?box:'')+name+'<small>'+esc(sub.join(' · '))+'</small></li>';
 }).join('');
 return panel(v.folder?.title||'Emby 资料库',tools+modes+'<div class="library-actions">'+(v.stack.length?libButton('返回上级','emby-back'):'')+libButton('浏览来源','emby-browse')+'<button class="button primary" data-lib-emby-import '+(!v.chosen.size||v.expanding.size||uploadBusy?'disabled':'')+'>导入选中'+(music?'歌曲':'影片')+'（'+v.chosen.size+'）</button></div>'+
 (v.error?'<p role="alert">'+esc(v.error)+'</p>':v.loading||v.expanding.size?'<p role="status">正在读取'+(v.expanding.size?'专辑曲目':'资料库')+'…</p>':'')+
 '<ul class="library-rows emby-rows">'+rows+'</ul>'+(!rows&&v.loaded&&!v.error&&!v.loading?'<p>没有找到匹配的项目。</p>':'')+'<div class="library-actions">'+(v.offset?libButton('上一页','emby-page',Math.max(0,v.offset-30)):'')+(v.offset+30<v.total?libButton('下一页','emby-page',v.offset+30):'')+'</div>');
}
function paintEmby(kind){
 if(state.route!==kind)return;
 if(importPicker?.open)drawImportPicker(kind);
}
function embyFileName(item){
 let label=[item.artist,item.series,item.season?'S'+item.season:'',item.series&&item.index?'E'+item.index:'',item.title].filter(Boolean).join(' - ').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').replace(/\.{2,}/g,'_').replace(/^[. ]+|[. ]+$/g,'');
 const ext='.'+item.container;let clean='';
 for(const char of label){if(byteLength(clean+char+ext)>96)break;clean+=char;}
 return (clean||item.id)+ext;
}
const embyAssets=new Map();
async function embyCover(source,root,imageId){
 if(!imageId)return '';
 const url=root+'/Items/'+encodeURIComponent(imageId)+'/Images/Primary?MaxWidth=240&MaxHeight=240&Format=jpg';
 if(embyAssets.has(url))return embyAssets.get(url);
 const response=await embyFetch(source,url),blob=await response.blob();if(!blob.size||blob.size>131072)return '';
 const bytes=new Uint8Array(await blob.arrayBuffer());let id=0xcbf29ce484222325n;for(const b of bytes)id=BigInt.asUintN(64,(id^BigInt(b))*0x100000001b3n);
 const name=id.toString(16).padStart(16,'0')+'.ecv',saved=await fetch('/api/v1/files/upload?dir=catalog&name='+name,{method:'POST',headers:{Authorization:'Bearer '+state.key,'Content-Type':'application/octet-stream'},body:blob});
 if(!saved.ok&&saved.status!==409)throw Error('封面保存失败');
 embyAssets.set(url,name);return name;
}
function askOriginal(t,bytes,why,playable){
 if(!Number.isSafeInteger(bytes)||bytes<1)throw Error('服务器没有提供原片大小，无法确认下载');
 if(bytes>0xffffffff)throw Error('原片为 '+formatBytes(bytes)+'，超过当前 TF 文件接口的单文件上限（4 GiB − 1 字节）');
 const prompt='<p>'+esc(why)+'</p><p>将「'+esc(t.title)+'」的 '+esc(t.container.toUpperCase())+' 原片保存到 TF 卡 /mjpeg/。</p><p><strong>'+esc(formatBytes(bytes))+'（'+bytes.toLocaleString('zh-CN')+' 字节）</strong></p>'+(playable?'':'<p>可在 WebUI 管理此原片，设备可能无法播放。</p>');
 showSheet('下载原片？',prompt,'<button class="button secondary" id="original-skip">跳过</button><button class="button primary" id="original-save">确认下载原片</button>');
 return new Promise(resolve=>{const sheet=$('#sheet');let approved=false;
  sheet.addEventListener('close',()=>resolve(approved),{once:true});
  $('#original-skip').onclick=()=>sheet.close();$('#original-save').onclick=()=>{approved=true;sheet.close();};});
}
async function originalRequest(source,url,extra){
 const r=await fetch('/api/v1/emby',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+state.key},body:JSON.stringify({source,url,book:true,...extra}),signal:AbortSignal.timeout(extra.original==='size'?30000:14400000)});
 if(!r.ok)throw Error((await r.json().catch(()=>null))?.error?.message||'原片读取失败（'+r.status+'）');
 return r.json();
}
async function saveEmbyVideo(source,root,t,onStage){
 const url=root+'/Items/'+encodeURIComponent(t.id)+'/Download';let reason='服务器未提供转码。';
 if(t.transcodable!==false&&t.seconds<=3600){
  const args=new URLSearchParams({MediaSourceId:t.sourceId||t.id,PlaySessionId:Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join(''),
   Static:'false',VideoCodec:'h264',Profile:'baseline',Level:'3.0',AudioCodec:'aac',AudioSampleRate:'44100',AudioBitrate:'96000',MaxAudioChannels:'2',VideoBitrate:'600000',MaxWidth:'460',MaxHeight:'460',MaxFramerate:'20',EnableAutoStreamCopy:'false',AllowVideoStreamCopy:'false',AllowAudioStreamCopy:'false'});
  let output;
  try{onStage('服务器转码');const response=await embyFetch(source,root+'/Videos/'+encodeURIComponent(t.id)+'/stream.mp4?'+args,true);
   const stream=await response.blob();if(stream.size>268435456||!stream.size)throw Error('转码文件大小超限');
   output=await encodeForDevice(stream,onStage);
  }catch(e){if(state.needsKey)throw e;reason='转码未完成：'+e.message;}
  if(output){const name=embyFileName({...t,container:'avi'});onStage('写入 TF 卡');await putMedia('video',name,output);return {name,devicePlayable:true,original:false};}
 }else if(t.seconds>3600)reason='影片时长超过设备播放器的一小时上限。';
 if(!/^[a-z0-9]{1,8}$/i.test(t.container))throw Error('服务器没有提供原片格式');
 const bytes=t.size||(await originalRequest(source,url,{original:'size'})).bytes;
 onStage('等待确认原片大小');if(!await askOriginal(t,bytes,reason,t.directPlayable))return null;
 const name=embyFileName(t);onStage('保存原片');
 await originalRequest(source,url,{original:'save',name,bytes});return {name,original:true,devicePlayable:t.directPlayable};
}
async function embyImport(kind){
 const v=embyViews[kind],source=v.source,entry=state.config.emby?.sources?.[source];if(uploadBusy||!entry||!ready)return;
 const items=[...v.chosen.values()];if(!items.length){toast('请先选择要导入的项目');return;}
 if(kind==='music'){
  openUploadDialog(kind);uploadDialog.querySelector('h2').textContent='从 Emby 导入音乐';
  uploadDialog.querySelector('.up-pick').hidden=true;uploadDialog.querySelector('.up-close').textContent='取消';
 }
 uploadBusy=true;const imports={},failed=[],warnings=[],started=Date.now();let count=0;
 try{const root=embyApiBase(entry);
  for(const [i,t] of items.entries()){
   postJob('emby',{label:'Emby',status:'导入 '+t.title,done:i,goal:items.length,started});
   try{
    let file;
    if(kind==='video'){
     const stage=status=>postJob('emby',{label:'视频',status:status+' · '+t.title,done:i,goal:items.length,started});
     file=await saveEmbyVideo(source,root,t,stage);if(!file)continue;
    }else{
     checkUpload();uploadDialog.querySelector('.up-file').textContent=(i+1)+' / '+items.length+' · '+t.title;
     modalStep('从 Emby 下载原文件',t.title);
     const name=embyFileName(t),res=await embyFetch(source,root+'/Items/'+encodeURIComponent(t.id)+'/Download',true);
     const raw=await res.blob();checkUpload();if(t.size&&raw.size!==t.size)throw Error('下载不完整');
     modalStep('检查音频',formatBytes(raw.size));
     const prepared=await prepareLocal(new File([raw],name),kind);checkUpload();
     const ext=prepared.name.split('.').pop();
     file={name:embyFileName({...t,container:ext})};await putMedia(kind,file.name,prepared.blob);
    }
    const name=file.name;
    let coverAsset='';try{coverAsset=await embyCover(source,root,t.image);}catch{warnings.push(t.title+'：封面未导入');}
    const path=(kind==='music'?'music/':'mjpeg/')+name;
    const tag=kind==='music'?{title:t.title,artist:t.artist,album:t.album,track:t.index?String(t.index):'',seconds:t.seconds}:{title:t.title,creator:t.creator,series:t.series,category:t.genre,importedAt:Date.now(),sourceFormat:file.original?'original':'transcoded',devicePlayable:file.devicePlayable?'yes':'no'};
    imports[path]=Object.fromEntries(Object.entries({...tag,coverAsset}).filter(([,value])=>value));v.chosen.delete(t.id);count++;
   }catch(e){if(kind==='music'&&stopUpload)break;failed.push(t.title+'：'+e.message);}
  }
  if(count){if(kind==='music')send('music-import',{imports});else send('media-upload',{kind,imports});if(kind==='video'){setTab('影片');toast('已导入 '+count+' 部影片，保存在 TF 卡 /mjpeg/');}else toast('已导入 '+count+' 首歌曲');}
  if(kind==='music'){
   modalStep(stopUpload?'已取消':failed.length?'部分歌曲未导入':'导入完成','已保存 '+count+' / '+items.length+' 首',1,1);
   for(const message of [...failed,...warnings]){const li=document.createElement('li');li.textContent=message;uploadDialog.querySelector('.up-results').append(li);}
   uploadDialog.querySelector('.up-close').textContent='关闭';
  }else if(failed.length||warnings.length)showSheet('导入结果','<ul>'+[...failed,...warnings].map(s=>'<li>'+esc(s)+'</li>').join('')+'</ul>');
 }finally{uploadBusy=false;postJob('emby');paintEmby(kind);}
}
document.addEventListener('click',e=>{
 const a=e.target.closest('button')?.dataset,kind=state.route,v=embyViews[kind];if(!a||!v)return;
 if('libEmbyLaunch'in a)openImportPicker(kind);
 if('libEmbySources'in a)openEmbySources();
 if('libEmbyMode'in a){v.mode=a.libEmbyMode;v.stack=[];embyBrowse(kind);}
 if('libEmbyBrowse'in a){v.stack=[];embyBrowse(kind);}
 if('libEmbySearch'in a)embyBrowse(kind,v.folder,0,$('#emby-query').value.trim());
 if('libEmbyFolder'in a){const r=v.rows[Number(a.libEmbyFolder)];v.stack.push([v.folder,v.offset,v.query]);embyBrowse(kind,r);}
 if('libEmbyBack'in a&&v.stack.length)embyBrowse(kind,...v.stack.pop());
 if('libEmbyPage'in a)embyBrowse(kind,v.folder,Number(a.libEmbyPage),v.query);
 if('libEmbyImport'in a)embyImport(kind);
});
document.addEventListener('change',e=>{
 const kind=state.route,v=embyViews[kind];if(!v)return;
 if(e.target.id==='emby-source'){v.source=Number(e.target.value);v.sourceGeneration++;v.expanding.clear();v.members.clear();v.stack=[];v.chosen.clear();embyBrowse(kind);}
 if(e.target.dataset.embySelect!==undefined){const r=v.rows[Number(e.target.dataset.embySelect)];if(r.type==='MusicAlbum'){selectEmbyAlbum(kind,r,e.target.checked);return;}if(e.target.checked)v.chosen.set(r.id,r);else v.chosen.delete(r.id);paintEmby(kind);}
});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='emby-query'){const value=e.target.value.trim();e.target.blur();embyBrowse(state.route,embyViews[state.route].folder,0,value);}});
let embyDraft=null;
function openEmbySources(){
 const rows=collection('emby.sources').map(r=>({id:r.id,index:r.index,data:{...r.data},user:'',credential:'',mode:'login'}));
 embyDraft={rows,revision:state.revision,saving:false};if(!rows.length)addEmbySource();drawEmbySources();
}
function addEmbySource(){embyDraft.rows.push({id:'new-'+crypto.getRandomValues(new Uint32Array(1))[0],index:null,data:{name:'',url:'',password:''},mode:'login',user:'',credential:''});}
function drawEmbySources(){
 const d=embyDraft;if(!d)return;
 const field=(i,key,label,value,type='text')=>'<label class="field"><span>'+label+'</span><input data-emby-input="'+key+'" data-i="'+i+'" type="'+type+'" autocomplete="'+(type==='password'?'new-password':'off')+'" value="'+(type==='password'?'':esc(value||''))+'"></label>';
 showSheet('Emby 服务器',d.rows.map((r,i)=>'<section class="entry-card"><div class="entry-card-header"><strong>'+esc(r.data.name||'新服务器')+'</strong><button class="icon-button" data-emby-delete="'+i+'" aria-label="移除服务器">'+icon('trash')+'</button></div><div class="form-grid">'+field(i,'name','名称',r.data.name)+field(i,'url','服务器地址',r.data.url,'url')+'<label class="field"><span>登录方式</span><select data-emby-mode="'+i+'"><option value="login">账号和密码</option><option value="key" '+(r.mode==='key'?'selected':'')+'>API 密钥</option></select></label>'+(r.mode==='login'?field(i,'user','Emby 用户名',r.user):'')+field(i,'credential',r.mode==='login'?'Emby 密码':'API 密钥','','password')+'</div>'+(r.index!==null&&r.data.password_configured?'<small>已保存访问凭据。只改名称时，登录信息可留空。</small>':'')+'</section>').join('')+'<button class="button secondary" data-emby-add '+(d.rows.length>=8?'disabled':'')+'>添加服务器</button><p id="emby-login-error" role="alert"></p>','<button class="button primary" data-emby-save>保存来源</button>');
 for(const input of $$('#sheet [data-emby-input="credential"]'))input.value=d.rows[Number(input.dataset.i)].credential;
}
async function saveEmbySources(){
 const d=embyDraft;if(!d||d.saving)return;d.saving=true;const sheet=$('#sheet');sheet.querySelectorAll('button,input,select').forEach(b=>b.disabled=true);
 try{
  if(d.revision!==state.revision)throw Error('设备配置已更新，请重新打开服务器列表');
  const rows=[];
  for(const r of d.rows){
   const data={...r.data,name:r.data.name.trim(),url:r.data.url.trim()};let url;
   try{url=new URL(data.url);}catch{throw Error('请填写完整的服务器地址');}
   if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.hash||url.search||!data.name||byteLength(data.name)>63||byteLength(data.url)>511)throw Error('请检查服务器名称和地址');
   const old=state.config.emby?.sources?.[r.index];
   if(r.user||r.credential||!old?.password_configured||old.url!==data.url){
    if(r.mode==='key'){if(!r.credential)throw Error('请填写 Emby API 密钥');data.password=r.credential;}
    else{
     if(!r.user.trim())throw Error('请填写 Emby 用户名');
     let deviceId=localStorage.getItem('nano.emby.device');if(!/^[a-f0-9]{32}$/.test(deviceId||'')){deviceId=Array.from(crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join('');localStorage.setItem('nano.emby.device',deviceId);}
     data.password=await new Promise((resolve,reject)=>{
      const login=new Worker('/emby-login.js');
      const timer=setTimeout(()=>{login.terminate();reject(Error('Emby 登录超时'));},25000);
      login.onmessage=({data})=>{clearTimeout(timer);login.terminate();if(data.token)resolve(data.token);else reject(Error(data.error));};
      login.onerror=()=>{clearTimeout(timer);login.terminate();reject(Error('无法连接 Emby 登录服务'));};
      login.postMessage({url:embyApiBase(data)+'/Users/AuthenticateByName',id:deviceId,user:r.user.trim(),password:r.credential});
     });
    }
    if(byteLength(data.password)>127)throw Error('访问凭据超出设备可保存的长度');
   }
   rows.push({id:r.id,index:r.index,data});
  }
  if(embyDraft!==d||!sheet.open)return;
  state.collections['emby.sources']=rows;collectionChanges('emby.sources');
  if(hasChanges())await saveChanges();else sheet.close();
 }catch(e){if(embyDraft===d)$('#emby-login-error').textContent=e.message==='Failed to fetch'?'浏览器无法连接 Emby，请检查地址和跨域设置。':e.message;}
 finally{if(embyDraft===d){d.saving=false;sheet.querySelectorAll('button,input,select').forEach(b=>b.disabled=b.hasAttribute('data-emby-add')&&d.rows.length>=8);}}
}
$('#sheet').addEventListener('close',()=>{if(embyDraft){embyDraft=null;$('#sheet-body').replaceChildren();if(importPicker?.open)drawImportPicker(importPicker.dataset.kind);}});
document.addEventListener('input',e=>{const a=e.target.dataset;if(!embyDraft||!a.embyInput)return;const r=embyDraft.rows[Number(a.i)];if(['name','url'].includes(a.embyInput))r.data[a.embyInput]=e.target.value;else r[a.embyInput]=e.target.value;});
document.addEventListener('change',e=>{const i=e.target.dataset.embyMode;if(i===undefined||!embyDraft)return;const r=embyDraft.rows[Number(i)];r.mode=e.target.value;r.credential='';r.user='';drawEmbySources();});
document.addEventListener('click',e=>{const a=e.target.closest('button')?.dataset;if(!embyDraft||!a)return;
 if('embyAdd'in a&&embyDraft.rows.length<8){addEmbySource();drawEmbySources();}
 if('embyDelete'in a){embyDraft.rows.splice(Number(a.embyDelete),1);drawEmbySources();}
 if('embySave'in a)saveEmbySources();
});

const panes={
 music:{tabs:['专辑','艺人','歌曲','播放列表','管理目录'],accept:'.flac,.mp3,.wav,.aac',dir:'tracks'},
 books:{tabs:['书籍','分类','作者','管理目录'],accept:'.txt,.epub',dir:'reads'},
 video:{tabs:['影片','分类','创作者','管理目录'],accept:'.mp4,.avi,.mjpg,.mjpeg',dir:'movies'}
};
const views=Object.fromEntries(Object.entries(panes).map(([k,p])=>[k,{tab:p.tabs[0],filter:'',query:'',category:'',creator:'',facets:{category:[],creator:[]},offset:0,total:0,rows:[],roots:[],visited:false}]));
const jobs=new Map();let ready=false,uploadBusy=false,lastBeat=0;
let transfer=null,transferTimer;
function showTransfer(stage,name,loaded,total,batch='',error=false){
 clearTimeout(transferTimer);
 transfer={stage,name,loaded,total,batch,error};
 drawTransfer();
}
function drawTransfer(){
 const panel=$('#transfer-progress');
 if(!panel)return;
 panel.hidden=!transfer||!panes[state.route]||uploadDialog?.open;if(panel.hidden)return;
 const {stage,name,loaded,total,batch,error}=transfer,determinate=Number.isFinite(loaded)&&total>0;
 $('#transfer-stage').textContent=stage+(batch?' · '+batch:'');
 $('#transfer-filename').textContent=name;$('#transfer-filename').title=name;
 const meter=$('#transfer-meter');
 if(determinate)meter.value=Math.floor(100*loaded/total);else meter.removeAttribute('value');
 $('#transfer-size').textContent=determinate?meter.value+'% · '+formatBytes(loaded)+' / '+formatBytes(total):'';
 panel.toggleAttribute('data-error',error);
}
function finishTransfer(success,message){
 if(!transfer)return;
 const t=transfer;showTransfer(success?'已保存':'上传失败',success?t.name:message,t.loaded,t.total,t.batch,!success);
 transferTimer=setTimeout(()=>{transfer=null;drawTransfer();},success?6000:15000);
}
const libButton=(label,attr,val='',primary=false)=>'<button class="button '+(primary?'primary':'secondary')+'" data-lib-'+attr+'="'+esc(val)+'">'+esc(label)+'</button>';
function jobText(){
 return [...jobs.values()].map(j=>{
  const rate=j.done>0?(Date.now()-j.started)/j.done:0,seconds=Math.max(1,Math.ceil(rate*(j.goal-j.done)/1000));
  const eta=!rate||!j.goal?'正在估算时间':seconds>=60?'约剩 '+Math.ceil(seconds/60)+' 分钟':'约剩 '+seconds+' 秒';
  return j.label+' · '+j.status+(j.goal?' '+j.done+'/'+j.goal:'')+' · '+eta;
 }).join(' ｜ ');
}
function updateJobs(){
 drawTransfer();
 const banner=$('#library-job');banner.classList.toggle('hidden',!jobs.size);
 if(jobs.size){
  const j=jobs.get('upload')||jobs.get('encode')||jobs.get('emby')||jobs.values().next().value;
  $('#job-stage').textContent=j.status;
  if(j===jobs.get('upload')&&uploadDialog?.open)$('#job-count').textContent='';
  else $('#job-count').textContent=(j===jobs.get('upload')&&transfer)?(transfer.total&&Number.isFinite(transfer.loaded)?Math.floor(100*transfer.loaded/transfer.total)+'%':transfer.stage):j.goal?j.done+'/'+j.goal+(j.done?' · 约 '+Math.max(1,Math.ceil((Date.now()-j.started)*(j.goal-j.done)/j.done/1000))+' 秒':''):'整理中';
  $('#job-detail').textContent=jobText()+'。请保持浏览器打开、设备联网。';
 }else banner.open=false;
 if(jobs.size&&state.connected&&!state.needsKey&&Date.now()-lastBeat>=20000){
  lastBeat=Date.now();if(document.hidden)api('/status').then(s=>{state.status=s;gateWorker();}).catch(()=>{});api('/activity',{method:'POST'}).catch(()=>{});
 }
}
function postJob(key,j){if(j)jobs.set(key,j);else jobs.delete(key);updateJobs();}
function refreshPage(kind){
 if(!ready||!panes[kind])return;
 if(kind==='music'){clientQuery();return;}
 const v=views[kind],tab=v.tab;
 if(['管理目录','OPDS 导入','播放列表','从 Emby 导入'].includes(tab))return;
 if(kind==='music')send('browse-music',{tab,artist:v.filter,offset:v.offset});
 else send('media-browse',{kind,tab,field:tab==='分类'?'category':['作者','创作者'].includes(tab)?'creator':'',filter:v.filter,offset:v.offset,query:v.query,category:v.category,creator:v.creator,request:v.request=(v.request||0)+1});
}
function enter(kind){
 if(!ready||!panes[kind])return;
 const v=views[kind];
 if(!v.visited){v.visited=true;if(kind==='music'){if(library.roots.length)send('scan');}else send('media-refresh',{kind});}
 refreshPage(kind);pending();
}
function pending(){
 const p=state.libraryPending;if(!ready||!p)return;
 state.libraryPending=null;openUploadDialog(p.kind,p.files);
}
function paintLibraries(){
 if(importPicker?.open&&importPicker.dataset.kind==='books')drawImportPicker('books');
 updateJobs();if(!panes[state.route]||!window.nanoLibraries)return;
 if(state.route==='music'&&$('#mc-body')){if(client.tab==='管理目录')paintClient();return;}
 if(document.activeElement?.matches('#opds-query,#emby-query,[data-collection]'))return;
 $('#content').innerHTML=libraryView(state.route);hydrateIcons($('#content'));loadPosters();
}
function catalogView(){
 const sources=state.config.opds?.sources||[];
 const head='<div class="library-tools"><label class="field"><span>书库来源</span><select id="opds-source">'+sources.map((s,i)=>'<option value="'+i+'" '+(i===catalog.source?'selected':'')+'>'+esc(s.name||s.url)+'</option>').join('')+'</select></label>'+libButton('浏览来源','opds-open')+libButton('管理来源','sources')+'</div>';
 if(!sources.length)return panel('OPDS 导入','<p>添加 OPDS 书库地址后，可按分类浏览并一次导入多本书。</p>'+libButton('添加书库来源','sources','',true));
 const match=text=>!catalog.query||text.toLowerCase().includes(catalog.query.toLowerCase());
 const items=catalog.books.map((b,i)=>({...b,i})).filter(b=>match(b.title+' '+b.creator));
 const nav=catalog.nav.filter(x=>match(x.title)).map(n=>libButton(n.title,'opds-url',n.href)).join('');
 const rows=items.map(b=>'<li><label><input type="checkbox" data-opds-book="'+b.i+'" '+(b.unsupported?'disabled':catalog.chosen.has(b.href)?'checked':'')+'> '+esc(b.title)+'</label><small>'+esc([b.creator,b.unsupported?b.unsupported+' · 可导入 EPUB 或 TXT':''].filter(Boolean).join(' · '))+'</small></li>').join('');
 return panel('OPDS 导入',head+(catalog.error?'<p role="alert">'+esc(catalog.error)+'</p>':'')+
  (catalog.loading?'<p>正在读取书库…</p>':'')+('<div class="library-tools"><input id="opds-query" aria-label="搜索书籍" placeholder="搜索书名或作者" value="'+esc(catalog.query)+'">'+libButton('搜索','opds-search')+(catalog.stack.length?libButton('返回上级','opds-back'):'')+'</div><div class="library-actions">'+nav+'</div><ul class="library-rows">'+rows+'</ul>'+
  (catalog.next?libButton('下一页','opds-url',catalog.next):'')+libButton('导入选中书籍（'+catalog.chosen.size+'）','opds-import','',true)));
}
const posterCache=new Map();
async function loadPosters(){
 for(const el of document.querySelectorAll('[data-library-poster]')){
  const name=el.dataset.libraryPoster;if(!/^[0-9a-f]{16}\.ecv$/.test(name))continue;
  if(!posterCache.has(name)){
   const pending=fetch('/api/v1/files/download?dir=catalog&name='+name,{headers:{Authorization:'Bearer '+state.key}}).then(async r=>{
    if(!r.ok)return '';
    const blob=await r.blob();if(blob.size>131072)return '';
    const reader=new FileReader();return new Promise(resolve=>{reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>resolve('');reader.readAsDataURL(new Blob([blob],{type:'image/jpeg'}));});
   }).catch(()=>'');
   if(posterCache.size>=48)posterCache.delete(posterCache.keys().next().value);posterCache.set(name,pending);
  }
  const url=await posterCache.get(name);if(!el.isConnected||!url)continue;
  const img=new Image();img.alt='';img.src=url;el.replaceChildren(img);
 }
}
function libraryView(kind){
 if(kind==='music')return clientView();
 const v=views[kind],name=libraryNames[kind],author=kind==='books'?'作者':'创作者';
 const icons={书籍:'book',影片:'video',分类:'apps',作者:'book',创作者:'video',管理目录:'settings'};
 const nav=panes[kind].tabs.map(t=>'<button data-lib-tab="'+t+'" aria-current="'+(v.tab===t?'page':'false')+'">'+icon(icons[t])+'<span>'+t+'</span></button>').join('');
 const select=(key,label)=>'<label>'+label+' <select data-meta-filter="'+key+'"><option value="">全部</option>'+v.facets[key].map(value=>'<option '+(v[key]===value?'selected ':'')+'value="'+esc(value)+'">'+esc(value)+'</option>').join('')+'</select></label>';
 const filters=v.tab==='管理目录'?'':'<form class="media-filters"><input type="search" data-media-query aria-label="搜索'+name+'" placeholder="搜索标题、'+author+'或分类" value="'+esc(v.query)+'">'+select('category','分类')+select('creator',author)+'<button class="button secondary">搜索</button></form>';
 return '<div class="mc-shell"><nav class="mc-nav" aria-label="'+name+'资料库">'+nav+'</nav><section class="mc-main">'+filters+mediaBody(kind,v)+'</section></div>';
}
function mediaBody(kind,v){
 const controls='';
 if(v.tab==='管理目录'){
  
  return controls+panel('管理目录',(v.roots||[]).map(p=>'<div class="setting-row"><strong>/'+esc(p)+'</strong>'+libButton('移除','remove-dir',p)+'</div>').join('')+'<div class="library-actions">'+libButton('添加目录','folder','',true)+libButton('重新整理','rescan')+'</div>');
 }
 const entries=v.rows.map((r,i)=>'<li><span class="file-icon" '+(r.coverAsset?'data-library-poster="'+esc(r.coverAsset)+'"':'')+'>'+icon(kind==='music'?'music':kind==='books'?'book':'video')+'</span><div class="file-main"><strong>'+esc(r.title)+'</strong><small>'+esc([r.sub,r.original?'原片':'',r.unplayable?'仅存档':''].filter(Boolean).join(' · '))+'</small></div>'+(r.unplayable?'':libButton(r.path?(kind==='books'?'阅读':'播放'):'查看','row',i))+libraryDeleteButton(r.path,r.title)+'</li>').join('');
 return controls+panel(v.filter||v.tab,(v.filter?libButton('返回'+v.tab,'group-back'):'')+
  (entries?'<ul class="library-rows">'+entries+'</ul>':'<p>这里还没有内容。可从右上角上传文件，或在管理目录中选择 TF 卡目录。</p>')+
  '<div class="library-actions">'+(v.offset?libButton('上一页','page',Math.max(0,v.offset-24)):'')+(v.total?'<small class="library-count">共 '+v.total+' 项</small>':'')+(v.offset+24<v.total?libButton('下一页','page',v.offset+24):'')+'</div>');
}
function libraryMessage(m){
 if(m.type==='local-music-ready'){refreshPage('music');return true;}
 if(clientMessage(m))return true;
 if(m.type==='initialized'){ready=true;enter(state.route);return true;}
 if(m.type==='status'){
  if(m.running&&!paused)postJob('music',{label:'音乐',status:lastGate?'等待设备空闲':m.statusText,done:m.progressDone||0,goal:m.progressGoal||0,started:m.progressStart||Date.now()});else postJob('music');return false;
 }
 if(m.type==='media-job'){
  postJob(m.kind,m.running?{label:libraryNames[m.kind],...m}:null);if(m.error)toast(m.error,true);return true;
 }
 if(m.type==='media-directories'){views[m.kind].roots=m.roots;paintLibraries();return true;}
 if(m.type==='media-updated'){refreshPage(m.kind);return true;}
 if(m.type==='music-page'||m.type==='media-page'){
  const k=m.kind||'music',v=views[k];
  if(v.tab!==m.tab||v.offset!==m.offset||v.filter!==(m.filter||m.artist||'')||(m.type==='media-page'&&m.request!==v.request))return true;
  if(v.offset>0&&v.offset>=m.total){v.offset=24*Math.floor(Math.max(0,m.total-1)/24);refreshPage(k);return true;}
  Object.assign(v,{rows:m.rows,total:m.total});if(m.facets)v.facets=m.facets;if(k===state.route)paintLibraries();return true;
 }return false;
}
async function encodeForDevice(file,onStage){
 const result=await runCodec(file,'video',false,false,onStage);
 return new Blob([result.output],{type:'video/x-msvideo'});
}
async function putMedia(kind,name,blob,batch=''){
 const limit=(kind==='books'?0:state.caps.limits.media_upload_bytes)||state.caps.limits.upload_bytes||33554432;
 if(!blob.size||blob.size>limit)throw Error(name+' 超出单文件大小限制（'+formatBytes(limit)+'）');
 if(byteLength(name)>96||/[\\/:*?"<>|\x00-\x1f]/.test(name)||name.includes('..')||/^[. ]|[. ]$/.test(name))throw Error('文件名无效或超过 96 字节');
 showTransfer('正在上传',name,0,blob.size,batch);
 await new Promise((resolve,reject)=>{
  const xhr=new XMLHttpRequest();if(uploadDialog?.open)activeRequest=xhr;
  const fail=message=>{finishTransfer(false,message);reject(Error(message));};
  xhr.open('POST','/api/v1/files/upload?dir='+(kind==='inbox'?'inbox':panes[kind].dir)+'&name='+encodeURIComponent(name));
  xhr.timeout=kind==='books'?120000:1800000;xhr.responseType='json';
  xhr.setRequestHeader('Content-Type','application/octet-stream');
  xhr.setRequestHeader('Authorization','Bearer '+state.key);
  if(uploadDialog?.open)modalStep('正在上传',name,0,blob.size);
  xhr.addEventListener('loadend',()=>{if(activeRequest===xhr)activeRequest=null;});
  xhr.upload.onprogress=e=>{if(uploadDialog?.open)modalStep(e.loaded>=blob.size?'设备正在保存':'正在上传',formatBytes(e.loaded)+' / '+formatBytes(blob.size)+' · '+Math.min(100,Math.floor(e.loaded*100/blob.size))+'%',e.loaded,blob.size);showTransfer(e.loaded>=blob.size?'设备正在保存':'正在上传',name,Math.min(e.loaded,blob.size),blob.size,batch);updateJobs();};
  xhr.onload=()=>{if(xhr.status===401)authNeeded();if(xhr.status===201&&xhr.response?.ok){
    showTransfer('设备已保存',name,blob.size,blob.size,batch);finishTransfer(true);resolve();
   }else fail(xhr.response?.error?.message||'设备未确认保存（'+xhr.status+'）');};
  xhr.onerror=()=>fail('网络中断，请检查连接后重试');xhr.ontimeout=()=>fail('上传超时，请重试');
  xhr.onabort=()=>fail('上传已取消');xhr.send(blob);
 });
}
async function runUploads(kind,files,importing=false){
 if(!importing)return uploadLocalFiles(kind,files);
 if(uploadBusy||!ready){toast('资料工具正忙，请稍后重试');return;}if(!files.length)return;
 uploadBusy=true;const started=Date.now(),imports={},success=[],fail=[];
 try{
  for(let i=0;i<files.length;i++){
   const f=files[i];let name=importing?f.title.replace(/[\\/:*?"<>|]/g,'_')+(f.epub?'.epub':'.txt'):f.name;
   postJob('upload',{label:libraryNames[kind],status:(importing?'导入 ':'上传 ')+name,done:i,goal:files.length,started});
   try{
    if(!panes[kind].accept.split(',').includes('.'+name.split('.').pop().toLowerCase()))throw Error('不支持该格式');
    let blob=importing?await opdsRead(f.href,true):f;
    let tags={};
    if(kind==='books'){
     if(blob.size>33554432)throw Error('书籍超过 32 MiB');
     if(/\.epub$/i.test(name)){const parsed=await loadEpub(blob);blob=parsed.blob;tags=parsed.metadata;name=name.replace(/\.epub$/i,'.txt');}
     else {const bytes=new Uint8Array(await blob.arrayBuffer());
      let encoding=bytes[0]===255&&bytes[1]===254?'utf-16le':bytes[0]===254&&bytes[1]===255?'utf-16be':'utf-8';
      try{new TextDecoder(encoding,{fatal:true}).decode(bytes);}catch{encoding='gb18030';}
      if(encoding!=='utf-8')blob=new Blob([new TextDecoder(encoding).decode(bytes)]);
     }
     if(importing)for(const field of ['title','creator','category'])if(f[field])tags[field]=f[field];
    }
    if(importing&&byteLength(name)>96){
     let hash=2166136261;for(const n of new TextEncoder().encode(f.href))hash=Math.imul(hash^n,16777619);
     const suffix='-'+(hash>>>0).toString(16)+'.txt';let prefix='';
     for(const char of name.slice(0,-4)){if(byteLength(prefix+char+suffix)>96)break;prefix+=char;}
     name=prefix+suffix;
    }
    await putMedia(kind,name,blob,files.length>1?(i+1)+'/'+files.length:'');success.push(name);
    if(kind==='books')imports['txt/'+name]=Object.fromEntries(Object.entries(tags).filter(([,v])=>typeof v==='string'&&v.trim()).map(([k,v])=>[k,v.slice(0,160)]));
    if(importing)catalog.chosen.delete(f.href);
   }catch(e){fail.push(name+'：'+e.message);}
  }
  if(success.length){if(kind==='music')send('music-import');else send('media-upload',{kind,imports});toast('已保存 '+success.length+' 个文件，正在整理元信息');}
  if(fail.length)showSheet('部分文件未导入','<ul>'+fail.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ul>');
 }finally{uploadBusy=false;postJob('upload');paintLibraries();}
}
let folderSequence=0;
async function mediaFolder(path='',cursor=0){
 const kind=state.route,id=++folderSequence;
 try{const r=await api('/file-manager',{method:'POST',body:JSON.stringify({operation:'list',source:path,cursor})});
  if(kind!==state.route||folderSequence!==id)return;
  const dirs=r.entries.filter(e=>e.directory&&(path||e.name!=='nanoos')).map(e=>libButton(e.name,'folder',fileJoin(path,e.name))).join('');
  showSheet('选择资料目录','<p>/'+esc(path)+'</p><div class="library-actions">'+(path?libButton('上级目录','folder',path.split('/').slice(0,-1).join('/')):'')+dirs+'</div>'+(r.next_cursor?libButton('下一页','folder-next',JSON.stringify([path,r.next_cursor])):''),path?libButton('管理此目录','use-dir',path,true):'');
 }catch(e){toast(e.message,true);}
}
function setTab(tab,filter=''){const v=views[state.route];Object.assign(v,{tab,filter,offset:0,rows:[],total:0});paintLibraries();refreshPage(state.route);}
document.addEventListener('click',event=>{
 const b=event.target.closest('button');if(!b||!panes[state.route])return;
 const k=state.route,v=views[k],a=b.dataset;
 if('libUpload'in a){if(!ready){toast('资料库正在准备，请稍后重试');return;}openUploadDialog(k);}
 if('libOpdsLaunch'in a)openImportPicker('books');
 if(a.libTab)setTab(a.libTab);
 if('libPage'in a){v.offset=Number(a.libPage);refreshPage(k);}
 if('libGroupBack'in a)setTab(v.tab==='歌曲'?'艺人':v.tab);
 if('libRow'in a){const r=v.rows[Number(a.libRow)];if(!r)return;
  if(r.id){albumId=r.id;sheetType='album';send('album',{id:r.id,offset:0});}
  else if(r.artist)setTab('歌曲',r.artist);
  else if(r.group)setTab(v.tab,r.group);
  else if(r.path)command('open',k==='books'?'book':k,{path:'/sdcard/'+r.path});
 }
 if('libRescan'in a)send('media-refresh',{kind:k,force:true});
 if('libFolder'in a)mediaFolder(a.libFolder);
 if(a.libFolderNext)mediaFolder(...JSON.parse(a.libFolderNext));
 if(a.libUseDir||a.libRemoveDir){send('media-roots',{kind:k,path:a.libUseDir||a.libRemoveDir,remove:!!a.libRemoveDir});if($('#sheet').open)$('#sheet').close();}
 if('libSources'in a){showSheet('OPDS 书库来源',collectionView('opds.sources'),'<button class="button primary" data-save-sheet>保存来源</button>','书籍');}
 if('libOpdsOpen'in a){const source=state.config.opds.sources[catalog.source];if(source)openFeed(source.url);}
 if(a.libOpdsUrl)openFeed(a.libOpdsUrl);
 if('libOpdsBack'in a&&catalog.stack.length)openFeed(catalog.stack.pop(),true);
 if('libOpdsSearch'in a)searchFeed($('#opds-query').value);
 if('libOpdsImport'in a){if(!catalog.chosen.size)toast('请先选择书籍');else runUploads('books',[...catalog.chosen.values()],true);}
});
document.addEventListener('keydown',e=>{if(e.target.id==='opds-query'&&e.key==='Enter'){const value=e.target.value;e.target.blur();searchFeed(value);}});
document.addEventListener('change',e=>{
 if(e.target.id==='opds-source'){catalog.generation++;Object.assign(catalog,{source:Number(e.target.value),url:'',search:'',next:'',stack:[],chosen:new Map(),nav:[],books:[],query:'',loading:false,error:''});paintLibraries();}
 if(e.target.dataset.opdsBook!==undefined){const b=catalog.books[Number(e.target.dataset.opdsBook)];if(e.target.checked)catalog.chosen.set(b.href,b);else catalog.chosen.delete(b.href);paintLibraries();}
});
document.addEventListener('click',event=>{
 const a=event.target.closest('button')?.dataset;
 if(!a||!$('#sheet').open)return;
 const title=$('#sheet-title').textContent;
 const path=title==='OPDS 书库来源'?'opds.sources':'';
 if(path&&(a.addCollection||a.removeCollection||a.clearCollection))$('#sheet-body').innerHTML=collectionView(path);
});
window.nanoLibraries={view:libraryView,enter,pending,changed:paintLibraries,message:libraryMessage,refreshMusic:()=>refreshPage('music'),busy:()=>!!jobs.size||uploadBusy};
gateWorker();send('init',{key:state.key,scanMusic:false});setInterval(gateWorker,800);setInterval(updateJobs,15000);


function libraryDeleteButton(path,title){
 if(!path)return '';
 return '<button type="button" class="icon-button library-delete" data-delete-media="'+esc(path)+'" data-media-name="'+esc(title||path)+'" aria-label="从 TF 卡删除《'+esc(title||path)+'》" title="从 TF 卡删除文件">'+icon('trash')+'</button>';
}
document.addEventListener('click',event=>{
 const button=event.target.closest('[data-delete-media]');if(!button||!panes[state.route])return;
 const kind=state.route,path=button.dataset.deleteMedia,title=button.dataset.mediaName;
 showSheet('从 TF 卡删除文件','<p>确定删除《'+esc(title)+'》？删除后无法恢复。</p><p class="delete-path">TF 卡 /'+esc(path.replace(/\.nbook\/pages\.nbp$/,'.nbook/'))+'</p>',
  '<button class="button secondary" id="cancel-media-delete" autofocus>取消</button><button class="button danger" id="confirm-media-delete">删除文件</button>',libraryNames[kind]);
 const dialog=$('#sheet'),confirm=$('#confirm-media-delete'),cancel=$('#cancel-media-delete');
 cancel.onclick=()=>dialog.close();
 confirm.onclick=async()=>{
  confirm.disabled=true;cancel.disabled=true;
  try{
   if(kind==='books'&&path.endsWith('.nbook/pages.nbp'))await deleteImageBook(path);
   else await fileOp('delete',path);
   dialog.close();toast('文件已从 TF 卡删除');
   if(kind==='music')send('music-file-deleted',{path});else send('media-refresh',{kind});
   if(state.route===kind){button.closest('tr,li')?.remove();}
  }catch(error){confirm.disabled=false;cancel.disabled=false;toast('删除失败：'+error.message,true);}
 };
});

document.addEventListener('submit',e=>{
 if(!e.target.matches('.media-filters'))return;
 e.preventDefault();const v=views[state.route];v.query=e.target.querySelector('[data-media-query]').value.trim();v.offset=0;refreshPage(state.route);
});
document.addEventListener('change',e=>{
 const field=e.target.dataset.metaFilter;if(!field)return;
 const v=views[state.route];v[field]=e.target.value;v.query=e.target.form.querySelector('[data-media-query]').value.trim();
 v.offset=0;refreshPage(state.route);
});

}
