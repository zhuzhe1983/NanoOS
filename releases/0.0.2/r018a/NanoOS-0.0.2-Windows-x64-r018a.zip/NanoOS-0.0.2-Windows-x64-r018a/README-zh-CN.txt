NanoOS 0.0.2 / r018a Windows x64 便携安装器

本版修复了刷新管理页面后重复下载 WASM 转换组件的问题。
本版固件包含音乐、书籍和视频资料库。设备管理后台可导入与整理媒体。
升级后请将随包 TF 资源合并到卡根目录，以便浏览器加载相应的转换组件。
r018a 已在 S31 实机写入并读回校验。Windows 启动器已做离线流程测试。

适用范围
Windows 10/11 x64，Windows PowerShell 5.1 或 PowerShell 7。
仅支持原 16 MiB ESP32-S31 Fake Nano 设备；ESP32-S3 不能替代。
包含官方 Python 3.13.17 嵌入式运行时、esptool 5.6.0 和固定版本依赖。
不需要安装 Python，不联网下载，不改系统 PATH，不安装驱动，也不改注册表。
如果设备在设备管理器中没有 COM 端口，请按设备厂商的说明处理 USB 驱动。

选择安装方式
完整安装（默认、推荐）：不知道区别时选完整安装。
  安装引导程序、原分区表、OTA 初始选择和 App。完整备份并校验整片 16 MiB Flash。
  支持从自制固件迁移：布局不同时，完整备份验证后显示原分区和影响；
  输入“确认覆盖”才会更换布局并重置目标内部设置区。直接回车取消，不写入设备。
  写入后读取整片 Flash，逐字节检查预期变化，并检查其他区域保持不变。
仅安装 App：适用于引导程序正常、布局兼容且已经选择 app0 的设备。
  仅写 app0 / 0x10000，完整备份并校验 app0 的 4 MiB；不改 OTA 选择。
  检查分区结构兼容性，不要求名称或摘要与原厂相同。空白设备、不同布局或
  不能正常启动的设备，请使用完整安装。仅更新应用不改变当前 OTA 启动选择。

两种安装模式都不主动执行全片擦除，不改 TF 卡。
完整安装选择 app0 启动；原厂布局保留内部设置。迁移自制固件并确认覆盖后，
额外重置目标 NVS 区域 0x9000—0xDFFF；原固件或旧分区内容可能不再可访问。
其他地址保留原字节，但这不表示换分区表后仍能使用旧文件系统。
完整安装不代替 TF 资源复制。
TF 字库、表盘、墙纸及 WebUI 转换资源需另行复制：解压本包中的 TF-resources.zip，按其中说明将 nanoos
目录合并复制到 TF 卡；保留自己的文件。本工具不会代为写入 TF，也不会格式化卡。

操作方法
1. 将 ZIP 完整解压到本地文件夹，例如 C:\NanoOS。不要直接在压缩包中运行。
   路径可含空格和中文；为兼容 Windows 默认路径限制，建议使用较短目录。
2. 用能传输数据的 USB 线连接设备，关闭串口监视器及其他刷写程序。
3. 双击 Flash-NanoOS.cmd，在中文菜单中选择安装方式：
   输入 1 或直接回车：完整安装（默认、推荐；不知道区别时选此项）。
   输入 2：仅更新 App。其他输入会取消，尚未连接设备。
   它仅给本次 PowerShell 进程使用 ExecutionPolicy Bypass，不修改当前用户或系统的
   执行策略。组织策略若禁止脚本，请遵循管理员要求。
4. 多个 COM 端口时按提示选择；只有一个端口时自动选择，随后显示实际设备身份。
   核对安装方式后输入“确认刷机”才会开始连接和备份；直接回车可取消。
   自制固件布局不同的，备份验证后还须输入“确认覆盖”，否则不写入。
5. 等待出现“安装完成”。程序只在核验结束后重启一次；让设备完成首次启动和 TF 初始化。

PowerShell 示例（位于解压目录）
  .\Flash-NanoOS.ps1 -CheckOnly
  .\Flash-NanoOS.ps1 -ListPorts
  .\Flash-NanoOS.ps1 -Mode Full -Port COM7
  .\Flash-NanoOS.ps1 -Mode App -Port COM7
  .\Flash-NanoOS.ps1 -Mode Full -Port COM7 -BackupRoot 'D:\设备备份'
也可用 pwsh -NoProfile -File .\Flash-NanoOS.ps1 -Mode Full（PowerShell 7）。
CheckOnly 只核验文件与依赖；ListPorts 仅枚举串口，二者均不打开串口、不写设备。
显式传入 -Mode Full / App 时跳过选择菜单；CheckOnly、ListPorts 和 RestoreFrom
也不显示菜单。恢复方式由备份记录决定。选定安装方式后，仍需输入“确认刷机”才会连接
并安装；恢复时须输入“确认恢复”。

写入清单固定如下，运行参数不能指定任意镜像或地址：
  0x2000   bootloader      22304 字节  （仅完整模式）
  0x8000   partition table  3072 字节  （仅完整模式，扇区余部填充 FF）
  0xe000   OTA initial      8192 字节  （仅完整模式）
  0x10000  app0          4190832 字节  （两种模式，最大 4 MiB）
固定 SHA-256 见 full-manifest.json 和 payload-manifest.json。
程序在写入前核验镜像精确长度、SHA-256、内部结构、芯片型号、Flash 容量及分区表，
备份落盘后重读文件，并调用 esptool 与设备比对；全部通过后才允许写入。
刷后再次使用 esptool 校验。完整模式读回整片 16 MiB Flash，核验方案中的写入区域及其余地址未变。
仅 App 模式读回 4 MiB app0，并单独核验 4 KiB 分区表；其读回验证不覆盖其他分区。
App 模式只向 app0 发出写入命令，验证结果不能用于证明 app0 之外的数据逐字节未变。
未完成所选模式的全部步骤不报告成功。
失败时不主动重启应用，串口会关闭；关闭窗口或异常断线时，设备实际状态需重新确认。

备份与日志默认永久保留在：
  %LOCALAPPDATA%\NanoOS\FlashBackups\日期时间-随机编号\
每次使用新目录，永不覆盖旧备份；不自动删除任何备份和日志。
完整模式：flash-before.bin / flash-readback.bin（各 16 MiB）。
仅 App 模式：app0-before.bin / app0-readback.bin（各 4 MiB）。
其他文件：backup.json（身份与校验）、table-before.bin / table-after.bin、
device.json、partition-report.json、result.json、console.log、technical.log。建议备份目标盘至少预留 100 MiB 空间。
备份可能包含个人数据和设备身份，请妥善保存；不要随软件包公开上传。

恢复
需要恢复时保留完整备份目录，将同一设备重新置于厂商规定的下载模式，再运行：
  .\Flash-NanoOS.ps1 -Port COM7 -RestoreFrom 'D:\设备备份\20261117-000000-12345678'
程序核对备份 SHA-256、长度、备份分区记录及设备 MAC，输入“确认恢复”后恢复。
App 备份只恢复 app0，要求当前分区表与备份一致。
完整备份恢复整片 16 MiB Flash，可以还原之前的自制固件分区和内部数据；
备份之后的内部内容会被替换，TF 卡不会被修改。仅可恢复到备份所属的同一台设备。
恢复前另存当前数据并校验，恢复后读回验证；空白机备份恢复后仍为空白状态。
完整恢复允许当前表损坏或未知，但备份文件和实际设备身份必须通过核对。

取消与失败
连接前按回车即可取消。连接后 Ctrl+C 会尝试停止工作进程并关闭串口。
擦写期间不要取消、拔线或断电；若中断，应用或引导程序可能不完整，需要进入下载模式
根据当前分区表状态尝试完整安装或恢复；分区表损坏时按上方恢复说明处理。
关闭窗口或系统崩溃后，以 result.json 为准；started / failed /
cancelled / verified-awaiting-reset 都不等于完整成功。不要因进度曾到 100% 就拔线。
console.log 保存中文操作提示；底层工具输出保存在 technical.log，异常详情
保存在 error-detail.log。若无成功结果，保留整个会话目录以便诊断。

完整性与许可
发布 ZIP 的外部 SHA-256 用于检查下载；PS 启动器还校验固定文件清单与全部负载。
这些校验不等于数字签名，不能替代可信下载来源。
DEPENDENCIES.json 记录官方来源与原始依赖包 SHA-256；LICENSES 中保留组件许可。
Python 运行时许可另见 runtime\LICENSE.txt，各 wheel 的原始 dist-info 许可也完整保留。
third-party-source 包含 esptool 完整原始源码归档；这不是 NanoOS 系统源码。
固件通知见 FIRMWARE-NOTICES.txt。AirPlay 使用 GPL-3.0-or-later；固件完整对应源码的
提供方式尚未解决。本包没有 NanoOS 完整对应源码，附上许可或测试二进制不能替代
相应分发条件；刷写器及依赖的许可不能视为整份组合固件的闭源分发许可。
