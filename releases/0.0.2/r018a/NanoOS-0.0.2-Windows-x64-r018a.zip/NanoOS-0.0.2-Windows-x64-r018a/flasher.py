"""NanoOS 离线安装器：备份、安装和恢复。"""
from __future__ import annotations
import argparse
import contextlib
import codecs
import functools
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import struct
import subprocess
import sys
import threading
import time
import traceback
import uuid

ROOT = Path(__file__).resolve().parent
POLICY = json.loads((ROOT / "release-policy.json").read_text(encoding="utf-8"))
BUILD = POLICY["candidate"]
IMAGE_BYTES = POLICY["image_bytes"]
IMAGE_SHA = POLICY["image_sha256"]
TABLE_SHA = "0d07801a8c51ddc2b85b1aa302c64b770d7ec471c9dabd33a80d644b5ac7b96c"
APP_OFFSET, APP_BYTES = 0x10000, 0x400000
TABLE_OFFSET, TABLE_BYTES = 0x8000, 0x1000
FLASH_BYTES = 0x1000000
FULL_PARTS = tuple((p["path"], p["offset"], p["bytes"], p["sha256"]) for p in POLICY["full_parts"])

def check(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save_json(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    temp.replace(path)

def save_bytes(path, data):
    with path.open("xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    check(path.read_bytes() == data, "备份写入磁盘后校验失败：" + str(path))

def check_image(data):
    check(len(data) == IMAGE_BYTES and 0 < len(data) <= APP_BYTES, "固件大小不符")
    check(digest(data) == IMAGE_SHA, "固件摘要不符")
    check(data[0] == 0xE9 and 1 <= data[1] <= 16, "固件镜像格式无效")
    check(struct.unpack_from("<H", data, 12)[0] == 32 and data[23] == 1, "镜像不是 ESP32-S31 固件或缺少附加摘要")
    offset, checksum = 24, 0xEF
    for _ in range(data[1]):
        check(offset + 8 <= len(data), "固件分段不完整")
        size = struct.unpack_from("<I", data, offset + 4)[0]
        offset += 8
        check(offset + size <= len(data), "固件分段越界")
        for value in data[offset:offset + size]:
            checksum ^= value
        offset += size
    end = ((offset + 16) // 16) * 16
    check(end + 32 == len(data) and data[end - 1] == checksum, "固件校验和或尾部不符")
    check(hashlib.sha256(data[:end]).digest() == data[end:], "固件内嵌摘要不符")

def parse_table(data):
    check(len(data) == TABLE_BYTES, "分区表读取长度不完整")
    entries = []
    for offset in range(0, 0xC00, 32):
        magic = struct.unpack_from("<H", data, offset)[0]
        if magic == 0xEBEB:
            check(data[offset + 2:offset + 16] == b"\xff" * 14, "分区表校验标记无效")
            check(hashlib.md5(data[:offset]).digest() == data[offset + 16:offset + 32], "分区表校验值不一致")
            break
        if magic == 0xFFFF:
            break  # Older IDF tables may omit their optional MD5 record.
        check(magic == 0x50AA, "无法识别现有分区表")
        _, kind, sub, start, size, label, flags = struct.unpack_from("<HBBII16sI", data, offset)
        check(size > 0 and start >= 0x9000 and start % 4096 == 0 and size % 4096 == 0 and start + size <= FLASH_BYTES, "分区边界无效")
        entries.append((start, size, label.rstrip(b"\0"), kind, sub, flags))
    else:
        raise RuntimeError("分区表条目过多")
    check(entries, "分区表为空")
    ordered = sorted(entries)
    check(all(a[0] + a[1] <= b[0] for a, b in zip(ordered, ordered[1:])), "分区之间存在重叠")
    return entries

def check_table(data):
    check(digest(data) == TABLE_SHA, "安装包中的目标分区表校验失败，请重新解压安装包")
    parse_table(data)

def check_before_table(data, mode):
    check(len(data) == TABLE_BYTES, "分区表读取不完整，尚未写入")
    if mode == "full":
        return  # A foreign layout is handled AFTER a verified full backup.
    entries = parse_table(data)
    apps = [e for e in entries if e[3] == 0 and e[4] == 0x10]
    check(len(apps) == 1 and apps[0][0] == APP_OFFSET and apps[0][1] >= APP_BYTES and apps[0][5] == 0,
          "现有应用分区不适合仅更新应用。请重新运行并选择「完整安装」，完成备份后可确认更换布局。")

def table_report(data):
    result = {"sha256": digest(data), "matches_nanoos": digest(data) == TABLE_SHA}
    try:
        result["partitions"] = [{"offset": a, "bytes": b, "name": c.decode("utf-8", "replace"), "type": d, "subtype": e, "flags": f}
                                for a, b, c, d, e, f in parse_table(data)]
    except RuntimeError as exc:
        result["parse_error"] = str(exc)
    return result

def confirm_repartition(report, session, ask=input):
    print("现有分区布局与 NanoOS 不同，整片 16 MB 备份已完成并通过校验。", flush=True)
    if report.get("parse_error"): print("现有分区表无法正常解析：" + report["parse_error"], flush=True)
    for item in report.get("partitions", []):
        print(f"  {item['name']}：起始 0x{item['offset']:08X}，大小 {item['bytes']} 字节", flush=True)
    print("继续将替换引导程序和分区表，安装 NanoOS，并重置内部设置。原固件可能无法直接启动，旧分区中的内容也可能不再可访问。TF 卡不会被修改。", flush=True)
    print("可用本次完整备份恢复原来的整片 Flash。备份位置：" + str(session), flush=True)
    return ask("如确认更换布局，请输入「确认覆盖」；直接回车取消：").strip() == "确认覆盖"


def assert_released(mode="app"):
    release = json.loads((ROOT / "release-status.json").read_text(encoding="utf-8"))
    check(release.get("candidate") == BUILD and release.get("image_sha256") == IMAGE_SHA, "发布记录与固件不一致")
    check(release.get("hardware_verified") is True, "此固件尚未完成发布验证：" + BUILD + "，尚未连接设备。")
    if mode == "full":
        full = json.loads((ROOT / "full-manifest.json").read_text(encoding="utf-8"))
        check(full.get("hardware_verified") is True, "完整安装固件尚未完成发布验证，尚未连接设备。")

def load_plan(mode):
    image = (ROOT / "firmware" / "nanoos-0.0.2-app0.bin").read_bytes()
    check_image(image)
    if mode == "app":
        return {"mode": mode, "parts": [(APP_OFFSET, image)], "backup_offset": APP_OFFSET,
                "backup_bytes": APP_BYTES, "backup_file": "app0-before.bin", "table_after_sha": TABLE_SHA}
    full = json.loads((ROOT / "full-manifest.json").read_text(encoding="utf-8"))
    check(full.get("schema") == 1 and full.get("mode") == "full" and full.get("build") == BUILD and full.get("version") == "0.0.2", "完整安装清单格式不符")
    check(full.get("chip") == "esp32s31" and full.get("flash_bytes") == FLASH_BYTES and full.get("erase_all") is False, "安装目标或擦写规则无效")
    check(full.get("partition_table_sha256") == TABLE_SHA and full.get("partition_table_offset") == TABLE_OFFSET and full.get("partition_table_bytes") == TABLE_BYTES, "安装包的分区配置不符")
    entries = [(e.get("path"), e.get("offset"), e.get("bytes"), e.get("sha256")) for e in full.get("parts", [])]
    check(entries == list(FULL_PARTS), "完整安装数据与发布清单不一致")
    check([(name, offset) for name, offset, _, _ in FULL_PARTS] == [("full/bootloader.bin", 0x2000), ("full/partition-table.bin", 0x8000), ("full/ota-data.bin", 0xE000), ("full/nanoOS26_prism.bin", APP_OFFSET)], "安装包中的四段固件地址不符")
    check(all(0 < length <= maximum for (_, _, length, _), maximum in zip(FULL_PARTS, (0x6000, TABLE_BYTES, 0x2000, APP_BYTES))), "安装数据超过允许范围")
    parts = []
    for name, offset, length, expected in FULL_PARTS:
        data = (ROOT / name).read_bytes()
        check(len(data) == length and digest(data) == expected, "安装文件校验失败：" + name)
        parts.append((offset, data))
    check_table(parts[1][1] + b"\xff" * (TABLE_BYTES - len(parts[1][1])))
    check(parts[-1][1] == image, "两种安装方式的应用镜像不一致")
    return {"mode": "full", "parts": parts, "backup_offset": 0, "backup_bytes": FLASH_BYTES,
            "backup_file": "flash-before.bin", "table_after_sha": TABLE_SHA}

def dependency_check():
    import importlib.metadata
    import esptool
    from esptool.targets import CHIP_DEFS
    import cryptography.hazmat.bindings._rust
    import _cffi_backend
    import yaml
    import serial.tools.list_ports
    check(esptool.__version__ == "5.6.0", "刷机工具版本必须为 5.6.0")
    check(CHIP_DEFS["esp32s31"].IMAGE_CHIP_ID == 32, "刷机工具不支持 ESP32-S31")
    for name, version in json.loads((ROOT / "dependency-versions.json").read_text()).items():
        check(importlib.metadata.version(name) == version, "依赖版本不一致：" + name)

def ports_now():
    from serial.tools import list_ports
    return [{"port": p.device.upper(), "description": p.description, "hwid": p.hwid,
             "serial_number": p.serial_number, "vid": p.vid, "pid": p.pid}
            for p in sorted(list_ports.comports()) if re.fullmatch(r"COM[1-9][0-9]*", p.device, re.I)]

def choose_port(ports, requested=None, ask=input):
    check(ports, "未找到串口。请用数据线连接设备，并关闭其他串口工具。")
    if requested:
        chosen = requested.upper()
        check(re.fullmatch(r"COM[1-9][0-9]*", chosen), "端口须为本机串口编号，如 COM3")
        check(chosen in [p["port"] for p in ports], "指定串口当前不可用")
        return chosen
    if len(ports) == 1:
        return ports[0]["port"]
    for index, p in enumerate(ports, 1):
        print(f"{index}. {p['port']}  {p['description']}  {p['hwid']}")
    answer = ask("请选择串口序号，直接回车取消：").strip()
    check(answer.isdigit() and 1 <= int(answer) <= len(ports), "已取消选择，或串口序号无效")
    return ports[int(answer) - 1]["port"]

def restore_payload(session):
    session = Path(session).resolve(strict=True)
    manifest = json.loads((session / "backup.json").read_text(encoding="utf-8"))
    mode = manifest.get("mode", "app")
    check(mode in ("app", "full"), "备份类型无效")
    start, size, filename = (APP_OFFSET, APP_BYTES, "app0-before.bin") if mode == "app" else (0, FLASH_BYTES, "flash-before.bin")
    data = (session / filename).read_bytes()
    check(manifest.get("schema") == 1 and manifest.get("chip") == "esp32s31", "备份格式无效")
    check(manifest.get("offset") == start and manifest.get("bytes") == size and len(data) == size, "备份大小或地址范围不正确")
    check(digest(data) == manifest.get("sha256") and manifest.get("device_verified") is True, "备份未通过校验或已经被修改")
    table = (session / "table-before.bin").read_bytes()
    check(len(table) == TABLE_BYTES, "备份分区表长度错误")
    if mode == "app": check_before_table(table, mode)
    check(digest(table) == manifest.get("table_sha256"), "备份中的分区表摘要不符")
    if mode == "full":
        check(data[TABLE_OFFSET:TABLE_OFFSET + TABLE_BYTES] == table, "完整备份与保存的分区表不一致")
    check(re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", manifest.get("mac", "")), "备份缺少有效设备身份")
    # Full recovery restores the verified complete snapshot to the same MAC.
    parts = [(APP_OFFSET, data)] if mode == "app" else [(0, data)]
    return {"mode": mode, "parts": parts, "backup_offset": start, "backup_bytes": size,
            "backup_file": filename, "table_after_sha": digest(table), "restore": True}, manifest["mac"]

def technical_log(method):
    @functools.wraps(method)
    def wrapped(self, *args, **kwargs):
        if not self.session: return method(self, *args, **kwargs)
        with (self.session / "technical.log").open("a", encoding="utf-8") as log:
            with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
                return method(self, *args, **kwargs)
    return wrapped

class EspBackend:
    """One explicit S31 connection. The serial handle is always closed, never reopened."""
    def __init__(self, session=None):
        self.esp = None
        self.session = session

    @technical_log
    def connect(self, port):
        from esptool.targets import CHIP_DEFS
        # Keep the handle even when connect raises, so finally can close it.
        self.esp = CHIP_DEFS["esp32s31"](port, 115200)
        self.esp.connect(mode="default-reset", attempts=7)
        check(self.esp.get_chip_id() == 32, "连接的设备不是 ESP32-S31")
        check(not self.esp.secure_download_mode and not self.esp.get_secure_boot_enabled() and not self.esp.get_flash_encryption_enabled(), "暂不支持启用安全启动或加密的设备，尚未写入")
        mac = ":".join(f"{b:02x}" for b in self.esp.read_mac())
        check(re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", mac), "设备未返回有效硬件地址")
        self.esp = self.esp.run_stub()
        self.esp.change_baud(460800)
        from esptool.cmds import attach_flash, flash_id
        attach_flash(self.esp)
        flash_id(self.esp)
        flash_id_value = self.esp.flash_id()
        check((flash_id_value >> 16) & 255 == 24, "此安装包支持 16 MB 闪存设备")
        return {"chip": "esp32s31", "chip_id": 32, "mac": mac, "flash_id": flash_id_value, "port": port}

    @technical_log
    def read(self, offset, size):
        from esptool.cmds import read_flash
        data = read_flash(self.esp, offset, size, no_progress=True)
        check(isinstance(data, bytes) and len(data) == size, "闪存读取长度不完整")
        return data

    @technical_log
    def verify(self, offset, data):
        from esptool.cmds import verify_flash
        verify_flash(self.esp, [(offset, data)])

    @technical_log
    def write(self, parts):
        from esptool.cmds import write_flash
        allowed = {0: FLASH_BYTES, 0x2000: 0x6000, TABLE_OFFSET: TABLE_BYTES, 0x9000: 0x5000, 0xE000: 0x2000, APP_OFFSET: APP_BYTES}
        check([offset for offset, _ in parts] in ([APP_OFFSET], [0], [0x2000, TABLE_OFFSET, 0xE000, APP_OFFSET], [0x2000, TABLE_OFFSET, 0x9000, 0xE000, APP_OFFSET]), "写入分段不符合安装或恢复方案")
        check(all(len(data) == FLASH_BYTES if offset == 0 else 0 < len(data) <= allowed[offset] for offset, data in parts), "写入范围超出当前方案")
        write_flash(self.esp, parts, erase_all=False, force=False,
                    encrypt=False, flash_size="keep", flash_mode="keep", flash_freq="keep", no_progress=True)

    @technical_log
    def reset(self):
        self.esp.hard_reset()

    @technical_log
    def close(self):
        if self.esp is not None:
            self.esp._port.close()

def install(backend, port, plan, session, expected_mac=None, confirm=None):
    """Fault-injectable orchestration; no success until every guard and close succeeds."""
    result = {"schema": 1, "status": "started", "mode": plan["mode"],
              "parts": [{"offset": offset, "bytes": len(data), "sha256": digest(data)} for offset, data in plan["parts"]],
              "write_started": False, "verified": False}
    save_json(session / "result.json", result)
    try:
        print("正在连接设备并读取芯片信息…", flush=True)
        identity = backend.connect(port)
        result["device"] = identity
        save_json(session / "device.json", identity)
        if expected_mac:
            check(identity["mac"] == expected_mac, "备份属于另一台设备，无法恢复到当前设备")
        print("已连接设备：" + identity["mac"], flush=True)
        table = backend.read(TABLE_OFFSET, TABLE_BYTES)
        save_bytes(session / "table-before.bin", table)
        report = table_report(table)
        save_json(session / "partition-report.json", report)
        if not plan.get("restore"): check_before_table(table, plan["mode"])
        if plan["mode"] == "app":
            if plan.get("restore"): check(digest(table) == plan["table_after_sha"], "当前分区表与应用备份不一致，请使用完整备份恢复。")
            plan = dict(plan, table_after_sha=digest(table))
        print(f"正在备份 {plan['backup_bytes'] // (1024 * 1024)} MB 闪存并验证，请稍候…", flush=True)
        before = backend.read(plan["backup_offset"], plan["backup_bytes"])
        check(len(before) == plan["backup_bytes"], "备份读取不完整")
        save_bytes(session / plan["backup_file"], before)
        backend.verify(plan["backup_offset"], (session / plan["backup_file"]).read_bytes())
        backup = {"schema": 1, "chip": "esp32s31", "mode": plan["mode"], "mac": identity["mac"], "offset": plan["backup_offset"],
                  "bytes": plan["backup_bytes"], "sha256": digest(before), "table_sha256": digest(table), "device_verified": True}
        save_json(session / "backup.json", backup)
        foreign = plan["mode"] == "full" and digest(table) != TABLE_SHA and table != b"\xff" * TABLE_BYTES
        if foreign and not plan.get("restore"):
            accepted = bool(confirm and confirm(report, session))
            result["layout_change_confirmed"] = accepted
            save_json(session / "result.json", result)
            if not accepted:
                result["status"] = "cancelled"
                print("已取消覆盖。备份已保存，设备尚未写入。", flush=True)
                return
            # A different layout may place arbitrary data at the target NVS
            # address. Reset only this explicitly disclosed settings region.
            parts = sorted(plan["parts"] + [(0x9000, b"\xff" * 0x5000)])
            plan = dict(plan, parts=parts)
            result["parts"] = [{"offset": offset, "bytes": len(data), "sha256": digest(data)} for offset, data in parts]
        # Re-read saved data and table immediately before the only mutation.
        check(digest((session / plan["backup_file"]).read_bytes()) == backup["sha256"], "磁盘中的备份已发生变化")
        check(backend.read(TABLE_OFFSET, TABLE_BYTES) == table, "写入前分区表发生变化，请重新检查设备")
        result["write_started"] = True
        save_json(session / "result.json", result)
        print("备份验证通过，正在写入固件…", flush=True)
        backend.write(plan["parts"])
        print("写入完成，正在逐段校验并读回核对…", flush=True)
        for offset, data in plan["parts"]:
            backend.verify(offset, data)
        expected = bytearray(before)
        for offset, data in plan["parts"]:
            # NOR erases complete sectors. Only these fixed regions may change.
            padded = data + b"\xff" * ((-len(data)) % 4096)
            relative = offset - plan["backup_offset"]
            check(0 <= relative and relative + len(padded) <= len(expected), "写入范围超过已备份区域")
            expected[relative:relative + len(padded)] = padded
        after = backend.read(plan["backup_offset"], plan["backup_bytes"])
        check(after == expected, "闪存读回内容与预期不一致，请保留备份并检查日志")
        save_bytes(session / ("flash-readback.bin" if plan["mode"] == "full" else "app0-readback.bin"), after)
        after_table = backend.read(TABLE_OFFSET, TABLE_BYTES)
        save_bytes(session / "table-after.bin", after_table)
        check(digest(after_table) == plan["table_after_sha"], "写入后的分区表与安装方案不一致")
        if plan["mode"] == "app":
            check(after_table == table, "仅更新应用时发现分区表被改变")
        result.update(verified=True, retained_data_verified=True, partition_table_verified=True,
                      partition_table_unchanged=after_table == table, status="verified-awaiting-reset")
        save_json(session / "result.json", result)
        # The only boot happens after readback and table validation.
        backend.reset()
        result["status"] = "success"
    except BaseException as exc:
        result.update(status="cancelled" if isinstance(exc, KeyboardInterrupt) else "failed", error=str(exc) or type(exc).__name__)
        raise
    finally:
        try:
            backend.close()
        except BaseException as exc:
            result.update(status="failed", error="串口关闭失败：" + str(exc))
            raise
        finally:
            save_json(session / "result.json", result)
    print("安装完成，固件、分区表及保留区域均已读回校验。请等待设备启动。", flush=True)

def child_environment():
    env = dict(os.environ)
    for key in list(env):
        if key.startswith("ESPTOOL_") or key.startswith("ESP_PYLIB_"):
            del env[key]
    env.update(ESPTOOL_CFGFILE=str(ROOT / "esptool.cfg"), NO_COLOR="1", PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    return env

def run_worker(command, session, timeout=1800):
    """Stream combined output, retain logs, stop/wait for our child on Ctrl+C."""
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    with (session / "console.log").open("wb") as log:
        process = subprocess.Popen(command, cwd=ROOT, env=child_environment(), stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, creationflags=flags)
        output_errors = []
        def copy_output():
            decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
            try:
                while chunk := process.stdout.read1(4096):
                    log.write(chunk)
                    log.flush()
                    print(decoder.decode(chunk), end="", flush=True)
                print(decoder.decode(b"", final=True), end="", flush=True)
            except BaseException as exc:
                output_errors.append(exc)
                try:
                    process.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGINT)
                except OSError:
                    pass
            finally:
                process.stdout.close()
        reader = threading.Thread(target=copy_output, daemon=True)
        reader.start()
        try:
            code = process.wait(timeout=timeout)
        except (KeyboardInterrupt, subprocess.TimeoutExpired) as exc:
            try:
                process.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGINT)
                process.wait(timeout=10)
            except (subprocess.TimeoutExpired, OSError, KeyboardInterrupt):
                process.kill()
                process.wait()
            raise RuntimeError("操作已中止或超时，设备可能尚未写入完整。请保留备份和日志。") from exc
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            reader.join(timeout=5)
        check(not output_errors, "输出或日志保存失败，无法确认安装结果：" + str(output_errors))
        check(code == 0, f"刷机未完成（退出码 {code}），请查看上方提示及备份目录中的诊断日志。")
    result = json.loads((session / "result.json").read_text(encoding="utf-8"))
    if result.get("status") == "cancelled" and result.get("write_started") is False: return
    check(result.get("status") == "success" and result.get("verified") is True and result.get("partition_table_verified") is True and result.get("retained_data_verified") is True,
          "未取得完整校验成功记录，请检查日志")

def main():
    class ChineseParser(argparse.ArgumentParser):
        def error(self, message):
            raise RuntimeError("启动参数无效。请双击 Flash-NanoOS.cmd 选择安装方式；恢复时使用 -RestoreFrom 指定备份目录。")
    parser = ChineseParser(description=__doc__, add_help=False, usage="双击 Flash-NanoOS.cmd，按中文菜单操作")
    parser.add_argument("-h", "--help", action="help", help="显示帮助并退出")
    parser._optionals.title="可选参数"
    parser.add_argument("--port")
    parser.add_argument("--mode", choices=("full", "app"), default="full")
    parser.add_argument("--list-ports", action="store_true")
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--backup-root", type=Path)
    parser.add_argument("--restore-from", type=Path)
    parser.add_argument("--worker-session", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    check(sys.platform == "win32" and struct.calcsize("P") == 8, "请在 64 位 Windows 上使用此安装包")
    # Config is pinned before importing esptool (it caches config at import time).
    os.environ.update(child_environment())
    dependency_check()
    plan = load_plan(args.mode)
    if args.check_only:
        print("离线文件和依赖校验通过，尚未连接串口。")
        print("固件版本：0.0.2；构建：" + BUILD)
        return
    if args.list_ports:
        
        for item in ports_now(): print("串口：" + item["port"] + "；设备：" + item["description"])
        return
    expected_mac = None
    if args.restore_from:
        plan, expected_mac = restore_payload(args.restore_from)
    assert_released(plan["mode"])
    if args.worker_session:
        check(args.port and re.fullmatch(r"COM[1-9][0-9]*", args.port, re.I), "请选择明确的本机串口编号")
        if hasattr(signal, "SIGBREAK"):
            signal.signal(signal.SIGBREAK, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
        install(EspBackend(args.worker_session), args.port, plan, args.worker_session, expected_mac, confirm_repartition)
        return
    port = choose_port(ports_now(), args.port)
    backup_root = args.backup_root or Path(os.environ["LOCALAPPDATA"]) / "NanoOS" / "FlashBackups"
    backup_root = backup_root.expanduser().resolve()
    check(not backup_root.is_relative_to(ROOT), "请将备份保存在安装包解压目录之外")
    action = "确认恢复" if args.restore_from else "确认刷机"
    if args.restore_from:
        print(f"准备恢复 {port}：将恢复经校验的备份，仅限备份所属设备。")
        print("完整备份会恢复整片 Flash，备份之后的内部设置和内容将被替换；TF 卡不变。")
    elif plan["mode"] == "full":
        print(f"准备完整安装到 {port}（默认、推荐）。")
        print("写入前会备份并校验整片 16 MB Flash。布局不同时，会另行说明影响并要求确认。")
        print("布局相同时保留内部设置和未涉及的分区；TF 卡不变。")
    else:
        print(f"准备仅更新应用到 {port}：写入 0x10000 起始的应用区。")
        print("适用于引导程序正常且应用分区兼容的设备；写入前备份 4 MB 应用区，保留分区表和其他区域。")
    print("备份位置：" + str(backup_root))
    print("请关闭其他串口工具。写入和校验期间保持 USB 供电，不要拔线或关机。")
    if input(f"输入「{action}」继续；直接回车取消：").strip() != action:
        print("已取消，尚未连接设备。")
        return
    session = backup_root / (datetime.datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8])
    session.mkdir(parents=True, exist_ok=False)
    save_json(session / "session.json", {"port": port, "action": action, "mode": plan["mode"], "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print("本次备份和日志：" + str(session), flush=True)
    command = [sys.executable, "-I", "-B", "-X", "utf8", "-u", str(ROOT / "flasher.py"), "--port", port, "--mode", plan["mode"], "--worker-session", str(session)]
    if args.restore_from:
        command += ["--restore-from", str(args.restore_from.resolve())]
    try:
        run_worker(command, session)
    finally:
        print("备份和日志已保留：" + str(session), flush=True)

if __name__ == "__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        session_arg = next((sys.argv[i + 1] for i, arg in enumerate(sys.argv[:-1]) if arg == "--worker-session"), None)
        detail = (Path(session_arg) if session_arg else Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "NanoOS") / "error-detail.log"
        try:
            detail.parent.mkdir(parents=True, exist_ok=True)
            with detail.open("a", encoding="utf-8") as log: traceback.print_exc(file=log)
            print("详细诊断日志：" + str(detail), flush=True)
        except OSError:
            print("无法保存诊断日志，请检查磁盘空间和目录权限。", flush=True)
        message = str(exc) if isinstance(exc, RuntimeError) and any("\u4e00" <= c <= "\u9fff" for c in str(exc)) else "操作未完成，请检查串口、连接和安装包；请查看诊断日志。"
        if isinstance(exc, KeyboardInterrupt): message = "操作已中止，请保留备份和日志。"
        print("安装器提示：" + message, flush=True)
        sys.exit(1)
