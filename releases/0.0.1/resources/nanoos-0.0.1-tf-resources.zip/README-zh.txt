﻿nanoOS 0.0.1 配套 TF 资源

把本包的 nanoos 文件夹合并复制到 TF 卡根目录。保留卡上已有的其他文件；不要格式化，也不要用整个文件夹替换来删除现有资料。
目录：nanoos/fonts/cjk20.nfnt（中文阅读字库）、nanoos/faces/atlas-v1.nfa（16款表盘背景）、nanoos/wallpapers/*.nwp（默认墙纸）。
同名系统资源可覆盖；本包不含个人配置、模型密钥、Wi-Fi密码或用户媒体。
网页/PowerShell刷写的是内部Flash，不会自动把这些资源写到TF卡。
字库基于 Source Han Sans SC，许可证见 LICENSES；表盘背景和墙纸为nanoOS项目生成素材。
