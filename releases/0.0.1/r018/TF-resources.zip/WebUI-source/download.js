async function codecBytes(path,size){
 self.postMessage({loading:0,total:size});
 const response=await fetch(path);
 if(!response.ok)throw Error('无法读取 TF 卡转码组件（'+response.status+'）');
 const reader=response.body.getReader(),bytes=new Uint8Array(size);
 let offset=0,last=0;
 for(;;){
  const {done,value}=await reader.read();if(done)break;
  if(offset+value.length>size)throw Error('转码组件大小异常');
  bytes.set(value,offset);offset+=value.length;
  if(Date.now()-last>100||offset===size){self.postMessage({loading:offset,total:size});last=Date.now();}
 }
 if(offset!==size)throw Error('转码组件下载不完整，请重试');
 return bytes;
}
