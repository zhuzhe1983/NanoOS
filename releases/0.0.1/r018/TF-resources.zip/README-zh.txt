NanoOS 0.0.1 r018 · TF 卡资源

将压缩包解压到电脑，再把其中的 nanoos 文件夹合并复制到 TF 卡根目录。
复制后，卡上应有 nanoos/fonts、nanoos/faces、nanoos/wallpapers 和 nanoos/tools。
tools 中的 .gz 文件请原样复制。浏览器通过设备读取这些文件，用于整理资料库和转换音视频、电子书。
升级时合并同名文件夹，保留卡上的个人书籍、音乐、视频和设置。
SHA256SUMS.txt 用于核对文件完整性。LICENSES 和 WebUI-source 供查阅。
