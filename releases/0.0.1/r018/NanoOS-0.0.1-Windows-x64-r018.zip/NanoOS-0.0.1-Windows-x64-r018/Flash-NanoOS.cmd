@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Flash-NanoOS.ps1" %*
set "nanoos_exit=%ERRORLEVEL%"
echo.
echo 安装器已退出，退出码：%nanoos_exit%。
echo 按任意键关闭窗口…
pause >nul
exit /b %nanoos_exit%
