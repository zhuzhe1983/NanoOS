﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Full', 'App')]
    [string]$Mode = 'Full',
    [string]$Port,
    [switch]$ListPorts,
    [switch]$CheckOnly,
    [string]$BackupRoot,
    [string]$RestoreFrom
)
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$OutputEncoding = [Console]::OutputEncoding
try {
    if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem) {
        throw '此安装包需要 64 位 Windows 10 或 11。'
    }
    $root = [IO.Path]::GetFullPath($PSScriptRoot)
    $manifestPath = Join-Path $root 'payload-manifest.json'
    if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a3009b9b65c3fa86ee493c94309bb576573e02f9b0c24e6367d42f956b876b3d') {
        throw '安装清单已被修改，请重新解压完整安装包。'
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Host '正在检查离线安装包完整性…'
    foreach ($entry in $manifest.files) {
        $target = [IO.Path]::GetFullPath((Join-Path $root $entry.path))
        if (-not $target.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            throw '安装清单中含有包外路径。'
        }
        $file = Get-Item -LiteralPath $target
        if ($file.Length -ne $entry.bytes -or
            (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
            throw ('安装文件校验失败：' + $entry.path)
        }
    }
    if (-not $PSBoundParameters.ContainsKey('Mode') -and -not $ListPorts -and -not $CheckOnly -and -not $RestoreFrom) {
        Write-Host ''
        Write-Host '请选择安装方式：'
        Write-Host '  1. 完整安装（默认、推荐；不知道区别时选此项）'
        Write-Host '  2. 仅更新应用'
        $selection = (Read-Host '输入 1 或 2；直接回车选择完整安装；其他输入取消').Trim()
        switch ($selection) {
            ''  { $Mode = 'Full' }
            '1' { $Mode = 'Full' }
            '2' { $Mode = 'App' }
            default {
                Write-Host '已取消，尚未连接设备。'
                exit 0
            }
        }
    }
    $python = Join-Path $root 'runtime\python.exe'
    $arguments = @('-I', '-B', '-X', 'utf8', '-u', (Join-Path $root 'flasher.py'))
    $arguments += @('--mode', $Mode.ToLowerInvariant())
    if ($Port) { $arguments += @('--port', $Port) }
    if ($ListPorts) { $arguments += '--list-ports' }
    if ($CheckOnly) { $arguments += '--check-only' }
    if ($BackupRoot) { $arguments += @('--backup-root', $BackupRoot) }
    if ($RestoreFrom) { $arguments += @('--restore-from', $RestoreFrom) }
    & $python @arguments
    $code = $LASTEXITCODE
    if ($code -ne 0) { Write-Host ('NanoOS 安装未完成（退出码 ' + $code + '），请查看上方提示和保存的日志。') -ForegroundColor Red }
    exit $code
} catch {
    $detail = $_
    $message = '无法启动安装器，请确认安装包已完整解压、文件未被拦截，并检查目录权限。'
    if ($detail.Exception.Message -match '^(此安装包|安装清单|安装文件)') { $message = $detail.Exception.Message }
    Write-Host ('NanoOS 安装器已停止：' + $message) -ForegroundColor Red
    try {
        $logDir = Join-Path $env:LOCALAPPDATA 'NanoOS'
        [IO.Directory]::CreateDirectory($logDir) | Out-Null
        $logPath = Join-Path $logDir 'launcher-error.log'
        $detail | Out-String | Out-File -LiteralPath $logPath -Encoding UTF8 -Append
        Write-Host ('详细诊断日志：' + $logPath)
    } catch { Write-Host '无法保存启动日志，请检查磁盘空间和目录权限。' }
    exit 1
}
