"""NanoOS Windows portable installer. No network, erase-all, or arbitrary offsets."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import struct
import subprocess
import sys
import threading
import time
import traceback
import uuid

ROOT = Path(__file__).resolve().parent
POLICY = json.loads((ROOT / "release-policy.json").read_text(encoding="utf-8"))
BUILD = POLICY["candidate"]
IMAGE_BYTES = POLICY["image_bytes"]
IMAGE_SHA = POLICY["image_sha256"]
TABLE_SHA = "0d07801a8c51ddc2b85b1aa302c64b770d7ec471c9dabd33a80d644b5ac7b96c"
APP_OFFSET, APP_BYTES = 0x10000, 0x400000
TABLE_OFFSET, TABLE_BYTES = 0x8000, 0x1000
FLASH_BYTES = 0x1000000
FULL_PARTS = tuple((p["path"], p["offset"], p["bytes"], p["sha256"]) for p in POLICY["full_parts"])

def check(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save_json(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    temp.replace(path)

def save_bytes(path, data):
    with path.open("xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    check(path.read_bytes() == data, "Backup disk read verification failed: " + str(path))

def check_image(data):
    check(len(data) == IMAGE_BYTES and 0 < len(data) <= APP_BYTES, "Firmware size mismatch")
    check(digest(data) == IMAGE_SHA, "Firmware SHA-256 mismatch")
    check(data[0] == 0xE9 and 1 <= data[1] <= 16, "Invalid ESP application image")
    check(struct.unpack_from("<H", data, 12)[0] == 32 and data[23] == 1, "Image is not ESP32-S31 / appended SHA-256")
    offset, checksum = 24, 0xEF
    for _ in range(data[1]):
        check(offset + 8 <= len(data), "Truncated image segment")
        size = struct.unpack_from("<I", data, offset + 4)[0]
        offset += 8
        check(offset + size <= len(data), "Image segment overflow")
        for value in data[offset:offset + size]:
            checksum ^= value
        offset += size
    end = ((offset + 16) // 16) * 16
    check(end + 32 == len(data) and data[end - 1] == checksum, "Image checksum/trailer mismatch")
    check(hashlib.sha256(data[:end]).digest() == data[end:], "Image embedded SHA-256 mismatch")

def check_table(data):
    check(len(data) == TABLE_BYTES and digest(data) == TABLE_SHA, "Original partition table mismatch; refusing write")
    entries = []
    for offset in range(0, 0xC00, 32):
        magic = struct.unpack_from("<H", data, offset)[0]
        if magic == 0xEBEB:
            check(data[offset + 2:offset + 16] == b"\xff" * 14, "Invalid partition digest marker")
            check(hashlib.md5(data[:offset]).digest() == data[offset + 16:offset + 32], "Partition MD5 mismatch")
            check(all(x == 255 for x in data[offset + 32:]), "Unexpected partition trailer")
            break
        check(magic == 0x50AA, "Invalid partition entry")
        _, kind, sub, start, size, label, flags = struct.unpack_from("<HBBII16sI", data, offset)
        check(size > 0 and start >= 0x9000 and start % 4096 == 0 and size % 4096 == 0 and start + size <= FLASH_BYTES, "Invalid partition boundary")
        entries.append((start, size, label.rstrip(b"\0"), kind, sub, flags))
    else:
        raise RuntimeError("Partition digest missing")
    ordered = sorted(entries)
    check(all(a[0] + a[1] <= b[0] for a, b in zip(ordered, ordered[1:])), "Overlapping partitions")
    check([e for e in entries if e[2] == b"app0"] == [(APP_OFFSET, APP_BYTES, b"app0", 0, 0x10, 0)], "Original 4 MiB app0 layout required")

def check_before_table(data, mode):
    if mode == "full" and data == b"\xff" * TABLE_BYTES:
        return
    check_table(data)

def assert_released(mode="app"):
    release = json.loads((ROOT / "release-status.json").read_text(encoding="utf-8"))
    check(release.get("candidate") == BUILD and release.get("image_sha256") == IMAGE_SHA, "Release image mismatch")
    check(release.get("hardware_verified") is True, "Release gate closed: " + BUILD + " hardware approval is pending. No device opened.")
    if mode == "full":
        full = json.loads((ROOT / "full-manifest.json").read_text(encoding="utf-8"))
        check(full.get("hardware_verified") is True, "Full-install hardware approval is pending. No device opened.")

def load_plan(mode):
    image = (ROOT / "firmware" / "nanoos-0.0.1-app0.bin").read_bytes()
    check_image(image)
    if mode == "app":
        return {"mode": mode, "parts": [(APP_OFFSET, image)], "backup_offset": APP_OFFSET,
                "backup_bytes": APP_BYTES, "backup_file": "app0-before.bin", "table_after_sha": TABLE_SHA}
    full = json.loads((ROOT / "full-manifest.json").read_text(encoding="utf-8"))
    check(full.get("schema") == 1 and full.get("mode") == "full" and full.get("build") == BUILD and full.get("version") == "0.0.1", "Unexpected full-install manifest")
    check(full.get("chip") == "esp32s31" and full.get("flash_bytes") == FLASH_BYTES and full.get("erase_all") is False, "Invalid full-install target or erase policy")
    check(full.get("partition_table_sha256") == TABLE_SHA and full.get("partition_table_offset") == TABLE_OFFSET and full.get("partition_table_bytes") == TABLE_BYTES, "Full-install partition policy mismatch")
    entries = [(e.get("path"), e.get("offset"), e.get("bytes"), e.get("sha256")) for e in full.get("parts", [])]
    check(entries == list(FULL_PARTS), "Full install must match the four approved segments exactly")
    check([(name, offset) for name, offset, _, _ in FULL_PARTS] == [("full/bootloader.bin", 0x2000), ("full/partition-table.bin", 0x8000), ("full/ota-data.bin", 0xE000), ("full/nanoOS26_prism.bin", APP_OFFSET)], "Fixed four-segment layout required")
    check(all(0 < length <= maximum for (_, _, length, _), maximum in zip(FULL_PARTS, (0x6000, TABLE_BYTES, 0x2000, APP_BYTES))), "Full-install segment exceeds fixed bounds")
    parts = []
    for name, offset, length, expected in FULL_PARTS:
        data = (ROOT / name).read_bytes()
        check(len(data) == length and digest(data) == expected, "Full-install payload mismatch: " + name)
        parts.append((offset, data))
    check_table(parts[1][1] + b"\xff" * (TABLE_BYTES - len(parts[1][1])))
    check(parts[-1][1] == image, "Full and App modes must use the same application image")
    return {"mode": "full", "parts": parts, "backup_offset": 0, "backup_bytes": FLASH_BYTES,
            "backup_file": "flash-before.bin", "table_after_sha": TABLE_SHA}

def dependency_check():
    import importlib.metadata
    import esptool
    from esptool.targets import CHIP_DEFS
    import cryptography.hazmat.bindings._rust
    import _cffi_backend
    import yaml
    import serial.tools.list_ports
    check(esptool.__version__ == "5.6.0", "esptool must be exactly 5.6.0")
    check(CHIP_DEFS["esp32s31"].IMAGE_CHIP_ID == 32, "Missing ESP32-S31 support")
    for name, version in json.loads((ROOT / "dependency-versions.json").read_text()).items():
        check(importlib.metadata.version(name) == version, "Dependency version mismatch: " + name)

def ports_now():
    from serial.tools import list_ports
    return [{"port": p.device.upper(), "description": p.description, "hwid": p.hwid,
             "serial_number": p.serial_number, "vid": p.vid, "pid": p.pid}
            for p in sorted(list_ports.comports()) if re.fullmatch(r"COM[1-9][0-9]*", p.device, re.I)]

def choose_port(ports, requested=None, ask=input):
    check(ports, "No COM port found. Connect the device with a data-capable USB cable; close other serial tools.")
    if requested:
        chosen = requested.upper()
        check(re.fullmatch(r"COM[1-9][0-9]*", chosen), "Port must be a local COM number")
        check(chosen in [p["port"] for p in ports], "Requested COM port is not currently available")
        return chosen
    if len(ports) == 1:
        return ports[0]["port"]
    for index, p in enumerate(ports, 1):
        print(f"{index}. {p['port']}  {p['description']}  {p['hwid']}")
    answer = ask("Select COM port number (blank cancels): ").strip()
    check(answer.isdigit() and 1 <= int(answer) <= len(ports), "Port selection cancelled or invalid")
    return ports[int(answer) - 1]["port"]

def restore_payload(session):
    session = Path(session).resolve(strict=True)
    manifest = json.loads((session / "backup.json").read_text(encoding="utf-8"))
    mode = manifest.get("mode", "app")
    check(mode in ("app", "full"), "Invalid backup mode")
    start, size, filename = (APP_OFFSET, APP_BYTES, "app0-before.bin") if mode == "app" else (0, FLASH_BYTES, "flash-before.bin")
    data = (session / filename).read_bytes()
    check(manifest.get("schema") == 1 and manifest.get("chip") == "esp32s31", "Invalid backup format")
    check(manifest.get("offset") == start and manifest.get("bytes") == size and len(data) == size, "Backup has wrong bounds")
    check(digest(data) == manifest.get("sha256") and manifest.get("device_verified") is True, "Backup was not verified or has changed")
    table = (session / "table-before.bin").read_bytes()
    check_before_table(table, mode)
    check(digest(table) == manifest.get("table_sha256"), "Backup table hash changed")
    if mode == "full":
        check(data[TABLE_OFFSET:TABLE_OFFSET + TABLE_BYTES] == table, "Backup full Flash table mismatch")
    check(re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", manifest.get("mac", "")), "Backup device identity missing")
    # Full recovery restores only the original four installation regions from
    # the user's full snapshot. It does not overwrite current NVS/resources.
    parts = [(APP_OFFSET, data)] if mode == "app" else [(offset, data[offset:offset + length]) for offset, length in ((0x2000, 0x6000), (0x8000, 0x1000), (0xE000, 0x2000), (APP_OFFSET, APP_BYTES))]
    return {"mode": mode, "parts": parts, "backup_offset": start, "backup_bytes": size,
            "backup_file": filename, "table_after_sha": digest(table), "restore": True}, manifest["mac"]

class EspBackend:
    """One explicit S31 connection. The serial handle is always closed, never reopened."""
    def __init__(self):
        self.esp = None

    def connect(self, port):
        from esptool.targets import CHIP_DEFS
        # Keep the handle even when connect raises, so finally can close it.
        self.esp = CHIP_DEFS["esp32s31"](port, 115200)
        self.esp.connect(mode="default-reset", attempts=7)
        check(self.esp.get_chip_id() == 32, "Connected device is not ESP32-S31")
        check(not self.esp.secure_download_mode and not self.esp.get_secure_boot_enabled() and not self.esp.get_flash_encryption_enabled(), "Secure/encrypted devices are unsupported; no write performed")
        mac = ":".join(f"{b:02x}" for b in self.esp.read_mac())
        check(re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", mac), "Device did not return a valid base MAC")
        self.esp = self.esp.run_stub()
        self.esp.change_baud(460800)
        from esptool.cmds import attach_flash, flash_id
        attach_flash(self.esp)
        flash_id(self.esp)
        flash_id_value = self.esp.flash_id()
        check((flash_id_value >> 16) & 255 == 24, "Only original 16 MiB NOR flash is supported")
        return {"chip": "esp32s31", "chip_id": 32, "mac": mac, "flash_id": flash_id_value, "port": port}

    def read(self, offset, size):
        from esptool.cmds import read_flash
        data = read_flash(self.esp, offset, size, no_progress=True)
        check(isinstance(data, bytes) and len(data) == size, "Flash read returned wrong length")
        return data

    def verify(self, offset, data):
        from esptool.cmds import verify_flash
        verify_flash(self.esp, [(offset, data)])

    def write(self, parts):
        from esptool.cmds import write_flash
        allowed = {0x2000: 0x6000, TABLE_OFFSET: TABLE_BYTES, 0xE000: 0x2000, APP_OFFSET: APP_BYTES}
        check([offset for offset, _ in parts] in ([APP_OFFSET], [0x2000, TABLE_OFFSET, 0xE000, APP_OFFSET]), "Unapproved write segments")
        check(all(0 < len(data) <= allowed[offset] for offset, data in parts), "Write outside fixed installation ranges refused")
        write_flash(self.esp, parts, erase_all=False, force=False,
                    encrypt=False, flash_size="keep", flash_mode="keep", flash_freq="keep", no_progress=True)

    def reset(self):
        self.esp.hard_reset()

    def close(self):
        if self.esp is not None:
            self.esp._port.close()

def install(backend, port, plan, session, expected_mac=None):
    """Fault-injectable orchestration; no success until every guard and close succeeds."""
    result = {"schema": 1, "status": "started", "mode": plan["mode"],
              "parts": [{"offset": offset, "bytes": len(data), "sha256": digest(data)} for offset, data in plan["parts"]],
              "write_started": False, "verified": False}
    save_json(session / "result.json", result)
    try:
        identity = backend.connect(port)
        result["device"] = identity
        save_json(session / "device.json", identity)
        if expected_mac:
            check(identity["mac"] == expected_mac, "Backup belongs to a different device; refusing restore")
        print("Connected device: " + identity["mac"], flush=True)
        table = backend.read(TABLE_OFFSET, TABLE_BYTES)
        check_before_table(table, plan["mode"])
        save_bytes(session / "table-before.bin", table)
        print(f"Backing up {plan['backup_bytes'] // (1024 * 1024)} MiB Flash...", flush=True)
        before = backend.read(plan["backup_offset"], plan["backup_bytes"])
        check(len(before) == plan["backup_bytes"], "Backup read incomplete")
        save_bytes(session / plan["backup_file"], before)
        backend.verify(plan["backup_offset"], (session / plan["backup_file"]).read_bytes())
        backup = {"schema": 1, "chip": "esp32s31", "mode": plan["mode"], "mac": identity["mac"], "offset": plan["backup_offset"],
                  "bytes": plan["backup_bytes"], "sha256": digest(before), "table_sha256": digest(table), "device_verified": True}
        save_json(session / "backup.json", backup)
        # Re-read saved data and table immediately before the only mutation.
        check(digest((session / plan["backup_file"]).read_bytes()) == backup["sha256"], "Backup changed on disk")
        check(backend.read(TABLE_OFFSET, TABLE_BYTES) == table, "Partition table changed before write")
        result["write_started"] = True
        save_json(session / "result.json", result)
        print("Writing approved " + plan["mode"] + " installation segments...", flush=True)
        backend.write(plan["parts"])
        for offset, data in plan["parts"]:
            backend.verify(offset, data)
        expected = bytearray(before)
        for offset, data in plan["parts"]:
            # NOR erases complete sectors. Only these fixed regions may change.
            padded = data + b"\xff" * ((-len(data)) % 4096)
            relative = offset - plan["backup_offset"]
            check(0 <= relative and relative + len(padded) <= len(expected), "Write exceeds backup bounds")
            expected[relative:relative + len(padded)] = padded
        after = backend.read(plan["backup_offset"], plan["backup_bytes"])
        check(after == expected, "Flash readback mismatch (including retained bytes)")
        save_bytes(session / ("flash-readback.bin" if plan["mode"] == "full" else "app0-readback.bin"), after)
        after_table = backend.read(TABLE_OFFSET, TABLE_BYTES)
        save_bytes(session / "table-after.bin", after_table)
        check(digest(after_table) == plan["table_after_sha"], "Partition table does not match installation plan")
        if plan["mode"] == "app":
            check(after_table == table, "Partition table changed in App mode")
        result.update(verified=True, retained_data_verified=True, partition_table_verified=True,
                      partition_table_unchanged=after_table == table, status="verified-awaiting-reset")
        save_json(session / "result.json", result)
        # The only boot happens after readback and table validation.
        backend.reset()
        result["status"] = "success"
    except BaseException as exc:
        result.update(status="cancelled" if isinstance(exc, KeyboardInterrupt) else "failed", error=str(exc) or type(exc).__name__)
        raise
    finally:
        try:
            backend.close()
        except BaseException as exc:
            result.update(status="failed", error="Serial close failed: " + str(exc))
            raise
        finally:
            save_json(session / "result.json", result)
    print("SUCCESS: installation, partition table and retained data verified. Allow the device to finish booting.", flush=True)

def child_environment():
    env = dict(os.environ)
    for key in list(env):
        if key.startswith("ESPTOOL_") or key.startswith("ESP_PYLIB_"):
            del env[key]
    env.update(ESPTOOL_CFGFILE=str(ROOT / "esptool.cfg"), NO_COLOR="1", PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    return env

def run_worker(command, session, timeout=1800):
    """Stream combined output, retain logs, stop/wait for our child on Ctrl+C."""
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    with (session / "console.log").open("wb") as log:
        process = subprocess.Popen(command, cwd=ROOT, env=child_environment(), stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, creationflags=flags)
        output_errors = []
        def copy_output():
            try:
                while chunk := process.stdout.read1(4096):
                    log.write(chunk)
                    log.flush()
                    print(chunk.decode("utf-8", errors="replace"), end="", flush=True)
            except BaseException as exc:
                output_errors.append(exc)
                try:
                    process.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGINT)
                except OSError:
                    pass
            finally:
                process.stdout.close()
        reader = threading.Thread(target=copy_output, daemon=True)
        reader.start()
        try:
            code = process.wait(timeout=timeout)
        except (KeyboardInterrupt, subprocess.TimeoutExpired) as exc:
            try:
                process.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGINT)
                process.wait(timeout=10)
            except (subprocess.TimeoutExpired, OSError, KeyboardInterrupt):
                process.kill()
                process.wait()
            raise RuntimeError("Cancelled or timed out; device state may be incomplete. Keep the backup and logs.") from exc
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            reader.join(timeout=5)
        check(not output_errors, "Console/log capture failed; installation is not confirmed: " + str(output_errors))
        check(code == 0, f"Flashing worker failed (exit {code}); inspect console.log and result.json")
    result = json.loads((session / "result.json").read_text(encoding="utf-8"))
    check(result.get("status") == "success" and result.get("verified") is True and result.get("partition_table_verified") is True and result.get("retained_data_verified") is True,
          "Worker did not produce verified success")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port")
    parser.add_argument("--mode", choices=("full", "app"), default="full")
    parser.add_argument("--list-ports", action="store_true")
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--backup-root", type=Path)
    parser.add_argument("--restore-from", type=Path)
    parser.add_argument("--worker-session", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    check(sys.platform == "win32" and struct.calcsize("P") == 8, "Use this bundle on 64-bit Windows")
    # Config is pinned before importing esptool (it caches config at import time).
    os.environ.update(child_environment())
    dependency_check()
    plan = load_plan(args.mode)
    if args.check_only:
        print("Offline payload/dependency validation passed. No serial port opened.")
        print((ROOT / "release-status.json").read_text(encoding="utf-8"))
        return
    if args.list_ports:
        print(json.dumps(ports_now(), ensure_ascii=False, indent=2))
        return
    expected_mac = None
    if args.restore_from:
        plan, expected_mac = restore_payload(args.restore_from)
    assert_released(plan["mode"])
    if args.worker_session:
        check(args.port and re.fullmatch(r"COM[1-9][0-9]*", args.port, re.I), "Explicit local COM port required")
        if hasattr(signal, "SIGBREAK"):
            signal.signal(signal.SIGBREAK, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
        install(EspBackend(), args.port, plan, args.worker_session, expected_mac)
        return
    port = choose_port(ports_now(), args.port)
    backup_root = args.backup_root or Path(os.environ["LOCALAPPDATA"]) / "NanoOS" / "FlashBackups"
    backup_root = backup_root.expanduser().resolve()
    check(not backup_root.is_relative_to(ROOT), "Choose a backup folder outside the extracted program folder")
    action = "RESTORE" if args.restore_from else "FLASH"
    if plan["mode"] == "full":
        print(f"{action} {port}: FULL installation (recommended): bootloader, original table, OTA selection, app0.")
        print("If unsure which mode to choose, use Full. NVS, app1, resources/storage and TF are retained.")
        print("The entire 16 MiB Flash will be backed up and verified before any write.")
    else:
        print(f"{action} {port}: APP ONLY: app0 at 0x10000. Bootloader, table, OTA selection, settings/storage and TF are retained.")
        print("This mode is for devices with a working compatible bootloader and app0 selected. Full app0 (4 MiB) will be backed up.")
    print("Backup destination: " + str(backup_root))
    print("Close serial monitors. Keep USB power connected until verification finishes. Do not power-cycle during the write.")
    if input(f"Type {action} to continue, or press Enter to cancel: ").strip() != action:
        print("Cancelled before opening the device.")
        return
    session = backup_root / (datetime.datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8])
    session.mkdir(parents=True, exist_ok=False)
    save_json(session / "session.json", {"port": port, "action": action, "mode": plan["mode"], "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print("Backup/log session: " + str(session), flush=True)
    command = [sys.executable, "-I", "-B", "-X", "utf8", "-u", str(ROOT / "flasher.py"), "--port", port, "--mode", plan["mode"], "--worker-session", str(session)]
    if args.restore_from:
        command += ["--restore-from", str(args.restore_from.resolve())]
    try:
        run_worker(command, session)
    finally:
        print("Backup and logs retained: " + str(session), flush=True)

if __name__ == "__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt):
        traceback.print_exc()
        sys.exit(1)
