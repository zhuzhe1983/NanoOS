@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Flash-NanoOS.ps1" %*
set "nanoos_exit=%ERRORLEVEL%"
echo.
echo Installer exited with code %nanoos_exit%.
pause
exit /b %nanoos_exit%
