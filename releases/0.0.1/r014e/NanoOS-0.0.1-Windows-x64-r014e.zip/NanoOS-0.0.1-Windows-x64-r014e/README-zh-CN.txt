﻿NanoOS 0.0.1 / r014e Windows x64 便携安装器

【候选状态】以 release-status.json 和 full-manifest.json 为准。实机审批关闭时，
程序会在打开串口之前停止。本包未在真实 Windows 电脑上运行验证；已做离线结构
校验与模拟失败测试。审批通过也不代表已经完成 Windows 实机验证。

适用范围
Windows 10/11 x64，Windows PowerShell 5.1 或 PowerShell 7。
仅支持原 16 MiB ESP32-S31 Fake Nano 设备；ESP32-S3 不能替代。
包含官方 Python 3.13.17 嵌入式运行时、esptool 5.6.0 和固定版本依赖。
不需要安装 Python，不联网下载，不改系统 PATH，不安装驱动，也不改注册表。
如果设备在设备管理器中没有 COM 端口，请按设备厂商的说明处理 USB 驱动。

选择安装方式
完整安装（默认、推荐）：不知道区别时选完整安装。
  安装引导程序、原分区表、OTA 初始选择和 App。完整备份并校验整片 16 MiB Flash。
  刷前分区表仅允许原厂精确版本，或整张 4 KiB 分区表均为空白 0xFF；拒绝第三方布局。
  写入后读取整片 Flash，逐字节检查预期变化，并检查其他区域保持不变。
仅安装 App：适用于引导程序正常、布局兼容且已经选择 app0 的设备。
  仅写 app0 / 0x10000，完整备份并校验 app0 的 4 MiB；不改 OTA 选择。
  必须有原厂精确分区表。对空白设备或不能正常启动的设备，请使用完整安装。

两种模式都不执行全片擦除，不改 NVS、app1、SPIFFS、assets、coredump 或 TF 卡。
完整安装的 OTA 初始数据会选择 app0；原设备设置保留，空白设备由固件初始化默认设置。
“完整安装”指四段系统固件安装，不代表格式化设备或自动向 TF 卡写入资源。
TF 字库、表盘等资源需另行复制：解压本包中的 TF-resources.zip，按其中说明将 nanoos
目录合并复制到 TF 卡；保留自己的文件。本工具不会代为写入 TF，也不会格式化卡。

操作方法
1. 将 ZIP 完整解压到本地文件夹，例如 C:\NanoOS。不要直接在压缩包中运行。
   路径可含空格和中文；为兼容 Windows 默认路径限制，建议使用较短目录。
2. 用能传输数据的 USB 线连接设备，关闭串口监视器及其他刷写程序。
3. 双击 Flash-NanoOS.cmd，在中文菜单中选择安装方式：
   输入 1 或直接回车：完整安装（默认、推荐；不知道区别时选此项）。
   输入 2：仅更新 App。其他输入会取消，尚未连接设备。
   它仅给本次 PowerShell 进程使用 ExecutionPolicy Bypass，不修改当前用户或系统的
   执行策略。组织策略若禁止脚本，请遵循管理员要求。
4. 多个 COM 端口时按提示选择；只有一个端口时自动选择，随后显示实际设备身份。
   核对安装方式后输入 FLASH 才会开始；直接回车可取消。
5. 等待出现 SUCCESS。程序只在核验结束后重启一次；让设备完成首次启动和 TF 初始化。

PowerShell 示例（位于解压目录）
  .\Flash-NanoOS.ps1 -CheckOnly
  .\Flash-NanoOS.ps1 -ListPorts
  .\Flash-NanoOS.ps1 -Mode Full -Port COM7
  .\Flash-NanoOS.ps1 -Mode App -Port COM7
  .\Flash-NanoOS.ps1 -Mode Full -Port COM7 -BackupRoot 'D:\设备备份'
也可用 pwsh -NoProfile -File .\Flash-NanoOS.ps1 -Mode Full（PowerShell 7）。
CheckOnly 只核验文件与依赖；ListPorts 仅枚举串口，二者均不打开串口、不写设备。
显式传入 -Mode Full / App 时跳过选择菜单；CheckOnly、ListPorts 和 RestoreFrom
也不显示菜单。恢复方式由备份记录决定。选定安装方式后，仍需输入 FLASH 才会连接
并安装；恢复时仍需输入 RESTORE。

写入清单固定如下，运行参数不能指定任意镜像或地址：
  0x2000   bootloader      22304 字节  （仅完整模式）
  0x8000   partition table  3072 字节  （仅完整模式，扇区余部填充 FF）
  0xe000   OTA initial      8192 字节  （仅完整模式）
  0x10000  app0          4193808 字节  （两种模式，最大 4 MiB）
固定 SHA-256 见 full-manifest.json 和 payload-manifest.json。
程序在写入前核验镜像精确长度、SHA-256、内部结构、芯片型号、Flash 容量及分区表，
备份落盘后重读文件，并调用 esptool 与设备比对；全部通过后才允许写入。
刷后再次使用 esptool 校验。完整模式读回整片 16 MiB Flash，核验四段写入及其他区域未变。
仅 App 模式读回 4 MiB app0，并单独核验 4 KiB 分区表；其读回验证不覆盖其他分区。
App 模式只向 app0 发出写入命令，验证结果不能用于证明 app0 之外的数据逐字节未变。
未完成所选模式的全部步骤不报告成功。
失败时不主动重启应用，串口会关闭；关闭窗口或异常断线时，设备实际状态需重新确认。

备份与日志默认永久保留在：
  %LOCALAPPDATA%\NanoOS\FlashBackups\日期时间-随机编号\
每次使用新目录，永不覆盖旧备份；不自动删除任何备份和日志。
完整模式：flash-before.bin / flash-readback.bin（各 16 MiB）。
仅 App 模式：app0-before.bin / app0-readback.bin（各 4 MiB）。
其他文件：backup.json（身份与校验）、table-before.bin / table-after.bin、
device.json、result.json、console.log。建议备份目标盘至少预留 100 MiB 空间。
备份可能包含个人数据和设备身份，请妥善保存；不要随软件包公开上传。

恢复
需要恢复时保留完整备份目录，将同一设备重新置于厂商规定的下载模式，再运行：
  .\Flash-NanoOS.ps1 -Port COM7 -RestoreFrom 'D:\设备备份\20261117-000000-12345678'
程序核对备份 SHA-256、长度、原分区表及实际设备 MAC，输入 RESTORE 后恢复。
App 备份只恢复 app0；完整备份只恢复安装涉及的四个原扇区范围（引导、分区表、
OTA 和 app0），不覆盖目前的 NVS、其他数据区或 TF。完整16MiB备份仍永久保留，
如需恢复其他区域，应由了解设备布局的人员另行处理。
恢复前另存当前数据并校验，恢复后继续执行完整核验。空白机备份恢复后仍为空白状态。
自动恢复也会核验设备当前分区表；若当前表已损坏或属于未知布局，完整安装与自动恢复
都会拒绝。此时请保留完整 16 MiB 备份及日志，交由了解设备布局的人员处理。

取消与失败
连接前按回车即可取消。连接后 Ctrl+C 会尝试停止工作进程并关闭串口。
擦写期间不要取消、拔线或断电；若中断，应用或引导程序可能不完整，需要进入下载模式
根据当前分区表状态尝试完整安装或恢复；分区表损坏时按上方恢复说明处理。
关闭窗口或系统崩溃后，以 result.json 为准；started / failed /
cancelled / verified-awaiting-reset 都不等于完整成功。不要因进度曾到 100% 就拔线。
日志保留标准输出和标准错误。若无成功结果，保留整个会话目录以便诊断。

完整性与许可
发布 ZIP 的外部 SHA-256 用于检查下载；PS 启动器还校验固定文件清单与全部负载。
这些校验不等于数字签名，不能替代可信下载来源。
DEPENDENCIES.json 记录官方来源与原始依赖包 SHA-256；LICENSES 中保留组件许可。
Python 运行时许可另见 runtime\LICENSE.txt，各 wheel 的原始 dist-info 许可也完整保留。
third-party-source 包含 esptool 完整原始源码归档；这不是 NanoOS 系统源码。
固件通知见 FIRMWARE-NOTICES.txt。AirPlay 使用 GPL-3.0-or-later；固件完整对应源码的
提供方式尚未解决。本包没有 NanoOS 完整对应源码，附上许可或测试二进制不能替代
相应分发条件；刷写器及依赖的许可不能视为整份组合固件的闭源分发许可。
