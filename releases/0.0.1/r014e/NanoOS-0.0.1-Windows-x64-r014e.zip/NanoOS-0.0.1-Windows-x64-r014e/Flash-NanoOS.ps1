﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Full', 'App')]
    [string]$Mode = 'Full',
    [string]$Port,
    [switch]$ListPorts,
    [switch]$CheckOnly,
    [string]$BackupRoot,
    [string]$RestoreFrom
)
$ErrorActionPreference = 'Stop'
try {
    if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem) {
        throw 'This package requires 64-bit Windows 10/11.'
    }
    $root = [IO.Path]::GetFullPath($PSScriptRoot)
    $manifestPath = Join-Path $root 'payload-manifest.json'
    if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a965e7cbb40db9c19f65c1f0ce8a2a1e6c556bbb529dec300a9a7757518f7e30') {
        throw 'Payload manifest has changed. Extract a fresh official ZIP.'
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Host 'Checking offline package integrity...'
    foreach ($entry in $manifest.files) {
        $target = [IO.Path]::GetFullPath((Join-Path $root $entry.path))
        if (-not $target.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Manifest contains a path outside this package.'
        }
        $file = Get-Item -LiteralPath $target
        if ($file.Length -ne $entry.bytes -or
            (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
            throw ('Payload check failed: ' + $entry.path)
        }
    }
    if (-not $PSBoundParameters.ContainsKey('Mode') -and -not $ListPorts -and -not $CheckOnly -and -not $RestoreFrom) {
        Write-Host ''
        Write-Host '请选择安装方式：'
        Write-Host '  1. 完整安装（默认、推荐；不知道区别时选此项）'
        Write-Host '  2. 仅更新 App'
        $selection = (Read-Host '输入 1 或 2；直接回车选择完整安装；其他输入取消').Trim()
        switch ($selection) {
            ''  { $Mode = 'Full' }
            '1' { $Mode = 'Full' }
            '2' { $Mode = 'App' }
            default {
                Write-Host '已取消，尚未连接设备。'
                exit 0
            }
        }
    }
    $python = Join-Path $root 'runtime\python.exe'
    $arguments = @('-I', '-B', '-X', 'utf8', '-u', (Join-Path $root 'flasher.py'))
    $arguments += @('--mode', $Mode.ToLowerInvariant())
    if ($Port) { $arguments += @('--port', $Port) }
    if ($ListPorts) { $arguments += '--list-ports' }
    if ($CheckOnly) { $arguments += '--check-only' }
    if ($BackupRoot) { $arguments += @('--backup-root', $BackupRoot) }
    if ($RestoreFrom) { $arguments += @('--restore-from', $RestoreFrom) }
    & $python @arguments
    $code = $LASTEXITCODE
    if ($code -ne 0) { Write-Host ('NanoOS installer failed (exit ' + $code + '). Read the message and retained log above.') -ForegroundColor Red }
    exit $code
} catch {
    Write-Host ('NanoOS installer stopped: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
